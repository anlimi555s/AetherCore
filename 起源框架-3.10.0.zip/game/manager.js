// manager.js - 起源管理器本体：诊断 / 模块开关 / 更新 三页签
// 依赖 susato-core(ui 面板与点击委托, 本包自带副本) 与 rules.js(SusatoRules 规则数据)。
// 全部 ModLoader API 访问都做存在性检查, 缺哪个哪个区块显示"不可用", 绝不抛错。
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.manager) return; // load-once 守卫

  var OFF_KEY = 'susato_modules_off';             // 框架功能模块开关(细分)
  var MODS_OFF_KEY = 'susato_mods_off';           // mod 整包停用清单(log-hook canLoadThisMod 消费)
  var MODS_OFF_META_KEY = 'susato_mods_off_meta'; // 停用时的版本备忘(仅展示)
  var SELF_NAME = '起源框架';

  // ---------------- CSS 注入 ----------------

  function _injectStyles() {
    try {
      if (document.getElementById('susato-manager-css')) return;
      if (!document.head) return; // 防御: head 不存在(极少见)
      var css = [
      '.susato-tab-bar{display:flex;gap:0;border-bottom:1px solid var(--700,#3f3f46);margin-bottom:14px;padding-bottom:0}',
      '.susato-tab-btn{background:none;border:none;color:var(--400,#a1a1aa);padding:8px 16px;cursor:pointer;font-size:13px;font-weight:500;border-bottom:2px solid transparent;margin-bottom:-1px;transition:all 0.2s;font-family:inherit}',
      '.susato-tab-btn:hover{color:var(--200,#e4e4e7)}',
      '.susato-tab-btn.susato-active{color:var(--gold,#D4AF37);border-bottom-color:var(--gold,#D4AF37);font-weight:700}',
      '.susato-card{border:1px solid var(--700,#3f3f46);border-radius:8px;padding:10px 14px;margin-bottom:8px;background:var(--750,rgba(255,255,255,0.02))}',
      '.susato-card.susato-card-warn{border-left:3px solid var(--gold,#ca4)}',
      '.susato-card.susato-card-err{border-left:3px solid var(--red,#c44)}',
      '.susato-card.susato-card-ok{border-left:3px solid var(--green,#4a4)}',
      '.susato-card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px}',
      '.susato-card-title{font-weight:700;font-size:13px}',
      '.susato-badge{font-size:10px;padding:2px 8px;border-radius:10px;background:var(--700,#3f3f46);color:var(--400,#a1a1aa);font-family:monospace}',
      '.susato-badge.susato-badge-gold{background:rgba(212,175,55,0.15);color:var(--gold,#D4AF37)}',
      '.susato-table{width:100%;border-collapse:collapse;margin-bottom:10px}',
      '.susato-table th{text-align:left;border-bottom:1px solid var(--700,#3f3f46);padding:5px 8px;font-size:11px;color:var(--500,#888);text-transform:uppercase;letter-spacing:0.04em}',
      '.susato-table td{padding:5px 8px;border-bottom:1px solid var(--800,#2a2a30);font-size:13px}',
      '.susato-table tr:hover td{background:var(--750,rgba(255,255,255,0.02))}',
      '.susato-table tr:nth-child(even) td{background:var(--780,rgba(255,255,255,0.01))}',
      '.susato-table tr:nth-child(even):hover td{background:var(--750,rgba(255,255,255,0.03))}',
      '.susato-log-pre{max-height:200px;overflow-y:auto;border:1px solid var(--800,#2a2a30);border-radius:6px;padding:8px;margin-top:4px;font-size:11px;font-family:monospace;background:var(--780,rgba(0,0,0,0.15))}',
      '.susato-log-line{margin:1px 0;white-space:pre-wrap;word-break:break-all}',
      '.susato-log-err{color:var(--red,#c44)}',
      '.susato-log-warn{color:var(--gold,#ca4)}',
      '.susato-log-info{color:var(--400,#999)}',
      '.susato-link{color:var(--gold,#D4AF37);cursor:pointer;text-decoration:none;font-size:12px}',
      '.susato-link:hover{text-decoration:underline}',
      '.susato-link-btn{display:inline-block;padding:8px 20px;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;text-decoration:none;transition:all 0.2s;font-family:inherit;text-align:center}',
      '.susato-link-btn.susato-btn-apply{background:var(--gold,#D4AF37);color:#1a1a1a;border:none}',
      '.susato-link-btn.susato-btn-apply:hover{filter:brightness(1.15);box-shadow:0 0 16px rgba(212,175,55,0.3)}',
      '.susato-link-btn.susato-btn-reset{background:transparent;color:var(--500,#888);border:1px solid var(--700,#3f3f46)}',
      '.susato-link-btn.susato-btn-reset:hover{color:var(--200,#e4e4e7);border-color:var(--500,#888)}',

      // toggle-switch (Dol-Optimization 同款)
      '.susato-toggle{position:relative;width:44px;height:24px;flex-shrink:0;cursor:pointer;display:inline-block}',
      '.susato-toggle input{opacity:0;width:0;height:0;position:absolute;pointer-events:none}',
      '.susato-toggle-track{position:absolute;inset:0;background:#3f3f46;border-radius:24px;transition:all 0.2s;border:1px solid var(--700,#3f3f46)}',
      '.susato-toggle-thumb{position:absolute;top:2px;left:2px;width:18px;height:18px;background:#fff;border-radius:50%;transition:all 0.2s;box-shadow:0 1px 3px rgba(0,0,0,0.5)}',
      '.susato-toggle input:checked+.susato-toggle-track{background:var(--gold,#D4AF37);border-color:var(--gold,#D4AF37)}',
      '.susato-toggle input:checked+.susato-toggle-track .susato-toggle-thumb{left:22px}',
      '.susato-toggle input:disabled+.susato-toggle-track{opacity:0.4;cursor:not-allowed}',
      '.susato-toggle input:disabled+.susato-toggle-track .susato-toggle-thumb{background:#888}',

      // 模块行
      '.susato-mod-row{display:flex;align-items:flex-start;gap:12px;padding:10px 0;border-bottom:1px solid var(--800,#2a2a30)}',
      '.susato-mod-row:last-child{border-bottom:none}',
      '.susato-mod-info{flex:1;min-width:0}',
      '.susato-mod-name{font-weight:600;font-size:13px;margin-bottom:2px}',
      '.susato-mod-desc{font-size:11px;color:var(--500,#888)}',
      '.susato-mod-warn{font-size:11px;color:var(--red,#c44);margin-top:2px}',

      // loading
      '.susato-spinner{display:inline-block;width:20px;height:20px;border:2px solid var(--700,#3f3f46);border-top-color:var(--gold,#D4AF37);border-radius:50%;animation:susato-spin 0.7s linear infinite;margin-right:8px;vertical-align:middle}',
      '@keyframes susato-spin{to{transform:rotate(360deg)}}',

      // update card
      '.susato-update-card{border:1px solid var(--gold,#ca4);border-radius:8px;padding:12px 14px;margin-bottom:8px;background:rgba(212,175,55,0.04)}',
      '.susato-update-card.susato-update-current{border-color:var(--700,#3f3f46);background:var(--750,rgba(255,255,255,0.02))}',
      '.susato-version-arrow{color:var(--gold,#D4AF37);margin:0 4px}',

      // empty / error state
      '.susato-empty{text-align:center;color:var(--500,#888);padding:20px 0;font-size:13px}',
      '.susato-err-card{border:1px solid var(--red,#c44);border-left:3px solid var(--red,#c44);border-radius:8px;padding:10px 14px;margin-bottom:8px}',

      // step list
      '.susato-step-list{counter-reset:susato-step;list-style:none;padding:0;margin:0}',
      '.susato-step-list li{counter-increment:susato-step;padding:4px 0 4px 28px;position:relative;font-size:13px}',
      '.susato-step-list li::before{content:counter(susato-step);position:absolute;left:0;top:4px;width:20px;height:20px;border-radius:50%;background:var(--700,#3f3f46);color:var(--400,#a1a1aa);text-align:center;line-height:20px;font-size:11px;font-weight:600}',

      // toast
      '.susato-toast-container{position:fixed;bottom:30px;left:50%;z-index:99999;pointer-events:none}',
      '.susato-toast{position:relative;left:-50%;background:#1f1f23;border:1px solid var(--700,#3f3f46);color:#e4e4e7;padding:10px 20px;border-radius:20px;font-size:12px;font-weight:600;box-shadow:0 6px 24px rgba(0,0,0,0.5);transform:translateY(120px);opacity:0;transition:transform 0.35s cubic-bezier(0.34,1.56,0.64,1),opacity 0.2s;margin-bottom:6px;white-space:nowrap}',
      '.susato-toast.susato-toast-show{transform:translateY(0);opacity:1}',
      '.susato-toast.susato-toast-success{border-color:var(--green,#4a4);box-shadow:0 6px 24px rgba(0,0,0,0.5),0 0 16px rgba(34,197,94,0.15)}',
      '.susato-toast.susato-toast-warning{border-color:var(--gold,#ca4)}',
      '.susato-toast.susato-toast-error{border-color:var(--red,#c44)}'
    ].join('\n');
    var s = document.createElement('style');
    s.id = 'susato-manager-css';
    s.textContent = css;
    document.head.appendChild(s);
    } catch (e) { /* CSS 注入失败不阻断面板渲染 */ }
  }

  // ---------------- Toast 通知 ----------------

  var _toastTimer = null;
  var _toastRoot = null;

  function _initToast() {
    if (_toastRoot) return;
    _toastRoot = document.createElement('div');
    _toastRoot.className = 'susato-toast-container';
    document.body.appendChild(_toastRoot);
  }

  function toast(msg, type) {
    _initToast();
    var el = document.createElement('div');
    el.className = 'susato-toast' + (type ? ' susato-toast-' + type : '');
    el.textContent = msg;
    _toastRoot.appendChild(el);
    // 强制回流后显示
    el.offsetHeight;
    el.classList.add('susato-toast-show');
    // 2.2s 后移除
    var timer = setTimeout(function () {
      el.classList.remove('susato-toast-show');
      setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 400);
    }, 2200);
    // 点击立即关闭
    el.addEventListener('click', function () {
      clearTimeout(timer);
      el.classList.remove('susato-toast-show');
      setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 400);
    });
  }

  // ---------------- 安全取数 ----------------

  function _utils() {
    try { return window.modUtils || (window.modSC2DataManager && window.modSC2DataManager.getModUtils()); }
    catch (e) { return null; }
  }
  function _rules() { return window.SusatoRules || null; }
  function _semver() {
    try { var u = _utils(); return u && u.getSemVerTools ? u.getSemVerTools() : null; }
    catch (e) { return null; }
  }

  // 已装 mod 快照: [{name, version, from, bootJson}]
  function _snapshot() {
    var u = _utils();
    if (!u || !u.getModListName) return null;
    var out = [];
    try {
      var names = u.getModListName();
      for (var i = 0; i < names.length; i++) {
        var name = names[i];
        var info = null, from = '';
        try { info = u.getMod(name); } catch (e) {}
        try {
          var mf = u.getModAndFromInfo && u.getModAndFromInfo(name);
          from = (mf && (mf.from || (mf.length && mf[0] && mf[0].from))) || '';
        } catch (e) {}
        out.push({
          name: name,
          version: (info && info.bootJson && info.bootJson.version) || '?',
          from: String(from || '?'),
          bootJson: (info && info.bootJson) || null,
        });
      }
    } catch (e) { return null; }
    return out;
  }

  function _satisfies(version, range) {
    var sv = _semver();
    if (!sv) return null;
    try {
      // InfiniteSemVer 的 parseVersion 返回 {version, operator} 包装, satisfies 要的是内层 .version
      // (本体 DependenceChecker 同款取法; 漏取会让比较恒等于 0, 任何范围都误判成立)
      var pv = sv.parseVersion(String(version));
      var inner = (pv && pv.version !== undefined) ? pv.version : pv;
      return !!sv.satisfies(inner, sv.parseRange(String(range)));
    } catch (e) { return null; }
  }

  // ---------------- 规则求值(与构建器同规则) ----------------

  function _findMod(mods, name) {
    for (var i = 0; i < mods.length; i++) if (mods[i].name === name) return { item: mods[i], index: i };
    return null;
  }

  function evalRules(mods) {
    var R = _rules();
    var out = [];
    if (!R || !mods) return out;
    var i;
    for (i = 0; i < (R.mutualExclusion || []).length; i++) {
      var mx = R.mutualExclusion[i];
      var a = _findMod(mods, mx.nameA), b = _findMod(mods, mx.nameB);
      if (!a || !b) continue;
      if (mx.versionA) {
        var sa = _satisfies(a.item.version, mx.versionA);
        if (sa === false) continue; // 版本不满足, 不触发
        if (sa === null) continue;  // 解析失败, 宁可漏报不误报
      }
      if (mx.versionB) {
        var sb = _satisfies(b.item.version, mx.versionB);
        if (sb === false) continue;
        if (sb === null) continue;
      }
      out.push({ level: mx.type === 'hard' ? 'error' : 'warn', text: '互斥: ' + mx.nameA + ' 与 ' + mx.nameB + ' 同装。' + mx.reason });
    }
    for (i = 0; i < (R.oldNames || []).length; i++) {
      var on = R.oldNames[i];
      if (_findMod(mods, on.oldName)) {
        out.push({ level: 'warn', text: '旧包: ' + on.oldName + ' 应换为 ' + on.newName + '。' + on.reason });
      }
    }
    for (i = 0; i < (R.orderContracts || []).length; i++) {
      var oc = R.orderContracts[i];
      var self = _findMod(mods, oc.name);
      if (!self) continue;
      for (var j = 0; j < oc.afterNames.length; j++) {
        var dep = _findMod(mods, oc.afterNames[j]);
        if (dep && dep.index > self.index) {
          out.push({ level: 'error', text: '顺序: ' + oc.name + ' 必须排在 ' + oc.afterNames[j] + ' 之后。' + oc.reason });
        }
      }
    }
    return out;
  }

  // 依赖复检: 返回 [{mod, dep, status:'ok'|'missing'|'version'|'unknown', detail}]
  function evalDeps(mods) {
    var out = [];
    if (!mods) return out;
    for (var i = 0; i < mods.length; i++) {
      var deps = (mods[i].bootJson && mods[i].bootJson.dependenceInfo) || [];
      for (var d = 0; d < deps.length; d++) {
        var dep = deps[d];
        if (!dep || !dep.modName) continue;
        if (dep.modName === 'ModLoader' || dep.modName === 'GameVersion') continue;
        var target = _findMod(mods, dep.modName);
        if (!target) { out.push({ mod: mods[i].name, dep: dep.modName + ' ' + (dep.version || ''), status: 'missing', detail: '未安装' }); continue; }
        if (dep.version) {
          var ok = _satisfies(target.item.version, dep.version);
          if (ok === false) out.push({ mod: mods[i].name, dep: dep.modName + ' ' + dep.version, status: 'version', detail: '已装 ' + target.item.version + ' 不满足' });
          else if (ok === null) out.push({ mod: mods[i].name, dep: dep.modName + ' ' + dep.version, status: 'unknown', detail: '版本无法判定(semver 工具不可用)' });
        }
      }
    }
    return out;
  }

  // 文件冲突摘要: 返回 [{mod, css, js, passage}] 或 null(API 不可用)
  function conflictSummary() {
    var u = _utils();
    if (!u || !u.getModConflictInfo) return null;
    var raw;
    try { raw = u.getModConflictInfo(); } catch (e) { return null; }
    if (!raw) return null;
    var out = [];
    try {
      var arr = Array.isArray(raw) ? raw : (raw.mod ? [raw] : Object.keys(raw).map(function (k) { return raw[k]; }));
      for (var i = 0; i < arr.length; i++) {
        var r = arr[i];
        var res = r && (r.result || r);
        var name = (r && (r.mod && r.mod.name)) || (res && res.dataSource) || ('#' + i);
        function cnt(x) { try { return (x && x.conflict && (x.conflict.size !== undefined ? x.conflict.size : x.conflict.length)) || 0; } catch (e) { return 0; } }
        var css = cnt(res && res.styleFileItems), js = cnt(res && res.scriptFileItems), pg = cnt(res && res.passageDataItems);
        if (css + js + pg > 0) out.push({ mod: String(name), css: css, js: js, passage: pg });
      }
    } catch (e) { return null; }
    return out;
  }

  // ---------------- 模块开关 ----------------

  function getOff() {
    try { var a = JSON.parse(localStorage.getItem(OFF_KEY)); return Array.isArray(a) ? a : []; }
    catch (e) { return []; }
  }
  function setOff(arr) {
    try { localStorage.setItem(OFF_KEY, JSON.stringify(arr)); return true; }
    catch (e) { return false; }
  }

  // ---------------- mod 整包开关(log-hook canLoadThisMod 消费) ----------------

  function getModsOff() {
    try { var a = JSON.parse(localStorage.getItem(MODS_OFF_KEY)); return Array.isArray(a) ? a : []; }
    catch (e) { return []; }
  }
  function setModsOff(arr) {
    try { localStorage.setItem(MODS_OFF_KEY, JSON.stringify(arr)); return true; }
    catch (e) { return false; }
  }
  function getModsOffMeta() {
    try { var m = JSON.parse(localStorage.getItem(MODS_OFF_META_KEY)); return (m && typeof m === 'object') ? m : {}; }
    catch (e) { return {}; }
  }
  function setModsOffMeta(m) {
    try { localStorage.setItem(MODS_OFF_META_KEY, JSON.stringify(m)); } catch (e) {}
  }

  // mod 开关行状态(纯函数, 仿真用)。mods=快照(加载序), off=停用清单, meta=版本备忘。
  // state: self=管理器本体不可关 / before=位于管理器之前拦不到 / on=已启用可关 / off=已停用可恢复
  function computeModRows(mods, off, meta) {
    var rows = [];
    var selfIdx = -1;
    var i, j;
    for (i = 0; i < (mods || []).length; i++) if (mods[i].name === SELF_NAME) { selfIdx = i; break; }
    for (i = 0; i < (mods || []).length; i++) {
      var m = mods[i];
      var state;
      if (m.name === SELF_NAME) state = 'self';
      else if (selfIdx >= 0 && i < selfIdx) state = 'before';
      else state = 'on';
      rows.push({ name: m.name, version: m.version, from: m.from, state: state, inOff: (off || []).indexOf(m.name) >= 0 });
    }
    for (i = 0; i < (off || []).length; i++) {
      var name = off[i];
      var loaded = false;
      for (j = 0; j < rows.length; j++) if (rows[j].name === name) { loaded = true; break; }
      if (!loaded) rows.push({ name: name, version: (meta && meta[name]) || '?', from: '已停用', state: 'off', inOff: true });
    }
    return rows;
  }

  // 关掉 name 会缺依赖的已装 mod(软警告)
  function dependentsOf(mods, name) {
    var out = [];
    for (var i = 0; i < (mods || []).length; i++) {
      var deps = (mods[i].bootJson && mods[i].bootJson.dependenceInfo) || [];
      for (var d = 0; d < deps.length; d++) {
        if (deps[d] && deps[d].modName === name) { out.push(mods[i].name); break; }
      }
    }
    return out;
  }

  // ---------------- DOM 构建 ----------------

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function _renderTabBar(root, tabs, current, onChange) {
    var bar = el('div', 'susato-tab-bar');
    for (var i = 0; i < tabs.length; i++) {
      (function (t) {
        var btn = document.createElement('button');
        btn.className = 'susato-tab-btn' + (t.id === current ? ' susato-active' : '');
        btn.textContent = t.name;
        btn.setAttribute('data-tab', t.id);
        btn.onclick = function () { onChange(t.id); };
        bar.appendChild(btn);
      })(tabs[i]);
    }
    root.appendChild(bar);
  }

  function _setActiveTab(bar, tabId) {
    var btns = bar.querySelectorAll('.susato-tab-btn');
    for (var i = 0; i < btns.length; i++) {
      btns[i].classList.toggle('susato-active', btns[i].getAttribute('data-tab') === tabId);
    }
  }

  // ---------------- 诊断页签 ----------------

  // 清 BSA 图像缓存并刷新(浏览器 IndexedDB 一个坑: 若有旧页面连接未关, blocked 回调触发,
  // reload 强行关连接, 新页面在旧连接确认关闭后自动托管 pending delete)
  function _clearBSACacheAndReload() {
    var IDB = window.indexedDB || window.webkitIndexedDB || window.mozIndexedDB || window.msIndexedDB;
    var DB_NAME = 'BeautySelectorAddon';
    if (!IDB) {
      toast('当前浏览器不支持 IndexedDB, 无需清理', 'warning');
      return;
    }
    var req = IDB.deleteDatabase(DB_NAME);
    req.onsuccess = function () {
      toast('美妆图像缓存已清除, 正在刷新', 'success');
      setTimeout(function () { try { location.reload(); } catch (e) {} }, 300);
    };
    req.onerror = function () {
      toast('缓存清除失败, 可手动去 F12->Application->IndexedDB 删除 ' + DB_NAME, 'error');
    };
    req.onblocked = function () {
      toast('缓存已标记清除, 正在刷新(关旧连接)', 'success');
      // 存在旧页面连接未关时 blocked 先触发, 硬刷新关当前连接,
      // 刷新后新页面开库时旧 pending delete 已在排队, 会等到旧连接确认关闭后执行
      setTimeout(function () { try { location.reload(); } catch (e) {} }, 300);
    };
  }

  function renderDiag(root) {
    root.innerHTML = '';
    var mods = _snapshot();
    if (!mods) { root.appendChild(el('div', 'susato-empty', 'ModLoader 接口不可用, 无法读取 mod 列表。')); return; }

    // 规则告警
    var alerts = evalRules(mods);
    if (alerts.length) {
      var alertCard = el('div', 'susato-card susato-card-warn');
      alertCard.appendChild(el('div', 'susato-card-title', '告警 (' + alerts.length + ')'));
      for (var a = 0; a < alerts.length; a++) {
        var line = el('div', 'susato-log-line', alerts[a].text);
        line.style.cssText = 'color:' + (alerts[a].level === 'error' ? 'var(--red,#c44)' : 'var(--gold,#ca4)') + ';margin:3px 0;font-size:12px;';
        alertCard.appendChild(line);
      }
      root.appendChild(alertCard);
    }

    // mod 总览表(默认隐藏 Local 内嵌来源与管理器本体, 可展开; # 保持原始加载序号)
    var tblCard = el('div', 'susato-card');
    var tblHead = el('div', 'susato-card-header');
    var tblTitle = el('span', 'susato-card-title', '');
    var tblToggle = el('span', 'susato-link', '');
    tblHead.appendChild(tblTitle);
    tblHead.appendChild(tblToggle);
    tblCard.appendChild(tblHead);
    var tblBox = el('div', '');
    tblCard.appendChild(tblBox);
    var showAll = false;
    function fillModTable() {
      tblBox.innerHTML = '';
      var tbl = el('table', 'susato-table');
      var head = document.createElement('tr');
      ['#', 'Mod', '版本', '来源'].forEach(function (h) { head.appendChild(el('th', '', h)); });
      tbl.appendChild(head);
      var shown = 0;
      for (var i = 0; i < mods.length; i++) {
        var noise = mods[i].from === 'Local' || mods[i].name === SELF_NAME;
        if (noise && !showAll) continue;
        var tr = document.createElement('tr');
        [String(i + 1), mods[i].name, mods[i].version, mods[i].from].forEach(function (c) {
          tr.appendChild(el('td', '', c));
        });
        tbl.appendChild(tr);
        shown++;
      }
      if (shown) tblBox.appendChild(tbl);
      else tblBox.appendChild(el('div', 'susato-empty', '除内嵌与管理器本体外没有其他 mod。'));
      tblTitle.textContent = '已装 Mod (' + shown + '/' + mods.length + ')';
      tblToggle.textContent = showAll ? '隐藏内嵌与本体' : '显示全部(' + mods.length + ')';
    }
    tblToggle.onclick = function () { showAll = !showAll; fillModTable(); };
    fillModTable();
    root.appendChild(tblCard);

    // 依赖复检
    var deps = evalDeps(mods);
    var depCard = el('div', 'susato-card');
    depCard.appendChild(el('div', 'susato-card-title', '依赖检查'));
    if (!deps.length) {
      depCard.appendChild(el('div', 'susato-empty', '全部依赖满足。'));
    } else {
      for (var d = 0; d < deps.length; d++) {
        depCard.appendChild(el('div', 'susato-log-err', deps[d].mod + ' 需要 ' + deps[d].dep + ' - ' + deps[d].detail));
      }
    }
    root.appendChild(depCard);

    // 文件冲突
    var conf = conflictSummary();
    var cbox = el('div', 'susato-card');
    cbox.appendChild(el('div', 'susato-card-title', '文件级覆盖'));
    if (conf === null) cbox.appendChild(el('div', 'susato-empty', '冲突信息不可用。'));
    else if (!conf.length) cbox.appendChild(el('div', 'susato-empty', '无同名文件覆盖。'));
    else {
      for (var c = 0; c < conf.length; c++) {
        cbox.appendChild(el('div', '', conf[c].mod + ': 段落 ' + conf[c].passage + ' / JS ' + conf[c].js + ' / CSS ' + conf[c].css + ' 处被后序 mod 覆盖'));
      }
    }
    root.appendChild(cbox);

    // 加载期日志
    var lbox = el('div', 'susato-card');
    lbox.appendChild(el('div', 'susato-card-title', '加载期日志'));
    var hook = window.__susatoLogHook;
    if (!hook || !hook.entries) {
      lbox.appendChild(el('div', 'susato-empty', '日志钩子未注册(需要本 mod 在加载列表中且 ModLoader 支持)。'));
    } else {
      var mode = 'bad';
      var pre = el('div', 'susato-log-pre');
      function refillLog() {
        pre.innerHTML = '';
        var n = 0;
        for (var k = 0; k < hook.entries.length; k++) {
          var e2 = hook.entries[k];
          if (mode === 'bad' && e2.level === 'info') continue;
          var line = el('div', 'susato-log-line susato-log-' + (e2.level === 'error' ? 'err' : (e2.level === 'warning' ? 'warn' : 'info')), '[' + e2.level + '] ' + e2.msg);
          pre.appendChild(line);
          n++;
        }
        if (!n) pre.appendChild(el('div', 'susato-empty', mode === 'bad' ? '没有错误或警告。' : '没有日志。'));
      }
      var bar = el('div', '');
      bar.style.cssText = 'margin:6px 0;';
      var btnBad = el('span', 'susato-link', '仅错误与警告');
      btnBad.style.cssText += 'margin-right:12px;';
      var btnAll = el('span', 'susato-link', '全部(' + hook.entries.length + ')');
      btnAll.style.cssText += 'margin-right:12px;';
      var btnCopy = el('span', 'susato-link', '复制全部');
      btnBad.onclick = function () { mode = 'bad'; refillLog(); };
      btnAll.onclick = function () { mode = 'all'; refillLog(); };
      btnCopy.onclick = function () {
        var txt = hook.entries.map(function (x) { return '[' + x.level + '] ' + x.msg; }).join('\n');
        try { navigator.clipboard.writeText(txt); btnCopy.textContent = '已复制'; } catch (e) {
          try {
            var ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta);
            ta.select(); document.execCommand('copy'); document.body.removeChild(ta); btnCopy.textContent = '已复制';
          } catch (e2) {}
        }
      };
      bar.appendChild(btnBad); bar.appendChild(btnAll); bar.appendChild(btnCopy);
      lbox.appendChild(bar);
      lbox.appendChild(pre);
      refillLog();
    }
    root.appendChild(lbox);

    // 维护
    var maintCard = el('div', 'susato-card');
    maintCard.appendChild(el('div', 'susato-card-title', '维护'));
    var maintRow = el('div', '');
    maintRow.style.cssText = 'display:flex;align-items:center;gap:12px;margin:6px 0;flex-wrap:wrap;';
    var maintName = el('span', '', '美妆图像缓存 (BeautySelectorAddon)');
    maintName.style.cssText = 'font-size:13px;';
    maintRow.appendChild(maintName);
    var clearBtn = el('a', 'susato-link-btn susato-btn-reset', '清除并刷新');
    clearBtn.style.cssText += 'padding:4px 12px;font-size:12px;';
    clearBtn.onclick = function () { _clearBSACacheAndReload(); };
    maintRow.appendChild(clearBtn);
    maintCard.appendChild(maintRow);
    maintCard.appendChild(el('div', 'susato-mod-desc', '图像不生效/变回原版/更新内容包后异常时先清这个。不清 Mod Loader 的 mod 存储库, 只清美妆选择器的图片缓存, 刷新后自动重建。'));

    // 本地 mod 安装
    var localRow = el('div', '');
    localRow.style.cssText = 'display:flex;align-items:center;gap:12px;margin:12px 0 4px;flex-wrap:wrap;';
    var localName = el('span', '', '安装本地 mod (zip)');
    localName.style.cssText = 'font-size:13px;';
    localRow.appendChild(localName);
    var fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.zip';
    fileInput.multiple = true;
    fileInput.style.display = 'none';
    var localStatus = el('span', 'susato-mod-desc', '');
    var pickBtn = el('a', 'susato-link-btn susato-btn-apply', '选择 zip 安装');
    pickBtn.style.cssText += 'padding:4px 12px;font-size:12px;';
    pickBtn.onclick = function () {
      if (!_canInstall()) { toast('ModLoader IndexDB 接口不可用', 'error'); return; }
      fileInput.click();
    };
    fileInput.onchange = function () {
      var files = Array.prototype.slice.call(fileInput.files || []);
      if (!files.length) return;
      var okCnt = 0, failCnt = 0, idx = 0;
      function next() {
        if (idx >= files.length) {
          localStatus.textContent = '';
          fileInput.value = '';
          if (okCnt) {
            toast('已装入 ' + okCnt + ' 个 mod' + (failCnt ? ', 失败 ' + failCnt : '') + ', 正在刷新', failCnt ? 'warning' : 'success');
            setTimeout(function () { try { location.reload(); } catch (e) {} }, 900);
          } else {
            toast('全部安装失败(' + failCnt + '), 详见控制台', 'error');
          }
          return;
        }
        var f = files[idx]; idx++;
        localStatus.textContent = '安装 ' + f.name + ' (' + idx + '/' + files.length + ')……';
        var reader = new FileReader();
        reader.onload = function () {
          _installLocalBytes(new Uint8Array(reader.result)).then(function (info) {
            okCnt++;
            toast('已装入 ' + info.name + ' v' + info.version, 'success');
            next();
          }, function (e) {
            failCnt++;
            try { console.error('[起源管理器] 本地安装失败 ' + f.name + ': ' + ((e && e.message) || e)); } catch (e2) {}
            toast(f.name + ' 安装失败: ' + ((e && e.message) || e), 'error');
            next();
          });
        };
        reader.onerror = function () { failCnt++; toast(f.name + ' 读取失败', 'error'); next(); };
        reader.readAsArrayBuffer(f);
      }
      next();
    };
    localRow.appendChild(pickBtn);
    localRow.appendChild(localStatus);
    localRow.appendChild(fileInput);
    maintCard.appendChild(localRow);
    maintCard.appendChild(el('div', 'susato-mod-desc', '选本地 zip 直接装进浏览器存储(IndexDB, 装载序最高, 同名覆盖旧版), 可多选, 装完自动刷新。新装 mod 排在加载列表末尾, 必要时去 Mod Loader 管理器调顺序。'));

    // IndexDB 存储清单(默认折叠, 供排查键名不一致的残留——兜底按名卸载覆盖不到的场景)
    var idxRow = el('div', '');
    idxRow.style.cssText = 'margin:10px 0 6px;';
    var idxLink = el('span', 'susato-link', 'IndexDB 存储清单 — 展开');
    var idxBox = el('div', '');
    idxBox.style.display = 'none';
    var idxFilled = false;
    idxLink.onclick = function () {
      if (!idxFilled) {
        idxFilled = true;
        try {
          var lc2 = _loadController();
          if (lc2 && typeof lc2.listModIndexDB === 'function') {
            lc2.listModIndexDB().then(function (list) {
              if (!list || !list.length) { idxBox.appendChild(el('div', 'susato-mod-desc', 'IndexDB 中没有 mod。')); return; }
              for (var i = 0; i < list.length; i++) {
                var itemRow = el('div', '');
                itemRow.style.cssText = 'display:flex;align-items:center;gap:8px;padding:3px 0;font-size:12px;';
                itemRow.appendChild(el('span', '', list[i]));
                if (list[i] !== SELF_NAME) itemRow.appendChild(_uninstallLink(list[i], 'IndexDB', '删除'));
                idxBox.appendChild(itemRow);
              }
            }).catch(function () { idxBox.appendChild(el('div', 'susato-mod-desc', '读取 IndexDB 清单失败。')); });
          } else { idxBox.appendChild(el('div', 'susato-mod-desc', 'ModLoader 接口不可用。')); }
        } catch (e) { idxBox.appendChild(el('div', 'susato-mod-desc', '读取失败: ' + (e.message || e))); }
      }
      var showing = idxBox.style.display !== 'none';
      idxBox.style.display = showing ? 'none' : '';
      idxLink.textContent = 'IndexDB 存储清单 — ' + (showing ? '展开' : '收起');
    };
    idxRow.appendChild(idxLink);
    maintCard.appendChild(idxRow);
    maintCard.appendChild(idxBox);
    maintCard.appendChild(el('div', 'susato-mod-desc', '用 Mod Loader 自带的 GUI 装的 mod 存储键可能不是包名, 按名卸不掉时可来这逐键手动清理。不清 ModLoader 自身存储库, 只删 mod 包数据。'));
    root.appendChild(maintCard);
  }

  // ---------------- 模块开关页签 ----------------

  // ---------------- 卸载(从浏览器存储移除, 刷新生效) ----------------
  // 内嵌(Local)不可卸载只能停用; IndexDB/LocalStorage 按来源走对应 API。
  // 存储键约定=mod名(本管理器安装的都是); Mod Loader 管理器装的若用了别的键,
  // 按名删会漏——兜底走维护卡的存储清单逐键删。
  function _canUninstall(from) { return from === 'IndexDB' || from === 'LocalStorage' || from === '已停用'; }
  function _uninstallMod(name, from) {
    if (name === SELF_NAME) return Promise.reject(new Error('管理器本体请在 Mod Loader 管理器中移除'));
    var lc = _loadController();
    if (!lc) return Promise.reject(new Error('ModLoader 接口不可用'));
    return Promise.resolve().then(function () {
      if (from === 'LocalStorage') {
        if (typeof lc.removeModLocalStorage !== 'function') throw new Error('LocalStorage 卸载接口不可用');
        return lc.removeModLocalStorage(name);
      }
      // IndexDB 与"已停用"(停用中的包仍存在 IndexDB)都走 IndexDB 删除
      if (from === 'IndexDB' || from === '已停用') {
        if (typeof lc.removeModIndexDB !== 'function') throw new Error('IndexDB 卸载接口不可用');
        return lc.removeModIndexDB(name);
      }
      throw new Error('内嵌 mod 无法卸载, 请用停用开关');
    }).then(function () {
      // 摘出停用清单, 防卸载后残留"已停用"幽灵行
      var off = getModsOff();
      var idx = off.indexOf(name);
      if (idx >= 0) { off.splice(idx, 1); setModsOff(off); }
      return true;
    });
  }

  // 两步确认的卸载文字链(开关页行内/存储清单行内共用)
  function _uninstallLink(name, from, labelPrefix) {
    var link = el('span', 'susato-link', labelPrefix || '卸载');
    link.style.cssText += 'font-size:11px;margin-top:4px;display:inline-block;';
    var armed = false, timer = null;
    link.onclick = function () {
      if (!armed) {
        armed = true;
        link.textContent = '确认卸载 ' + name + '? (再点一次)';
        link.style.color = 'var(--red,#c44)';
        timer = setTimeout(function () { armed = false; link.textContent = labelPrefix || '卸载'; link.style.color = ''; }, 5000);
        return;
      }
      clearTimeout(timer);
      link.textContent = '卸载中……';
      _uninstallMod(name, from).then(function () {
        toast('已卸载 ' + name + ', 正在刷新', 'success');
        setTimeout(function () { try { location.reload(); } catch (e) {} }, 700);
      }, function (e) {
        armed = false;
        link.textContent = labelPrefix || '卸载';
        link.style.color = '';
        toast('卸载失败: ' + ((e && e.message) || e), 'error');
      });
    };
    return link;
  }

  // 通用开关行: opts={checked, disabled, name, nameMuted, desc, descClass, warnText, warnVisible, extraBar(可选任意节点), onChange(checked, warnEl)}
  function _toggleRow(opts) {
    var row = el('div', 'susato-mod-row');
    var label = document.createElement('label');
    label.className = 'susato-toggle';
    label.style.cssText = 'margin-top:2px;';
    var cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = !!opts.checked;
    cb.disabled = !!opts.disabled;
    label.appendChild(cb);
    var track = document.createElement('span');
    track.className = 'susato-toggle-track';
    track.appendChild(el('span', 'susato-toggle-thumb'));
    label.appendChild(track);
    row.appendChild(label);
    var info = el('div', 'susato-mod-info');
    var nameRow = el('div', 'susato-mod-name', opts.name);
    if (opts.nameMuted) nameRow.style.cssText += 'color:var(--500,#888);';
    info.appendChild(nameRow);
    if (opts.desc) info.appendChild(el('div', opts.descClass || 'susato-mod-desc', opts.desc));
    if (opts.extraBar) info.appendChild(opts.extraBar);
    var warnEl = null;
    if (opts.warnText) {
      warnEl = el('div', 'susato-mod-warn', opts.warnText);
      warnEl.style.display = opts.warnVisible ? '' : 'none';
      info.appendChild(warnEl);
    }
    cb.onchange = function () { if (opts.onChange) opts.onChange(cb.checked, warnEl); };
    row.appendChild(info);
    return row;
  }

  function _applyButtons(root, applyLabel, resetLabel, onApply, onReset) {
    var actions = el('div', '');
    actions.style.cssText = 'display:flex;align-items:center;gap:12px;margin:4px 0 18px;';
    var apply = el('a', 'susato-link-btn susato-btn-apply', applyLabel);
    apply.onclick = onApply;
    var reset = el('a', 'susato-link-btn susato-btn-reset', resetLabel);
    reset.onclick = onReset;
    actions.appendChild(apply);
    actions.appendChild(reset);
    root.appendChild(actions);
  }

  function _saveAndReload(okFn) {
    if (okFn()) {
      toast('设置已保存, 正在刷新页面', 'success');
      setTimeout(function () { try { location.reload(); } catch (e) {} }, 400);
    } else {
      toast('写入失败, 浏览器可能处于隐私模式', 'error');
    }
  }

  function renderModules(root) {
    root.innerHTML = '';
    var mods = _snapshot();

    // ---- 第一节: mod 整包开关 ----
    var head1 = el('div', 'susato-card-title', 'Mod 开关');
    head1.style.cssText += 'margin-bottom:6px;';
    root.appendChild(head1);

    var info1 = el('div', 'susato-card');
    info1.appendChild(el('div', '', '停用 = 下次加载时整包拦截, 不删除文件, 随时可恢复; 应用后刷新生效。'));
    info1.appendChild(el('div', 'susato-mod-desc', '管理器只能拦截排在它之后加载的 mod, 建议在 Mod Loader 列表把本管理器排到最前。'));
    root.appendChild(info1);

    if (!mods) {
      root.appendChild(el('div', 'susato-empty', 'ModLoader 接口不可用, 无法读取 mod 列表。'));
    } else {
      var offNow = getModsOff();
      var meta = getModsOffMeta();
      var pendingMods = offNow.slice();
      var rows = computeModRows(mods, offNow, meta);
      // 位于管理器之前的行(多为加载器底座: ModLoaderGui/ImageLoaderHook/BSA 等)不可操作,
      // 默认折叠免噪音; 可操作行(可关/已停用/本体)正常列出
      var actionable = [], blocked = [];
      for (var i = 0; i < rows.length; i++) {
        (rows[i].state === 'before' ? blocked : actionable).push(rows[i]);
      }

      var listCard = el('div', 'susato-card');
      function renderModRow(container, row) {
        var desc;
        if (row.state === 'self') desc = '管理器本体, 不可停用';
        else if (row.state === 'before') desc = '位于管理器之前, 拦截不到' + (row.inOff ? '(已在停用清单, 前移管理器后生效)' : '');
        else if (row.state === 'off') desc = '已停用, 打开并应用即恢复';
        else desc = '来源 ' + row.from;
        var depWarn = '';
        if (row.state === 'on') {
          var deps = dependentsOf(mods, row.name);
          if (deps.length) depWarn = '关闭后 ' + deps.join(' / ') + ' 将缺依赖';
        }
        var extraBar = null;
        if (_canUninstall(row.from) && row.state !== 'self') {
          extraBar = _uninstallLink(row.name, row.from);
        }
        container.appendChild(_toggleRow({
          checked: pendingMods.indexOf(row.name) < 0,
          disabled: row.state === 'self' || row.state === 'before',
          name: row.name + (row.version !== '?' ? '  v' + row.version : ''),
          nameMuted: row.state === 'self' || row.state === 'before',
          desc: desc,
          warnText: depWarn,
          warnVisible: depWarn && pendingMods.indexOf(row.name) >= 0,
          extraBar: extraBar,
          onChange: function (checked, warnEl) {
            var idx = pendingMods.indexOf(row.name);
            if (checked && idx >= 0) pendingMods.splice(idx, 1);
            if (!checked && idx < 0) pendingMods.push(row.name);
            if (warnEl) warnEl.style.display = checked ? 'none' : '';
          },
        }));
      }
      for (var a2 = 0; a2 < actionable.length; a2++) renderModRow(listCard, actionable[a2]);

      if (blocked.length) {
        var blkHead = el('div', '');
        blkHead.style.cssText = 'padding:10px 0 2px;';
        var blkLink = el('span', 'susato-link', '加载器与前置 mod (' + blocked.length + ' 个, 位于管理器之前无法拦截) — 展开');
        var blkBox = el('div', '');
        blkBox.style.display = 'none';
        var blkFilled = false;
        blkLink.onclick = function () {
          var showing = blkBox.style.display !== 'none';
          if (!showing && !blkFilled) {
            blkFilled = true;
            for (var b = 0; b < blocked.length; b++) renderModRow(blkBox, blocked[b]);
          }
          blkBox.style.display = showing ? 'none' : '';
          blkLink.textContent = '加载器与前置 mod (' + blocked.length + ' 个, 位于管理器之前无法拦截) — ' + (showing ? '展开' : '收起');
        };
        blkHead.appendChild(blkLink);
        listCard.appendChild(blkHead);
        listCard.appendChild(blkBox);
      }
      root.appendChild(listCard);

      _applyButtons(root, '应用并刷新', '全部恢复并刷新', function () {
        // 版本备忘: 停用清单里的已装 mod 记下版本, 供恢复列表显示
        var m2 = getModsOffMeta();
        for (var k = 0; k < pendingMods.length; k++) {
          for (var j = 0; j < rows.length; j++) {
            if (rows[j].name === pendingMods[k] && rows[j].version !== '?') m2[pendingMods[k]] = rows[j].version;
          }
        }
        setModsOffMeta(m2);
        _saveAndReload(function () { return setModsOff(pendingMods); });
      }, function () {
        _saveAndReload(function () { return setModsOff([]); });
      });
    }

    // ---- 第二节: 功能模块微调(框架与美化包的功能开关, 守卫由 core 统一提供) ----
    var R = _rules();
    if (!R || !R.modules) return;

    var head2 = el('div', 'susato-card-title', '功能模块微调');
    head2.style.cssText += 'margin-bottom:6px;';
    root.appendChild(head2);

    var info2 = el('div', 'susato-card');
    var coreOk = false;
    try { coreOk = !!(window.SusatoModel && typeof window.SusatoModel.moduleOff === 'function'); } catch (e) {}
    if (!coreOk) {
      info2.appendChild(el('div', 'susato-log-err', '生效的框架核心是旧版(残留的旧 起源框架-寿里美化包/旧管理器 zip 抢先加载), 微调不可用——请在 Mod Loader 中移除旧包。'));
    }
    info2.appendChild(el('div', '', '只关框架的某个功能而保留其余, 应用后刷新生效。'));
    root.appendChild(info2);

    var off = getOff();
    var pending = off.slice();

    var toggleable = (R.modules || []).filter(function (mm) { return !mm.lock; });
    var listCard2 = el('div', 'susato-card');
    for (var m = 0; m < toggleable.length; m++) {
      (function (mm) {
        listCard2.appendChild(_toggleRow({
          checked: pending.indexOf(mm.id) < 0,
          disabled: !!mm.lock,
          name: mm.name + (mm.lock ? ' (锁定)' : ''),
          nameMuted: !!mm.lock,
          desc: mm.desc,
          warnText: mm.warn ? '关闭后: ' + mm.warn : '',
          warnVisible: mm.warn && pending.indexOf(mm.id) >= 0,
          onChange: function (checked, warnEl) {
            var idx = pending.indexOf(mm.id);
            if (checked && idx >= 0) pending.splice(idx, 1);
            if (!checked && idx < 0) pending.push(mm.id);
            if (warnEl) warnEl.style.display = checked ? 'none' : '';
          },
        }));
      })(R.modules[m]);
    }
    root.appendChild(listCard2);

    _applyButtons(root, '应用并刷新', '恢复默认并刷新', function () {
      _saveAndReload(function () { return setOff(pending); });
    }, function () {
      _saveAndReload(function () { return setOff([]); });
    });
  }

  // ---------------- 联网更新 ----------------
  var UPDATE_FETCH_TIMEOUT = 10000;
  var _pendingReload = false; // 本页会话内已装过更新, 等待刷新生效

  function _loadController() {
    try {
      return window.modModLoadController ||
        (window.modSC2DataManager && window.modSC2DataManager.getModLoadController && window.modSC2DataManager.getModLoadController());
    } catch (e) { return null; }
  }

  // 一键安装可用性: 需要 ModLoader 的 IndexDB 运行时接口
  function _canInstall() {
    var lc = _loadController();
    return !!(lc && typeof lc.addModIndexDB === 'function' && typeof lc.checkModZipFileIndexDB === 'function');
  }

  // 仓库文件的下载地址对(jsDelivr 优先, raw 降级), 统一从 rules.update.urls 取
  function _updateUrls(file) {
    try {
      var cfg = _rules() && _rules().update;
      return (cfg && typeof cfg.urls === 'function') ? cfg.urls(file) : [];
    } catch (e) { return []; }
  }

  // 按序尝试 urls 下载二进制。超时只管响应头(大包慢网正文不限时), onProgress(已收字节, 总字节|0)。
  function _fetchZipFirst(urls, onProgress) {
    var idx = 0;
    return new Promise(function (resolve, reject) {
      function tryNext(lastErr) {
        if (idx >= urls.length) { reject(lastErr || new Error('全部下载源不可达 (' + urls.length + ' 个地址尝试完毕)')); return; }
        var url = urls[idx]; idx++;
        var ctrl = (typeof AbortController === 'function') ? new AbortController() : null;
        var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, UPDATE_FETCH_TIMEOUT);
        var opt = { cache: 'no-cache' };
        if (ctrl) opt.signal = ctrl.signal;
        fetch(url, opt).then(function (r) {
          clearTimeout(timer); // 头已到, 正文按实际网速走
          if (!r.ok) { tryNext(new Error('HTTP ' + r.status)); return; }
          var total = 0;
          try { total = parseInt(r.headers.get('content-length') || '0', 10) || 0; } catch (e) {}
          if (r.body && r.body.getReader) {
            var reader = r.body.getReader();
            var chunks = [], received = 0;
            (function pump() {
              reader.read().then(function (step) {
                if (step.done) {
                  var buf = new Uint8Array(received), off = 0;
                  for (var i = 0; i < chunks.length; i++) { buf.set(chunks[i], off); off += chunks[i].length; }
                  resolve({ bytes: buf, url: url });
                  return;
                }
                chunks.push(step.value); received += step.value.length;
                if (onProgress) { try { onProgress(received, total); } catch (e) {} }
                pump();
              }, function (e) { tryNext(e); });
            })();
          } else {
            // 环境无流式 body: 整体读取, 无进度
            r.arrayBuffer().then(function (ab) { resolve({ bytes: new Uint8Array(ab), url: url }); }, function (e) { tryNext(e); });
          }
        }).catch(function (e) { clearTimeout(timer); tryNext(e); });
      }
      tryNext(null);
    });
  }

  // 校验 zip 并写入 IndexDB(装载序最高, 同名整体覆盖旧包, 整页刷新后生效)。
  // 双重防错: 包内 boot.json name 必须与清单一致; 版本必须与清单 latest 一致(拦 CDN 缓存旧包)。
  function _installFromBytes(modName, expectVersion, bytes) {
    var lc = _loadController();
    if (!lc || typeof lc.checkModZipFileIndexDB !== 'function' || typeof lc.addModIndexDB !== 'function') {
      return Promise.reject(new Error('ModLoader IndexDB 接口不可用, 请改用浏览器下载后手动安装'));
    }
    return Promise.resolve().then(function () {
      return lc.checkModZipFileIndexDB(bytes);
    }).then(function (bootJ) {
      if (!bootJ || typeof bootJ === 'string') {
        throw new Error('zip 校验失败: ' + (bootJ || '包内 boot.json 无效'));
      }
      if (bootJ.name !== modName) {
        throw new Error('包名不符: 清单是 ' + modName + ', 包内是 ' + bootJ.name + ', 已拒绝安装');
      }
      if (expectVersion && String(bootJ.version) !== String(expectVersion)) {
        throw new Error('版本不符: 清单是 ' + expectVersion + ', 包内是 ' + bootJ.version + '。多为 CDN 缓存未刷新, 请稍后重试');
      }
      return Promise.resolve(lc.addModIndexDB(modName, bytes)).then(function () {
        return { name: bootJ.name, version: bootJ.version };
      });
    });
  }

  // 并行下载多个文件并拼接(分卷还原; 单文件=单元素数组)。
  // 大小护栏: 拼完与清单总大小不符即拒绝(截断/缓存旧卷)。onProgress(已收合计, 总大小, 卷数, 卷数)
  function _downloadAllParts(files, totalSize, onProgress) {
    var done = 0, gotAll = 0;
    var chunks = new Array(files.length);
    function progressAll() {
      var sum = 0;
      for (var i = 0; i < chunks.length; i++) sum += (chunks[i] ? chunks[i].length : 0);
      gotAll = sum;
      if (onProgress) { try { onProgress(gotAll, totalSize || 0, files.length, files.length); } catch (e) {} }
    }
    return Promise.all(files.map(function (file, idx) {
      return _fetchZipFirst(_updateUrls(file), function () { progressAll(); }).then(function (res) {
        chunks[idx] = res.bytes;
        progressAll();
      });
    })).then(function () {
      var all = new Uint8Array(gotAll), off = 0;
      for (var i = 0; i < chunks.length; i++) { all.set(chunks[i], off); off += chunks[i].length; }
      if (totalSize && all.length !== totalSize) {
        return Promise.reject(new Error('大小不符: 清单 ' + totalSize + ' 实收 ' + all.length + ' 字节, 下载可能被截断或 CDN 缓存未刷新'));
      }
      return all;
    });
  }

  // 本地 zip 直装(维护卡"安装本地 mod"): 不做清单名/版本比对, 只验 boot.json 合法,
  // 存储键=包内 boot.name(同名覆盖旧版, 与一键更新同规)
  function _installLocalBytes(bytes) {
    var lc = _loadController();
    if (!lc || typeof lc.checkModZipFileIndexDB !== 'function' || typeof lc.addModIndexDB !== 'function') {
      return Promise.reject(new Error('ModLoader IndexDB 接口不可用'));
    }
    return Promise.resolve().then(function () {
      return lc.checkModZipFileIndexDB(bytes);
    }).then(function (bootJ) {
      if (!bootJ || typeof bootJ === 'string') {
        throw new Error('zip 校验失败: ' + (bootJ || '包内 boot.json 无效'));
      }
      return Promise.resolve(lc.addModIndexDB(bootJ.name, bytes)).then(function () {
        return { name: bootJ.name, version: bootJ.version };
      });
    });
  }

  function _startInstall(r, btn, statusEl) {
    if (btn._busy) return;
    btn._busy = true;
    btn.style.opacity = '0.55';
    statusEl.className = 'susato-mod-desc';
    statusEl.textContent = '连接中……';
    var files = (r.parts && r.parts.length) ? r.parts : [r.file];
    _downloadAllParts(files, r.size || 0, function (got, total, partNo, partCount) {
      statusEl.textContent = '下载中' + (partCount > 1 ? ' 第' + partNo + '/' + partCount + '卷' : '') +
        ' ' + _formatSize(got) + (total ? ' / ' + _formatSize(total) : '');
    }).then(function (bytes) {
      statusEl.textContent = '校验并写入本地存储……';
      return _installFromBytes(r.modName, r.remoteVersion, bytes);
    }).then(function (info) {
      _pendingReload = true;
      btn.textContent = '已安装';
      btn.classList.remove('susato-btn-apply');
      btn.classList.add('susato-btn-reset');
      statusEl.textContent = 'v' + info.version + ' 已写入, 刷新页面生效';
      toast('已安装 ' + info.name + ' v' + info.version, 'success');
      var bar = document.getElementById('susato-update-reloadbar');
      if (bar) bar.style.display = '';
    }).catch(function (e) {
      btn._busy = false;
      btn.style.opacity = '';
      statusEl.className = 'susato-mod-desc susato-log-err';
      statusEl.textContent = '失败: ' + ((e && e.message) || e);
      toast('安装失败', 'error');
    });
  }

  function _fetchFirst(urls) {
    var idx = 0;
    return new Promise(function (resolve, reject) {
      function tryNext() {
        if (idx >= urls.length) { reject(new Error('全部更新源不可达 (' + urls.length + ' 个地址尝试完毕)')); return; }
        var url = urls[idx];
        var ctrl = new AbortController();
        var timer = setTimeout(function () { ctrl.abort(); }, UPDATE_FETCH_TIMEOUT);
        fetch(url, { signal: ctrl.signal, cache: 'no-cache' }).then(function (r) {
          clearTimeout(timer);
          if (!r.ok) { idx++; tryNext(); return; }
          r.text().then(function (t) { resolve({ text: t, url: url }); }, function () { idx++; tryNext(); });
        }).catch(function () { clearTimeout(timer); idx++; tryNext(); });
      }
      tryNext();
    });
  }

  function _parseManifest(text) {
    try {
      var m = JSON.parse(text);
      if (!m || typeof m !== 'object') return null;
      if (!m.mods || typeof m.mods !== 'object') return null;
      return m;
    } catch (e) { return null; }
  }

  function _compareOne(localVersion, modEntry) {
    if (!modEntry || !modEntry.latest) return null;
    var remote = modEntry.latest;
    var info = (modEntry.versions && modEntry.versions[remote]) || {};
    function mk(isNewer, lv, failed) {
      return {
        isNewer: !!isNewer, localVersion: lv, remoteVersion: remote,
        date: info.date || '', changes: info.changes || '', file: info.file || '',
        size: info.size || 0, parts: info.parts || null, compareFailed: !!failed,
      };
    }
    var sv = _semver();
    if (!sv || !localVersion) return mk(false, localVersion || '?', false);
    // 走 _satisfies(内含 parseVersion 解包 + parseRange): 直接把范围字符串喂 satisfies
    // 会被真实库当可迭代对象扫字符, 恒判"在范围内" -- 任何版本都显示可更新的元凶
    var newer = _satisfies(String(remote), '>' + String(localVersion));
    if (newer === null) return mk(localVersion !== remote, localVersion, true); // 解析失败降级字符串比较
    return mk(newer, localVersion, false);
  }

  function _formatSize(bytes) {
    if (!bytes) return '';
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + ' MB';
    if (bytes >= 1024) return Math.round(bytes / 1024) + ' KB';
    return bytes + ' B';
  }

  // 下载页数据(纯函数, 仿真用): 清单全部条目分组, 已装/停用打状态标(已装可重下当前版)。
  // 坏条目(latest 不在 versions 里)排除; 分组按收录时 --group, 缺省"其他"
  function computeStore(modsMap, installedNames, offNames, installedVersions) {
    var groups = {};
    var order = [];
    for (var name in modsMap) {
      if (!Object.prototype.hasOwnProperty.call(modsMap, name)) continue;
      var entry = modsMap[name];
      if (!entry || !entry.latest || !entry.versions || !entry.versions[entry.latest]) continue;
      var g = entry.group || '其他';
      if (!groups[g]) { groups[g] = []; order.push(g); }
      groups[g].push({
        name: name, entry: entry,
        installed: (installedNames || []).indexOf(name) >= 0,
        off: (offNames || []).indexOf(name) >= 0,
        localVersion: (installedVersions && installedVersions[name]) || '',
      });
    }
    return order.map(function (g) { return { group: g, list: groups[g] }; });
  }

  // 商店卡片的前置检查: entry.deps 里未安装的生态 mod
  function missingDeps(entry, installedNames) {
    var out = [];
    var deps = (entry && entry.deps) || [];
    for (var i = 0; i < deps.length; i++) {
      if (deps[i] && deps[i].name && installedNames.indexOf(deps[i].name) < 0) out.push(deps[i].name);
    }
    return out;
  }

  // 安装/下载操作行(更新卡与商店卡共用)。r: {modName, remoteVersion, file, parts, size}
  function _installActionRow(r, btnLabel) {
    var actionRow = el('div', '');
    actionRow.style.cssText = 'margin-top:8px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;';
    var urls = _updateUrls(r.file);
    var hasParts = !!(r.parts && r.parts.length);
    // 分卷包没有可手动下载的整文件, 人工通道指向 GitHub Releases 页(挂完整包)
    var fallbackUrl = '';
    if (hasParts) {
      var cfg2 = _rules() && _rules().update;
      if (cfg2 && cfg2.user) fallbackUrl = 'https://github.com/' + cfg2.user + '/' + cfg2.repo + '/releases';
    } else if (urls.length) {
      fallbackUrl = urls[0];
    }
    var statusEl = el('span', 'susato-mod-desc', '');
    if (_canInstall() && urls.length) {
      var inst = el('a', 'susato-link-btn susato-btn-apply', btnLabel || '下载并安装');
      inst.style.cssText += 'padding:5px 14px;font-size:12px;';
      inst.onclick = function () { _startInstall(r, inst, statusEl); };
      actionRow.appendChild(inst);
    }
    if (fallbackUrl) {
      var dl = el('span', 'susato-link', hasParts ? '到 Releases 页手动下载' : '浏览器下载');
      dl.style.cssText += 'font-size:12px;';
      dl.onclick = function () { window.open(fallbackUrl, '_blank'); };
      actionRow.appendChild(dl);
    }
    actionRow.appendChild(statusEl);
    return actionRow;
  }

  function _renderUpdateContent(root, state) {
    root.innerHTML = '';

    // 顶部操作栏
    var topBar = el('div', 'susato-card-header');
    topBar.style.cssText += 'margin-bottom:12px;';
    var recheckBtn = el('span', 'susato-link', '检查更新');
    recheckBtn.style.cssText += 'font-size:13px;';
    recheckBtn.onclick = function () { _startUpdateCheck(root); };
    topBar.appendChild(recheckBtn);
    if (state.status === 'ok' && state.fetchUrl) {
      var srcLabel = el('span', 'susato-badge', '数据源: CDN');
      topBar.appendChild(srcLabel);
    }
    root.appendChild(topBar);

    // 已装更新待刷新提示条(常驻隐藏, 安装成功后亮出)
    var reloadBar = el('div', 'susato-card susato-card-ok');
    reloadBar.id = 'susato-update-reloadbar';
    reloadBar.style.cssText += 'display:' + (_pendingReload ? '' : 'none') + ';';
    var rbRow = el('div', 'susato-card-header');
    rbRow.style.cssText += 'margin-bottom:0;';
    rbRow.appendChild(el('span', '', '更新已写入本地存储, 刷新页面后生效。刷新前建议先在游戏内存档。'));
    var rbBtn = el('a', 'susato-link-btn susato-btn-apply', '立即刷新');
    rbBtn.style.cssText += 'padding:5px 14px;font-size:12px;flex-shrink:0;';
    rbBtn.onclick = function () { try { location.reload(); } catch (e) {} };
    rbRow.appendChild(rbBtn);
    reloadBar.appendChild(rbRow);
    root.appendChild(reloadBar);

    if (state.status === 'loading') {
      var loadBox = el('div', 'susato-empty');
      loadBox.innerHTML = '<span class="susato-spinner"></span> 正在检查更新……';
      root.appendChild(loadBox);
      return;
    }

    if (state.status === 'error') {
      var errBox = el('div', 'susato-err-card');
      errBox.appendChild(el('div', 'susato-card-title susato-log-err', '检查失败'));
      errBox.appendChild(el('div', '', state.errorMsg || '未知错误'));
      if (state.errorDetail) errBox.appendChild(el('div', 'susato-mod-desc', state.errorDetail));
      root.appendChild(errBox);
      root.appendChild(el('div', 'susato-mod-desc', '请确认 GitHub 仓库已创建且 versions.json 已推送。国内用户如遇 jsDelivr 不可达, 约 5 分钟后重试(CDN 回源延迟)。'));
      return;
    }

    var updated = [], same = [];
    var resultsArr = state.results || [];
    for (var i = 0; i < resultsArr.length; i++) {
      if (resultsArr[i].isNewer) updated.push(resultsArr[i]);
      else same.push(resultsArr[i]);
    }

    if (updated.length) {
      var uTitle = el('div', 'susato-card-title susato-log-warn');
      uTitle.style.cssText += 'margin-bottom:8px;';
      uTitle.textContent = '可更新 (' + updated.length + ')';
      root.appendChild(uTitle);
      for (var u = 0; u < updated.length; u++) {
        root.appendChild(_buildModCard(updated[u], true, state.baseUrl));
      }
      if (!_canInstall()) {
        root.appendChild(el('div', 'susato-mod-desc', '当前环境不支持一键安装(缺 ModLoader IndexDB 接口), 请用浏览器下载 zip 后经 Mod Loader 管理器安装。'));
      }
    } else if (resultsArr.length) {
      var okMsg = el('div', 'susato-empty');
      okMsg.style.cssText += 'color:var(--green,#4a4);';
      okMsg.textContent = '全部 mod 均为最新版本。';
      root.appendChild(okMsg);
    } else {
      root.appendChild(el('div', 'susato-empty', '未在清单中找到已安装的 mod。'));
    }

    if (same.length) {
      var sTitle = el('div', 'susato-card-title');
      sTitle.style.cssText += 'margin:14px 0 8px;';
      sTitle.textContent = '已是最新 (' + same.length + ')';
      root.appendChild(sTitle);
      for (var s = 0; s < same.length; s++) {
        root.appendChild(_buildModCard(same[s], false, state.baseUrl));
      }
    }

  }

  // ---------------- 清单缓存(更新页+下载页共用, 免双拉) ----------------
  var _manifestCache = null; // {manifest, installedNames, baseUrl, store, ts}
  function _clearManifestCache() { _manifestCache = null; }
  function _fetchManifest() {
    var mods = _snapshot();
    var rules = _rules();
    var cfg = rules && rules.update;
    if (!cfg || !cfg.user || cfg.user === 'YOUR_GITHUB_USER') return Promise.reject(new Error('仓库未配置'));
    if (!mods) return Promise.reject(new Error('ModLoader 接口不可用'));
    // 60s 内复用
    if (_manifestCache && _manifestCache.ts && Date.now() - _manifestCache.ts < 60000) return Promise.resolve(_manifestCache);
    return _fetchFirst(cfg.urls(cfg.manifestFile)).then(function (result) {
      var manifest = _parseManifest(result.text);
      if (!manifest) throw new Error('versions.json 格式无效');
      var modsMap = manifest.mods;
      var installedNames = [];
      var installedVersions = {};
      for (var i = 0; i < mods.length; i++) {
        installedNames.push(mods[i].name);
        installedVersions[mods[i].name] = mods[i].version;
      }
      var base = result.url.replace(/\/[^/]*$/, '/');
      _manifestCache = { manifest: manifest, installedNames: installedNames, baseUrl: base, store: computeStore(modsMap, installedNames, getModsOff(), installedVersions), ts: Date.now() };
      return _manifestCache;
    });
  }

  // ---------------- 下载页签(独页; 清单缓存复用) ----------------
  function _renderShopContent(root, state) {
    root.innerHTML = '';
    if (state.status === 'loading') {
      var loadBox = el('div', 'susato-empty');
      loadBox.innerHTML = '<span class="susato-spinner"></span> 正在拉取仓库清单……';
      root.appendChild(loadBox);
      return;
    }
    if (state.status === 'error') {
      var errBox = el('div', 'susato-err-card');
      errBox.appendChild(el('div', 'susato-card-title susato-log-err', '检查失败'));
      errBox.appendChild(el('div', '', state.errorMsg || '未知错误'));
      root.appendChild(errBox);
      return;
    }
    if (!state.store || !state.store.length) {
      root.appendChild(el('div', 'susato-empty', '仓库里暂无可安装的 mod。'));
      return;
    }
    root.appendChild(el('div', 'susato-mod-desc', '仓库全部 mod 都在这里: 没装的可安装, 已装的可重新下载(修复本地损坏/重装当前版)。安装写入本地存储, 刷新生效; 新装 mod 排在加载列表末尾。'));
    for (var g = 0; g < state.store.length; g++) {
      var grp = state.store[g];
      var gh = el('div', 'susato-badge');
      gh.style.cssText += 'display:inline-block;margin:10px 0 6px;';
      gh.textContent = grp.group + ' (' + grp.list.length + ')';
      root.appendChild(gh);
      for (var m2 = 0; m2 < grp.list.length; m2++) {
        root.appendChild(_buildStoreCard(grp.list[m2], state.installedNames || []));
      }
    }
  }

  function _startShopCheck(root) {
    _clearManifestCache();
    _renderShopContent(root, { status: 'loading' });
    var rules = _rules();
    var cfg = rules && rules.update;
    if (!cfg || !cfg.user || cfg.user === 'YOUR_GITHUB_USER') {
      _renderShopContent(root, { status: 'error', errorMsg: '仓库未配置', errorDetail: '请在 rules.js 中填写 GitHub 用户名与仓库名后重试。' });
      return;
    }
    _fetchManifest().then(function (cache) {
      _renderShopContent(root, { status: 'ok', store: cache.store, installedNames: cache.installedNames });
    }).catch(function (err) {
      _renderShopContent(root, { status: 'error', errorMsg: (err && err.message) || String(err) });
    });
  }

  // 下载页卡片: 全量清单条目(已装可重下, 停用中标注)
  function _buildStoreCard(item, installedNames) {
    var entry = item.entry;
    var info = (entry.versions && entry.versions[entry.latest]) || {};
    var card = el('div', 'susato-update-card susato-update-current');
    var hdr = el('div', 'susato-card-header');
    hdr.appendChild(el('span', 'susato-card-title', item.name));
    if (item.off) hdr.appendChild(el('span', 'susato-badge', '已停用'));
    else if (item.installed) hdr.appendChild(el('span', 'susato-badge susato-badge-gold', '已装 v' + (item.localVersion || '?')));
    var meta = 'v' + entry.latest + (info.size ? '  ' + _formatSize(info.size) : '');
    hdr.appendChild(el('span', 'susato-badge', meta));
    card.appendChild(hdr);
    if (entry.description) {
      var desc = el('div', 'susato-mod-desc');
      desc.style.cssText = 'margin:2px 0 4px;';
      desc.textContent = entry.description;
      card.appendChild(desc);
    }
    if (info.changes) {
      var ch = el('div', '');
      ch.style.cssText = 'font-size:12px;margin:2px 0;';
      ch.textContent = info.changes;
      card.appendChild(ch);
    }
    if (!item.installed) {
      var miss = missingDeps(entry, installedNames);
      if (miss.length) {
        card.appendChild(el('div', 'susato-mod-warn', '需要先装: ' + miss.join(' / ') + ' (可在本页一并安装, 装完统一刷新)'));
      }
    }
    if (item.off) {
      card.appendChild(el('div', 'susato-mod-desc', '此 mod 处于停用状态, 重装后仍停用, 到开关页打开。'));
    }
    card.appendChild(_installActionRow({
      modName: item.name,
      remoteVersion: entry.latest,
      file: info.file || '',
      parts: info.parts || null,
      size: info.size || 0,
    }, item.installed ? '重新下载安装' : '下载并安装'));
    return card;
  }

  function _buildModCard(r, isUpdate, baseUrl) {
    var card = el('div', isUpdate ? 'susato-update-card' : 'susato-update-card susato-update-current');
    // header row
    var hdr = el('div', 'susato-card-header');
    hdr.appendChild(el('span', 'susato-card-title', r.modName));
    var verSpan = el('span', 'susato-badge' + (isUpdate ? ' susato-badge-gold' : ''));
    verSpan.textContent = 'v' + r.localVersion + (isUpdate ? ' → v' + r.remoteVersion : '');
    hdr.appendChild(verSpan);
    card.appendChild(hdr);
    // details
    if (r.date) {
      var detail = el('div', 'susato-mod-desc');
      detail.textContent = '发布日期: ' + r.date + (r.size ? '  |  大小: ' + _formatSize(r.size) : '');
      card.appendChild(detail);
    }
    if (r.changes) {
      var changes = el('div', '');
      changes.style.cssText = 'font-size:12px;margin:4px 0;';
      changes.textContent = r.changes;
      card.appendChild(changes);
    }
    if (r.compareFailed) {
      card.appendChild(el('div', 'susato-mod-desc susato-log-warn', '版本比对降级为字符串比较'));
    }
    // 安装/下载操作行
    if (isUpdate && r.file) {
      card.appendChild(_installActionRow(r));
    }
    return card;
  }

  function _startUpdateCheck(root) {
    root.innerHTML = '';
    var loadBox = el('div', 'susato-empty');
    loadBox.innerHTML = '<span class="susato-spinner"></span> 正在检查更新……';
    root.appendChild(loadBox);

    var rules = _rules();
    var cfg = rules && rules.update;
    if (!cfg || !cfg.user || cfg.user === 'YOUR_GITHUB_USER') {
      _renderUpdateContent(root, { status: 'error', errorMsg: '仓库未配置', errorDetail: '请在 rules.js 中填写 GitHub 用户名与仓库名后重试。' });
      return;
    }

    var mods = _snapshot();
    if (!mods) { _renderUpdateContent(root, { status: 'error', errorMsg: 'ModLoader 接口不可用, 无法读取已装 mod 列表。' }); return; }

    var urls = cfg.urls(cfg.manifestFile);
    _fetchFirst(urls).then(function (result) {
      var manifest = _parseManifest(result.text);
      if (!manifest) { _renderUpdateContent(root, { status: 'error', errorMsg: 'versions.json 格式无效', errorDetail: '已成功获取但无法解析为合法 JSON, 请检查清单文件。' }); return; }

      var results = [];
      var modsMap = manifest.mods;
      var installedNames = [];
      for (var i = 0; i < mods.length; i++) {
        installedNames.push(mods[i].name);
        var entry = modsMap[mods[i].name];
        if (!entry) continue;
        var cmp = _compareOne(mods[i].version, entry);
        if (cmp) { cmp.modName = mods[i].name; results.push(cmp); }
      }

      var base = result.url.replace(/\/[^/]*$/, '/');
      _renderUpdateContent(root, {
        status: 'ok', fetchUrl: result.url, manifest: manifest, results: results, baseUrl: base,
      });
    }).catch(function (err) {
      var msg = err && err.message ? err.message : String(err);
      var detail = '';
      if (msg.indexOf('abort') >= 0 || msg.indexOf('timeout') >= 0) detail = '请求超时(' + (UPDATE_FETCH_TIMEOUT / 1000) + 's), 网络可能不通。';
      else if (msg.indexOf('fetch') >= 0 || msg.indexOf('NetworkError') >= 0) detail = '网络请求失败, 请检查网络连接。';
      else if (msg.indexOf('全部更新源不可达') >= 0) detail = 'jsDelivr 与 raw GitHub 均不可达, 请确认仓库存在且文件已推送。';
      _renderUpdateContent(root, { status: 'error', errorMsg: msg, errorDetail: detail });
    });
  }

  function renderUpdate(root) {
    root.innerHTML = '';
    var rules = _rules();
    var cfg = rules && rules.update;
    if (!cfg || !cfg.user || cfg.user === 'YOUR_GITHUB_USER') {
      var box = el('div', 'susato-card');
      box.appendChild(el('div', 'susato-card-title', '仓库待配置'));
      box.appendChild(el('div', '', '联网更新通过 GitHub + jsDelivr CDN 分发。'));
      var steps = el('ol', 'susato-step-list');
      steps.style.cssText += 'margin-top:8px;';
      var stepsData = [
        '创建 GitHub 仓库, 上传 mod zip 包与 versions.json',
        '编辑 rules.js 的 update.user / update.repo 字段',
        '重新打包管理器 zip 并安装'
      ];
      for (var i = 0; i < stepsData.length; i++) {
        steps.appendChild(el('li', '', stepsData[i]));
      }
      box.appendChild(steps);
      root.appendChild(box);
      root.appendChild(el('div', 'susato-mod-desc', 'versions.json 格式请参考 .date 开发文档。'));
      return;
    }
    _startUpdateCheck(root);
  }

  function renderShop(root) {
    root.innerHTML = '';
    var rules = _rules();
    var cfg = rules && rules.update;
    if (!cfg || !cfg.user || cfg.user === 'YOUR_GITHUB_USER') {
      var box = el('div', 'susato-card');
      box.appendChild(el('div', 'susato-card-title', '仓库待配置'));
      box.appendChild(el('div', '', '下载页需先在 rules.js 配置 GitHub 仓库(与更新页同一配置)。'));
      root.appendChild(box);
      return;
    }
    _startShopCheck(root);
  }

  // ---------------- 感谢页签 ----------------
  function renderCredits(root) {
    root.innerHTML = '';
    var card = el('div', 'susato-card');
    var lead = el('div', '');
    lead.style.cssText = 'font-size:13px;margin-bottom:12px;';
    lead.textContent = '非常感谢所有在此过程中帮助过我的人，同时希望各位能够友好交流、享受游戏。';
    card.appendChild(lead);
    var pre = el('div', '');
    pre.style.cssText = 'font-family:monospace;font-size:12px;line-height:1.75;white-space:pre-wrap;color:var(--400,#a1a1aa);';
    pre.textContent = [
      'CREDITS',
      '//  画家K — 架构 & 核心代码 & 重构',
      '//  Yisic, 画家K, Cicero, 小鼹鼠, Ki, 冰, 枯木枝修, Phantalis — 贴图 & 测试 & 反馈',
      '// ==================================================================',
      '//',
      '//  发现，珍宝总是易逝，',
      '//  欢愉与狂怒交织——我正注视着你。',
      '//  今夜，请小心你的一举一动。',
      '//  我想时机已到，我想鲜血已经凝固，',
      '//  它仍在渴求更多。那我们还在等什么？',
      '//',
      '//  线缆与锁链（我只是厌倦了视而不见），',
      '//  开始褪色消散（我只是厌倦了视而不见），',
      '//  感觉像一场游戏（我只是厌倦了视而不见），',
      '//  你必须入局（我只是厌倦了视而不见）。',
      '//',
      '//  熄灯。这才是真实的你吗？',
      '//  无法直视你的双眼，你那扭曲的心智。',
      '//  好暗，如此黑暗。我们就在此了结，就在此地，此刻。',
      '//  请告诉我你带了家伙，',
      '//  让我们把夜空点燃，再消逝于长夜。',
      '//',
      '//  那些曾经美好的日子已然远逝，',
      '//  我试着看清这一切究竟为何，却永远无法得知。',
      '//  尽管它已死去，我仍听见那召唤。',
      '//',
      '//  线缆与锁链，开始褪色消散，',
      '//  感觉像一场游戏，你无法逃脱。',
      '//',
      '//  我终于发现：珍宝总是易逝。',
      '//  欢愉早已被遗忘。如今的你，究竟是谁？',
      '//',
    ].join('\n');
    card.appendChild(pre);
    root.appendChild(card);
  }

  // ---------------- 面板入口 ----------------

  var TABS = [
    { id: 'diag', name: '诊断', render: renderDiag },
    { id: 'modules', name: '模块开关', render: renderModules },
    { id: 'update', name: '更新', render: renderUpdate },
    { id: 'shop', name: '下载', render: renderShop },
    { id: 'credits', name: '感谢', render: renderCredits },
  ];

  SM.manager = {
    render: function (rootId) {
      // 先尝试 getElementById, 失败则 querySelector, 再失败则向 body 追加(容器不存在时自己造)
      var host = document.getElementById(rootId);
      if (!host) {
        try { host = document.querySelector('#' + rootId); } catch (e) {}
      }
      if (!host) {
        // 容器还没进 DOM (极少见的 SugarCube 渲染时序问题), 自己建一个追加到面板
        try {
          host = document.createElement('div');
          host.id = rootId;
          var panelRoot = document.getElementById('susato-manager-root');
          if (panelRoot) { panelRoot.appendChild(host); }
          else { (document.body || document.documentElement).appendChild(host); }
        } catch (e) { return; }
      }
      host.innerHTML = '';

      try {
        _injectStyles();
        _initToast();

        var body = el('div', '');
        var current = 'diag';

        function show(tabId) {
          current = tabId;
          body.innerHTML = '';
          // 直接查找对应 tab 的 render 函数(避免 filter+forEach 可能的兼容问题)
          var found = null;
          for (var i = 0; i < TABS.length; i++) {
            if (TABS[i].id === tabId) { found = TABS[i]; break; }
          }
          if (found) {
            try { found.render(body); } catch (e) { body.appendChild(el('div', 'susato-err-card', '渲染出错: ' + e.message)); }
          } else {
            body.appendChild(el('div', 'susato-empty', '未知页签'));
          }
          var tabBar = host.querySelector('.susato-tab-bar');
          if (tabBar) _setActiveTab(tabBar, tabId);
        }

        _renderTabBar(host, TABS, current, show);
        host.appendChild(body);
        show(current);
      } catch (e) {
        host.appendChild(el('div', 'susato-err-card', '管理器初始化异常: ' + (e.message || e)));
      }
    },
    toast: toast,
    // 仿真与调试用
    _evalRules: evalRules,
    _evalDeps: evalDeps,
    _snapshot: _snapshot,
    _getOff: getOff,
    _setOff: setOff,
    _getModsOff: getModsOff,
    _setModsOff: setModsOff,
    _computeModRows: computeModRows,
    _dependentsOf: dependentsOf,
    _installFromBytes: _installFromBytes,
    _fetchZipFirst: _fetchZipFirst,
    _downloadAllParts: _downloadAllParts,
    _updateUrls: _updateUrls,
    _canInstall: _canInstall,
    _computeStore: computeStore,
    _missingDeps: missingDeps,
    _clearBSACacheAndReload: _clearBSACacheAndReload,
    _installLocalBytes: _installLocalBytes,
    _compareOne: _compareOne,
    _uninstallMod: _uninstallMod,
    _canUninstall: _canUninstall,
  };
})();
