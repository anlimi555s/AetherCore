// ==================================================================
//  stacking-core 3.0.0 — 时装系统数据层
//  叠层数据结构: V.worn_layers[slot] = [clothingItem, ...]
//  物品从衣柜 clone 进入叠层, 主装备(V.worn)不受影响。
//
//  API (挂 SusatoModel.clothingLayers, 与旧版时装系统兼容):
//    SusatoModel.clothingLayers.removeAll()          — 全部叠层送回衣柜
//    SusatoModel.clothingLayers.removeAt(slot, pos)  — 移除指定叠层
//    SusatoModel.clothingLayers.toggleHidden(slot, pos)       — 显隐单层
//    SusatoModel.clothingLayers.togglePrimaryHidden(slot)     — 显隐主装备
//    SusatoModel.clothingLayers.getCount(slot)       — 槽位层数
//    SusatoModel.clothingLayers.getTotalCount()      — 总层数
//    SusatoModel.clothingLayers.getSignature(slot)   — 叠层状态签名(渲染层脏检测)
//    SusatoModel.clothingLayers.getBodySignature()   — 体型签名(合成图失效判定)
//    SusatoModel.clothingLayers.isEnabled()          — 开关状态
//
//  依赖: 无 (纯数据层, storyready 初始化)
//  消费方: stacking-renderer.js, stacking-outfit.js, twee UI
// ==================================================================
(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('stacking-core')) return;

  window.SusatoModel = window.SusatoModel || {};
  var SL = window.SusatoModel.clothingLayers = window.SusatoModel.clothingLayers || {};

  // 全部衣物槽位 (与本体 setup.clothingLayer.all 一致)
  var ALL_SLOTS = [
    'upper', 'lower', 'under_upper', 'under_lower',
    'over_upper', 'over_lower', 'head', 'over_head',
    'face', 'neck', 'hands', 'handheld', 'legs', 'feet'
  ];
  SL.ALL_SLOTS = ALL_SLOTS;

  // ========== 初始化 ==========
  function init() {
    if (typeof V === 'undefined') return;
    if (!V.worn_layers || typeof V.worn_layers !== 'object') V.worn_layers = {};
    ALL_SLOTS.forEach(function (s) {
      if (!Array.isArray(V.worn_layers[s])) V.worn_layers[s] = [];
    });
  }
  SL.init = init;

  // ========== 数据 API ==========
  SL.removeAll = function () {
    if (typeof V === 'undefined' || !V.worn_layers) return;
    Object.keys(V.worn_layers).forEach(function (slot) {
      var layers = V.worn_layers[slot];
      if (!Array.isArray(layers) || !layers.length) return;
      for (var i = layers.length - 1; i >= 0; i--) {
        if (layers[i]) {
          if (!V.wardrobe[slot]) V.wardrobe[slot] = [];
          V.wardrobe[slot].push(layers[i]);
        }
      }
      V.worn_layers[slot] = [];
    });
  };

  SL.removeAt = function (slot, pos) {
    try {
      var layers = V.worn_layers[slot];
      if (!layers || pos < 0 || pos >= layers.length) return null;
      var item = layers[pos];
      if (!V.wardrobe[slot]) V.wardrobe[slot] = [];
      V.wardrobe[slot].push(item);
      layers.splice(pos, 1);
      return item;
    } catch (e) { return null; }
  };

  SL.toggleHidden = function (slot, pos) {
    try {
      var layers = V.worn_layers[slot];
      if (!layers || pos < 0 || pos >= layers.length) return;
      layers[pos]._hidden = !layers[pos]._hidden;
    } catch (e) {}
  };

  SL.togglePrimaryHidden = function (slot) {
    try {
      var item = V.worn[slot];
      if (!item || item.index === 0) return;
      item._hidden = !item._hidden;
    } catch (e) {}
  };

  SL.getCount = function (slot) {
    var layers = V.worn_layers && V.worn_layers[slot];
    return layers ? layers.length : 0;
  };

  SL.getTotalCount = function () {
    var n = 0;
    try {
      if (V.worn_layers) Object.keys(V.worn_layers).forEach(function (s) {
        var a = V.worn_layers[s];
        if (Array.isArray(a)) n += a.length;
      });
    } catch (e) {}
    return n;
  };

  SL.isEnabled = function () {
    try { return !!V.susato_layering_enabled; } catch (e) { return false; }
  };

  // ========== 状态签名 (渲染层脏检测) ==========
  // 叠层数据变化 (穿/脱/染色/隐藏) 都会改变签名。
  // 渲染层对比签名, 变了才重新离屏合成, 不变直接用缓存图。
  SL.getSignature = function (slot) {
    try {
      var items = V.worn_layers && V.worn_layers[slot];
      if (!Array.isArray(items) || !items.length) return '';
      return items.map(function (it) {
        if (!it) return '';
        return [
          it.name, it.colour, it.accessory_colour, it.pattern,
          it.integrity, it.alt, it.altposition, it.hoodposition,
          it._hidden ? 'h' : 'v'
        ].join('|');
      }).join(',');
    } catch (e) { return ''; }
  };

  // 体型签名: 衣服子图层图依赖这些状态, 变了合成图要重算
  SL.getBodySignature = function () {
    try {
      return [
        V.breast_size, V.bodyshape, V.arm_type,
        V.preg_type || 0, V.skin_type || '',
        V.belly || 0, V.bellyTucked || 0
      ].join('|');
    } catch (e) { return ''; }
  };

  // ========== 启动 ==========
  if (typeof $ !== 'undefined') {
    $(document).one(':storyready', init);
  } else {
    init();
  }
})();
