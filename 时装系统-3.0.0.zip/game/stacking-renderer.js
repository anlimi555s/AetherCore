// ==================================================================
//  stacking-renderer 3.0.0 — 时装系统渲染层 (逐层合成缓存 + 原版 z)
//
//  ──────────────────────────────────────────────────────────────
//  愚不可及的v，你要是再这样不管社区的更新下去，
//  谁他妈有这么多时间和精力一起跑更新。
//  ──────────────────────────────────────────────────────────────
//
//  原理: 叠层衣服走一遍原版渲染管线, 之后固定——
//    1. 叠层数据变化时, 离屏 CanvasModel (CanvasModel.create('main', 槽位))
//       以"叠层衣服"为 worn 跑 compile(含全部 mod 钩子), 得到该槽位
//       子图层列表, 每个图层的 z/src/show 都是原版求值结果
//    2. 每个子图层【独立】用 composeLayers 合成一张缓存图, 保留该层原版 z
//    3. 主立绘每帧: 把缓存图层(带原版 z + 0.02 微偏移)作为独立图层追加
//       —— 每帧只是贴图, 不重算渲染; 只有换衣/染色/体型变化才重算
//
//  与旧版(每帧深拷贝子图层+改共享 options)的区别:
//    - 合成一次缓存, 每帧贴图(性能优于旧版每帧求值)
//    - 不修改主渲染的 options → 无污染
//    - z 完全用原版求出的值 → 层序永远是原版规则(含 mod z 修改)
//    - 颜色在离屏 options 独立生成 → custom 染色正常, 不丢色
//
//  注意: 逐层合成时 blend 混合缺参照层(极少数透明层可能轻微偏差),
//  绝大多数衣服图层是 normal 模式, 不影响。
//
//  依赖: susato-core.js (renderer.onCompile), stacking-core.js (数据+签名)
// ==================================================================
(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('stacking-renderer')) return;

  window.SusatoModel = window.SusatoModel || {};
  var SL = window.SusatoModel.clothingLayers = window.SusatoModel.clothingLayers || {};
  var SR = window.SusatoModel.renderer;

  var MAX_RETRY = 3;            // 同签名缺图重试上限 (防死循环)
  var Z_OFFSET = 0.02;          // 叠层相对原版 z 的微偏移 (避免与原版同 z 图层 z-fight)

  // ========== 内部状态 ==========
  var _synthBusy = false;       // 防递归: 离屏 compile 会重入 onCompile 钩子
  var _retryTimer = null;
  var _retryCount = 0;
  var _mainModel = null;        // 主立绘实例 (钩子里记录, retry 时 redraw 用)
  // 缓存结构: _cache[slot] = {sig, bodySig, layers: [{name, z, canvas, show}]}
  var _cache = {};

  // ========== 工具 ==========
  function imageToCanvas(img) {
    try {
      var c = Renderer.createCanvas(img.naturalWidth || img.width, img.naturalHeight || img.height);
      c.drawImage(img, 0, 0);
      return c.canvas;
    } catch (e) { return null; }
  }

  // ========== 离屏合成 (逐层, 保留原版 z) ==========
  // slot: 槽位, item: 叠层物品, mainOptions: 主渲染当前帧 options, cb: (layers|null)
  // 返回: [{name, z, canvas, show}] 每个子图层一张缓存图
  function synthesize(slot, item, mainOptions, cb) {
    try {
      var offModel = CanvasModel.create('main', 'stacking_off_' + slot);
      if (!offModel || offModel.name === 'empty') { cb(null); return; }

      // 重置离屏 model 图层状态 (防上次合成残留 show/src/image)
      if (typeof offModel.reset === 'function') offModel.reset();

      // 独立 options: 主渲染 options 副本, 仅替换该槽位 worn
      var wornEntry = window.getClothingOptionsItem ? window.getClothingOptionsItem(slot, item) : null;
      if (!wornEntry || !wornEntry[slot]) { cb(null); return; }
      var offOptions = Object.assign({}, mainOptions || {});
      offOptions.worn = Object.assign({}, (mainOptions && mainOptions.worn) || {}, wornEntry);
      offOptions.filters = Object.assign({}, (mainOptions && mainOptions.filters) || {});

      // 该槽位颜色 filter 独立重建 (不继承主装备的配置)
      // 预设色: 用 generateClothingFilter 按叠层物品的 colour 字段生成
      // custom 色: 预置 worn_slot_custom 供 lookupColour 读取
      try {
        var slotItem = wornEntry[slot];
        if (typeof window.generateClothingFilter === 'function') {
          offOptions.filters['worn_' + slot] = window.generateClothingFilter(offOptions, slot, slotItem);
        }
        if (typeof window.generateClothingAccFilter === 'function') {
          offOptions.filters['worn_' + slot + '_acc'] = window.generateClothingAccFilter(offOptions, slot, slotItem);
        }
        if (typeof getCustomClothesColourCanvasFilter === 'function') {
          if (slotItem.colour === 'custom') {
            offOptions.filters['worn_' + slot + '_custom'] =
              item.colourCanvasFilter || getCustomClothesColourCanvasFilter(item.colourCustom);
          }
          if (slotItem.accColour === 'custom') {
            offOptions.filters['worn_' + slot + '_acc_custom'] =
              item.accessory_colourCanvasFilter || getCustomClothesColourCanvasFilter(item.accessory_colourCustom);
          }
        }
      } catch (e) {}

      // 借原版 compile (离屏 model 图层深拷贝, 污染安全; 钩子对离屏同样生效)
      _synthBusy = true;
      var specs;
      try {
        specs = offModel.compile(offOptions);
      } finally {
        _synthBusy = false;
      }
      if (!Array.isArray(specs)) { cb(null); return; }

      // 只留该槽位的子图层
      specs = specs.filter(function (l) {
        return l && (l.name === slot || (l.name && l.name.indexOf(slot + '_') === 0));
      });
      if (!specs.length) { cb(null); return; }

      // 逐层独立合成: 每层一张图 + 原版 z
      var outLayers = [];
      var missing = 0;
      for (var i = 0; i < specs.length; i++) {
        var l = specs[i];
        if (!l || l.show === false) continue;   // 原版判定不显示的层不合成
        if (!l.src) continue;

        // src/masksrc → canvas (同步路径); 缺图保留 URL 异步, 计入 missing
        l.image = null;
        l.mask = null;
        var cachedImg = Renderer.ImageCaches && Renderer.ImageCaches[l.src];
        if (cachedImg) {
          var c = imageToCanvas(cachedImg);
          if (c) { l.src = c; } else { missing++; continue; }
        } else {
          missing++;
        }
        if (l.masksrc && typeof l.masksrc !== 'object' && Renderer.ImageCaches && Renderer.ImageCaches[l.masksrc]) {
          var mci = imageToCanvas(Renderer.ImageCaches[l.masksrc]);
          if (mci) l.masksrc = mci;
        }

        // 每层单独合成 (若该层有 mask/缺口, compose 内部处理)
        var one = [l];
        if (typeof Renderer.composeLayers === 'function') {
          var target = Renderer.createCanvas(offModel.width, offModel.height);
          Renderer.composeLayers(target, one, 1, null);
          var canvasObj = target.canvas;
          if (canvasObj && canvasObj.width > 0) {
            outLayers.push({ name: l.name, z: l.z, canvas: canvasObj, show: true });
          }
        } else {
          continue;
        }
      }

      if (missing > 0) scheduleRetry();
      cb(outLayers.length ? outLayers : null);
    } catch (e) {
      try { console.warn('[stacking-renderer] synthesize(' + slot + '): ' + (e.message || e)); } catch (e2) {}
      cb(null);
    }
  }

  // ========== 重试 ==========
  function scheduleRetry() {
    if (_retryTimer) return;
    _retryTimer = setTimeout(function () {
      _retryTimer = null;
      _retryCount++;
      if (_retryCount > MAX_RETRY) { _retryCount = 0; return; }
      _cache = {};
      try {
        if (_mainModel && typeof _mainModel.redraw === 'function') _mainModel.redraw();
      } catch (e) {}
      _retryCount = 0;
    }, 150);
  }

  // ========== 渲染钩子 ==========
  if (!SR || !SR.onCompile) return;

  SR.onCompile(function (specs, options, model) {
    if (_synthBusy) return specs;                          // 离屏合成中的递归 compile
    if (!model || model.name !== 'main') return specs;     // 只处理主立绘
    if (!SL.isEnabled || !SL.isEnabled()) return specs;
    try {
      if (typeof V === 'undefined' || !V.worn_layers) return specs;
    } catch (e) { return specs; }

    _mainModel = model;   // 记录主立绘实例供 retry redraw

    // 主装备隐藏: 该槽位子图层 show=false (叠层此时独立显示)
    var specsOut = specs;
    SL.ALL_SLOTS.forEach(function (slot) {
      try {
        if (V.worn[slot] && V.worn[slot]._hidden) {
          specsOut = specsOut.map(function (s) {
            if (s && (s.name === slot || (s.name && s.name.indexOf(slot + '_') === 0))) {
              var copy = Object.assign({}, s);
              copy.show = false;
              return copy;
            }
            return s;
          });
        }
      } catch (e) {}
    });

    var stacked = [];

    SL.ALL_SLOTS.forEach(function (slot) {
      var items = V.worn_layers[slot];
      if (!Array.isArray(items) || !items.length) return;

      // 签名检查: 变了才重合成 (惰性)
      var sig = SL.getSignature(slot);
      var bodySig = SL.getBodySignature();
      var c = _cache[slot];
      if (!c || c.sig !== sig || c.bodySig !== bodySig) {
        _cache[slot] = { sig: sig, bodySig: bodySig, layers: [] };
        c = _cache[slot];
        for (var n = 0; n < items.length; n++) {
          (function (slot, n) {
            var it = items[n];
            if (!it || it._hidden) return;
            synthesize(slot, it, options, function (outLayers) {
              var cc = _cache[slot];
              if (!cc) return;
              cc.layers[n] = outLayers || null;
            });
          })(slot, n);
        }
      }

      // 构造独立图层追加进本帧渲染列表
      // 每层: z = 原版 z + 0.02 + 叠层序号*0.01
      var layerSets = c.layers || [];
      for (var k = 0; k < items.length; k++) {
        var item = items[k];
        if (!item || item._hidden) continue;
        var outLayers = layerSets[k];
        if (!Array.isArray(outLayers) || !outLayers.length) continue;
        for (var gi = 0; gi < outLayers.length; gi++) {
          var ol = outLayers[gi];
          if (!ol || !ol.canvas) continue;
          var oz = (typeof ol.z === 'number') ? ol.z : 100;
          stacked.push({
            name: 'stack_' + slot + '_' + k + '_' + gi,
            src: ol.canvas,
            z: oz + Z_OFFSET + k * 0.01,
            show: true,
            filters: [],
            animation: ''
          });
        }
      }
    });

    if (!stacked.length) return specsOut;
    return specsOut.concat(stacked);
  });
})();
