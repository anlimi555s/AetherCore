// ==================================================================
//  stacking-outfit 3.0.0 — 时装系统套装存取 (含颜色/图案)
//  旧版只存 name, 恢复后颜色丢失——本版存完整外观字段。
//
//  存档格式:
//    { slot: [{n: name, c: colour, ac: accessory_colour, p: pattern, h: hidden}] }
//  兼容旧格式:
//    { slot: ["name1", "name2"] }  → 恢复时沿用衣柜里物品自带颜色
//
//  API:
//    SusatoModel.clothingLayers.getStackingOutfit()  — 序列化当前叠穿方案
//    SusatoModel.clothingLayers.restoreStacking(data) — 恢复方案 (含颜色覆盖)
//
//  依赖: stacking-core.js (数据层)
//  消费方: twee/outfit-save.twee, twee/outfit-load.twee
// ==================================================================
(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('stacking-outfit')) return;

  window.SusatoModel = window.SusatoModel || {};
  var SL = window.SusatoModel.clothingLayers = window.SusatoModel.clothingLayers || {};
  var ALL_SLOTS = SL.ALL_SLOTS || [];

  // ========== 序列化 ==========
  // 每层存: 名字 + 颜色 + 配件色 + 图案 + 隐藏标记
  SL.getStackingOutfit = function () {
    var stacking = {};
    try {
      if (!V.worn_layers) return stacking;
      Object.keys(V.worn_layers).forEach(function (slot) {
        var items = V.worn_layers[slot];
        if (!Array.isArray(items) || items.length === 0) return;
        stacking[slot] = items.map(function (item) {
          if (!item || !item.name) return null;
          var entry = { n: item.name };
          if (item.colour !== undefined) entry.c = item.colour;
          if (item.accessory_colour !== undefined) entry.ac = item.accessory_colour;
          if (item.pattern !== undefined && item.pattern !== 0) entry.p = item.pattern;
          if (item._hidden) entry.h = true;
          return entry;
        }).filter(function (e) { return !!e; });
      });
    } catch (e) {}
    return stacking;
  };

  // ========== 恢复 ==========
  // 当前叠层先全部回衣柜, 再从 data 按 name 找衣服 clone 进叠层。
  // 新格式: 恢复后把存档的颜色/图案覆盖到物品上 (旧版丢色问题的修复)。
  SL.restoreStacking = function (data) {
    try {
      if (!V.wardrobe) V.wardrobe = {};
      data = data || {};

      // 1. 当前叠层全部回衣柜
      if (V.worn_layers) {
        Object.keys(V.worn_layers).forEach(function (slot) {
          var layers = V.worn_layers[slot];
          if (!Array.isArray(layers)) return;
          for (var i = layers.length - 1; i >= 0; i--) {
            if (layers[i]) {
              if (!V.wardrobe[slot]) V.wardrobe[slot] = [];
              V.wardrobe[slot].push(layers[i]);
            }
          }
        });
      }
      ALL_SLOTS.forEach(function (s) {
        if (!V.worn_layers) V.worn_layers = {};
        if (!Array.isArray(V.worn_layers[s])) V.worn_layers[s] = [];
        else V.worn_layers[s] = [];
      });

      // 2. 按 data 恢复
      Object.keys(data).forEach(function (slot) {
        if (slot === '_primary') return;
        var entries = data[slot];
        if (!Array.isArray(entries) || !entries.length) return;
        if (!V.wardrobe[slot]) V.wardrobe[slot] = [];
        for (var i = 0; i < entries.length; i++) {
          var entry = entries[i];
          var itemName = typeof entry === 'string' ? entry : entry.n;   // 兼容旧格式
          var hidden = typeof entry === 'object' ? !!entry.h : false;
          var idx = -1;
          for (var j = 0; j < V.wardrobe[slot].length; j++) {
            if (V.wardrobe[slot][j] && V.wardrobe[slot][j].name === itemName) { idx = j; break; }
          }
          if (idx < 0) continue;   // 衣柜里没有这件, 跳过
          if (!V.worn_layers[slot]) V.worn_layers[slot] = [];
          var item = clone(V.wardrobe[slot][idx]);
          // 颜色/图案覆盖 (新格式)
          if (typeof entry === 'object') {
            if (entry.c !== undefined) item.colour = entry.c;
            if (entry.ac !== undefined) item.accessory_colour = entry.ac;
            if (entry.p !== undefined) item.pattern = entry.p;
          }
          if (hidden) item._hidden = true;
          V.worn_layers[slot].push(item);
          V.wardrobe[slot].splice(idx, 1);
        }
      });

      // 3. 主装备隐藏标记
      if (data._primary) {
        Object.keys(data._primary).forEach(function (slot) {
          if (V.worn[slot]) V.worn[slot]._hidden = true;
        });
      }
    } catch (e) {
      try { console.warn('[stacking-outfit] restoreStacking: ' + (e.message || e)); } catch (e2) {}
    }
  };
})();
