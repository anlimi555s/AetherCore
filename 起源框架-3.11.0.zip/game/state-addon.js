// state-addon.js — 起源框架运行时地基：变量托管 / 统一消息 / 日界调度
// 对标 economy-addon/skill-addon 家族风格。三件事的共同点：内容 mod 每次都要手写、写错就是旧档 NaN 或消息不显示。
//
// API:
//   SusatoModel.vars.define(name, defaultValue)
//     声明存档变量与默认值。storyready 与每个 passageend 幂等补齐：
//     新档自动初始化，旧档加载后自动补上缺失变量（根治"旧档新变量 undefined -> NaN"整类 bug）。
//     默认值为对象/数组时按值深拷贝，注册表不会被游戏内修改污染。
//   SusatoModel.vars.defineAll({ name: default, ... })
//
//   SusatoModel.notify(text, style)
//     在当前或下个 passage 顶部显示一行提示。style: gold(默认)/red/teal/green/blue（本体配色类名）。
//     队列存 $susatoNotices（故事变量，跨 passage 存活——link 里调用也不会丢，khMsg 的老问题）。
//   SusatoModel.notifyFlush()
//     立即渲染并清空队列（幂等）。框架自己在 passageend 会调；需要"结算后当页就显示"的消费者
//     （如 economy）在自己的 passageend 逻辑末尾再调一次即可。
//
//   SusatoModel.time.onDay(fn)
//     日界回调。跨日后的第一个 passageend 触发一次 fn(today, prevDay)；跳多天也只触发一次，
//     需要逐日补结的消费者自己按 today-prevDay 处理。时间倒流（debug）只重新对表不触发。
//
// 存档状态: $susatoNotices = [{t, c}], $susatoTimeDay = number

(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.vars) return; // load-once 守卫
  if (!SM.onInit) {
    SM._initHooks = SM._initHooks || [];
    SM.onInit = function (fn) { SM._initHooks.push(fn); };
  }

  function _V() {
    return (typeof State !== 'undefined' && State.variables) ? State.variables : null;
  }

  function _clone(v) {
    if (v === null || typeof v !== 'object') return v;
    try { return JSON.parse(JSON.stringify(v)); } catch (e) { return v; }
  }

  // ---------------- 变量托管 ----------------

  var _defs = {}; // name -> defaultValue

  function _applyVars() {
    var V = _V();
    if (!V) return;
    for (var name in _defs) {
      if (Object.prototype.hasOwnProperty.call(_defs, name) && V[name] === undefined) {
        V[name] = _clone(_defs[name]);
      }
    }
  }

  SM.vars = {
    define: function (name, defaultValue) {
      if (typeof name !== 'string' || !name.length) return;
      if (!(name in _defs)) _defs[name] = defaultValue;
      _applyVars(); // 声明即尝试应用（storyready 之后注册的也立即生效）
    },
    defineAll: function (obj) {
      if (!obj || typeof obj !== 'object') return;
      for (var k in obj) if (Object.prototype.hasOwnProperty.call(obj, k)) {
        if (!(k in _defs)) _defs[k] = obj[k];
      }
      _applyVars();
    },
    apply: _applyVars,
  };

  // ---------------- 统一消息 ----------------

  var STYLES = { gold: 1, red: 1, teal: 1, green: 1, blue: 1 };

  function _queue() {
    var V = _V();
    if (!V) return null;
    if (!Array.isArray(V.susatoNotices)) V.susatoNotices = [];
    return V.susatoNotices;
  }

  SM.notify = function (text, style) {
    var q = _queue();
    if (!q || text === undefined || text === null || text === '') return;
    q.push({ t: String(text), c: (style && STYLES[style]) ? style : 'gold' });
  };

  SM.notifyFlush = function () {
    var q = _queue();
    if (!q || !q.length) return;
    try {
      var target = document.getElementById('passage-content') ||
                   document.querySelector('.passage');
      if (!target) return;
      var box = document.createElement('div');
      for (var i = 0; i < q.length; i++) {
        var span = document.createElement('span');
        span.className = q[i].c || 'gold';
        span.textContent = q[i].t;
        box.appendChild(span);
        box.appendChild(document.createElement('br'));
      }
      box.appendChild(document.createElement('br'));
      target.insertBefore(box, target.firstChild);
      q.length = 0;
    } catch (e) {}
  };

  // ---------------- 日界调度 ----------------

  var _dayHooks = [];

  function _tickDay() {
    var V = _V();
    if (!V || V.statFreeze) return;
    if (typeof Time === 'undefined' || typeof Time.days !== 'number') return;
    var today = Time.days;
    if (typeof V.susatoTimeDay !== 'number') { V.susatoTimeDay = today; return; } // 首次对表不触发（旧档友好）
    if (today === V.susatoTimeDay) return;
    if (today < V.susatoTimeDay) { V.susatoTimeDay = today; return; } // 时间倒流只对表
    var prev = V.susatoTimeDay;
    V.susatoTimeDay = today;
    for (var i = 0; i < _dayHooks.length; i++) {
      try { _dayHooks[i](today, prev); } catch (e) {}
    }
  }

  SM.time = {
    onDay: function (fn) { if (typeof fn === 'function') _dayHooks.push(fn); },
    lastDay: function () { var V = _V(); return V ? V.susatoTimeDay : undefined; },
  };

  // ---------------- 启动 ----------------

  var _hooksSetup = false;
  function _setupHooks() {
    if (_hooksSetup || typeof $ === 'undefined') return;
    _hooksSetup = true;
    $(document).on(':passageend', function () {
      _applyVars();
      _tickDay();
      SM.notifyFlush();
    });
  }

  SM.onInit(function () {
    _applyVars();
    _setupHooks();
  });

  if (typeof $ !== 'undefined') {
    _setupHooks();
    $(document).one(':storyready', function () {
      _applyVars();
      _setupHooks();
    });
  }
})();
