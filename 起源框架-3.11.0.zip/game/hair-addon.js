// hair-addon.js — 发型运行时注册框架
// 对标 clothing-addon：一行 add() 注册自定义发型，storyready 注入 setup.hairstyles，
// 免除 ModdedHairAddon 依赖与严格 JSON 数据文件（宽松 JSON 静默失败的教训见 .date）。
//
// API:
//   SusatoModel.hair.add('fringe'|'sides', {
//     variable: 'Qian',        // 唯一标识, 也是 img/hair/{fringe|sides}/<variable>/ 文件夹名
//     name_cap: '飞仙',        // 显示名(必填)
//     type: ['short'],         // 发型类型标签(默认 ['short'])
//     shop: ['mirrorhair'],    // 出现位置(默认理发店/镜子)
//   })
//
// 图片要求: img/hair/fringe/<variable>/ 与 sides 同名目录下 short/shoulder/chest/navel/thighs/feet.png
// 注入后重算 setup.hairTraits(本体 widget 用它汇总全部发型 type, 不重算会漏掉新类型)。

(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.hair) return; // load-once 守卫

  var _queue = [];   // {section, spec}
  var _flushed = false;

  function _normalize(section, spec) {
    var item = {
      name: spec.name || spec.variable,
      name_cap: spec.name_cap || spec.variable,
      variable: spec.variable,
      type: Array.isArray(spec.type) ? spec.type : ['short'],
      shop: Array.isArray(spec.shop) ? spec.shop : ['mirrorhair'],
    };
    for (var k in spec) if (Object.prototype.hasOwnProperty.call(spec, k) && !(k in item)) item[k] = spec[k];
    return item;
  }

  function _inject(section, spec) {
    try {
      if (typeof setup === 'undefined' || !setup.hairstyles) return false;
      if (!Array.isArray(setup.hairstyles[section])) setup.hairstyles[section] = [];
      var arr = setup.hairstyles[section];
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] && arr[i].variable === spec.variable) return false; // 去重
      }
      arr.push(_normalize(section, spec));
      return true;
    } catch (e) { return false; }
  }

  // 本体 widget 汇总的全部发型 type 集合, 注入新类型后需要重算
  function _recomputeTraits() {
    try {
      if (typeof setup === 'undefined' || !setup.hairstyles) return;
      var all = [];
      for (var k in setup.hairstyles) {
        if (!Array.isArray(setup.hairstyles[k])) continue;
        for (var i = 0; i < setup.hairstyles[k].length; i++) {
          var t = setup.hairstyles[k][i] && setup.hairstyles[k][i].type;
          if (Array.isArray(t)) all = all.concat(t);
        }
      }
      var seen = {};
      setup.hairTraits = all.filter(function (x) { if (seen[x]) return false; seen[x] = 1; return true; });
    } catch (e) {}
  }

  SM.hair = {
    add: function (section, spec) {
      if ((section !== 'fringe' && section !== 'sides') || !spec || !spec.variable) return false;
      if (_flushed) { var ok = _inject(section, spec); if (ok) _recomputeTraits(); return ok; }
      _queue.push({ section: section, spec: spec });
      return true;
    },
  };

  function _flush() {
    var changed = false;
    for (var i = 0; i < _queue.length; i++) {
      if (_inject(_queue[i].section, _queue[i].spec)) changed = true;
    }
    _queue.length = 0;
    _flushed = true;
    if (changed) _recomputeTraits();
  }

  if (SM.onInit) SM.onInit(_flush);
  if (typeof $ !== 'undefined') $(document).one(':storyready', _flush);
})();
