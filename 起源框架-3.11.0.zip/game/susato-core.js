// ==================================================================
//  SusatoModel 渲染器核心 v1.1
//  统一入口：图层注入 · 图层修改 · ZIndices 扩展 · compile 钩子
//  不需要 ReplacePatcher、不需要 maplebirch。
//
//  CREDITS
//  画家K — 架构 & 核心代码 & 重构
//  Yisic, 画家K, Cicero, 小鼹鼠, Ki, 冰, 枯木枝修, Phantalis — 贴图 & 测试 & 反馈
// ==================================================================
//
//  发现，珍宝总是易逝，
//  欢愉与狂怒交织——我正注视着你。
//  今夜，请小心你的一举一动。
//  我想时机已到，我想鲜血已经凝固，
//  它仍在渴求更多。那我们还在等什么？
//
//  线缆与锁链（我只是厌倦了视而不见），
//  开始褪色消散（我只是厌倦了视而不见），
//  感觉像一场游戏（我只是厌倦了视而不见），
//  你必须入局（我只是厌倦了视而不见）。
//
//  熄灯。这才是真实的你吗？
//  无法直视你的双眼，你那扭曲的心智。
//  好暗，如此黑暗。我们就在此了结，就在此地，此刻。
//  请告诉我你带了家伙，
//  让我们把夜空点燃，再消逝于长夜。
//
//  那些曾经美好的日子已然远逝，
//  我试着看清这一切究竟为何，却永远无法得知。
//  尽管它已死去，我仍听见那召唤。
//
//  线缆与锁链，开始褪色消散，
//  感觉像一场游戏，你无法逃脱。
//
//  我终于发现：珍宝总是易逝。
//  欢愉早已被遗忘。如今的你，究竟是谁？
//
// ==================================================================
(function () {
  'use strict';

  window.SusatoModel = window.SusatoModel || {};
  var SR = window.SusatoModel.renderer = window.SusatoModel.renderer || {};

  // ================================================================
  //  load-once 守卫 —— susato-core 可能被多个子 mod 各打包一份而加载多次。
  //  只让第一份生效，后续加载直接退出。否则第二份会重置内部钩子/队列，
  //  而 compile 包装器（_susatoCompileHooked 守卫，只装一次）仍读第一份的
  //  钩子数组 → 第二份之后注册的 onCompile 钩子永不执行（时装叠穿失效的真因）。
  //  这道守卫是"稳定抽象层"的前提：被复用几次都保持单例、行为一致。
  // ================================================================
  if (SR._coreLoaded) {
    // 已有一份 core 抢先生效(残留的旧大包/旧管理器 zip)。旧核心带新模块跑风险不可控,
    // 大红警告提示清理 —— canLoadThisMod 拦不到排在自己之前的 mod, 只能靠人清。
    try {
      if (SR._coreVersion !== '3.0.0') {
        console.error('[susato-core] 检测到旧版核心已抢先加载(版本 ' + (SR._coreVersion || '未知(<3.0)') + '), 本副本(3.0.0)退让。请从 Mod Loader 移除旧的 起源框架-寿里美化包(<=2.8) 或 寿里美化拓展-起源管理器 包, 否则新功能可能异常。');
        try { window.modSC2DataManager.getModLoadController().getLog().error('[susato-core] 旧版核心抢占单例, 请清理旧包'); } catch (e2) {}
      }
    } catch (e) {}
    return;
  }
  SR._coreLoaded = true;
  SR._coreVersion = '3.0.0';

  // ================================================================
  //  模块开关 —— 起源管理器写 localStorage 键 susato_modules_off
  //  (JSON 字符串数组, 如 ["decorations","model-addon"]), 各功能模块
  //  IIFE 顶部用 SusatoModel.moduleOff('<id>') 守卫, 刷新页面后生效。
  //  读一次缓存: 开关翻转本来就要求刷新, 不需要动态重读。
  // ================================================================
  var _modulesOff = (function () {
    try {
      var arr = JSON.parse(localStorage.getItem('susato_modules_off'));
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  })();

  window.SusatoModel.moduleOff = function (id) {
    return _modulesOff.indexOf(id) >= 0;
  };
  window.SusatoModel.moduleOffList = function () {
    return _modulesOff.slice();
  };

  // ================================================================
  //  共享初始化钩子 —— 任何模块注册一个 fn，由 core 在 :storyready
  //  flush 时统一调用。clothing-addon 等模块不再需要自己的 :storyready
  //  处理器和独立队列，全走这个管道。
  // ================================================================
  window.SusatoModel._initHooks = window.SusatoModel._initHooks || [];
  window.SusatoModel.onInit = function (fn) {
    window.SusatoModel._initHooks.push(fn);
  };

  // ================================================================
  //  ZIndices 扩展 —— 运行时动态给 ZIndices 对象加属性
  //  const ZIndices = {...} 只阻止变量重赋值，不阻止属性修改，
  //  所以这里直接赋值即可，不需要 ReplacePatcher 文本替换。
  // ================================================================

  var _zQueue = [];

  function _applyZ(map) {
    var keys = Object.keys(map);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (!(k in ZIndices)) ZIndices[k] = map[k];
    }
  }

  SR.extendZIndices = function (map) {
    if (typeof ZIndices !== 'undefined') {
      _applyZ(map);
    } else {
      _zQueue.push(map);
    }
  };

  // ================================================================
  //  addLayers —— 注入新图层 { name: {srcfn,showfn,zfn,animation} }
  //  在 :storyready 统一注入，自动去重
  // ================================================================

  var _layerQueue = [];

  function _injectLayers(layers) {
    var model;
    try { model = Renderer.CanvasModels && Renderer.CanvasModels.main; } catch (e) { return; }
    if (!model || !model.layers) return;

    var keys = Object.keys(layers);
    for (var i = 0; i < keys.length; i++) {
      var name = keys[i];
      if (model.layers[name]) continue;
      model.layers[name] = layers[name];
    }
  }

  SR.addLayers = function (layers) {
    if (_flushed) { _injectLayers(layers); } else { _layerQueue.push(layers); }
  };

  // ================================================================
  //  patchLayer / patchLayers —— 修改已有图层属性（不改名）
  //  patchLayer("rightarm", fn) 或 patchLayers(filterFn, fn)
  //  自动排队 + 去重（同名只 patch 一次）
  // ================================================================

  var _patchedNames = {};
  var _patchQueue = [];

  function _applyPatch(name, patchFn) {
    if (_patchedNames[name]) return; // 去重
    var model;
    try { model = Renderer.CanvasModels && Renderer.CanvasModels.main; } catch (e) { return; }
    if (!model || !model.layers || !model.layers[name]) return;
    patchFn(model.layers[name], name);
    _patchedNames[name] = true;
  }

  function _applyPatchAll(filterFn, patchFn) {
    var model;
    try { model = Renderer.CanvasModels && Renderer.CanvasModels.main; } catch (e) { return; }
    if (!model || !model.layers) return;

    var keys = Object.keys(model.layers);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (_patchedNames[k]) continue;
      if (!filterFn(k, model.layers[k])) continue;
      patchFn(model.layers[k], k);
      _patchedNames[k] = true;
    }
  }

  // 修改单个命名图层
  SR.patchLayer = function (name, patchFn) {
    if (typeof patchFn !== 'function') return;
    if (_flushed) { _applyPatch(name, patchFn); } else { _patchQueue.push({ name: name, fn: patchFn }); }
  };

  // 按过滤函数批量修改（如匹配所有右臂相关图层）
  SR.patchLayers = function (filterFn, patchFn) {
    if (typeof patchFn !== 'function' || typeof filterFn !== 'function') return;
    if (_flushed) { _applyPatchAll(filterFn, patchFn); } else { _patchQueue.push({ filter: filterFn, fn: patchFn }); }
  };

  // ================================================================
  //  onCompile —— 注册 compile 钩子
  //  hook(layerSpecs, options, model)，返回修改后的 layerSpecs
  //  多个钩子按注册顺序执行。任一个返回 null/undefined 则保留原样。
  // ================================================================

  var _compileHooks = [];

  SR.onCompile = function (hook) {
    _compileHooks.push(hook);
  };

  function _setupCompileHook() {
    if (typeof CanvasModel === 'undefined') return;
    if (CanvasModel.prototype._susatoCompileHooked) return;

    var _originalCompile = CanvasModel.prototype.compile;

    CanvasModel.prototype.compile = function (options) {
      var specs = _originalCompile.call(this, options);

      for (var i = 0; i < _compileHooks.length; i++) {
        try {
          var result = _compileHooks[i](specs, options, this);
          if (result) specs = result;
        } catch (e) {}
      }

      return specs;
    };

    CanvasModel.prototype._susatoCompileHooked = true;
  }

  // 提早安装 compile 包装器 —— 和"能用的直接覆写"同时机：加载时就装，不等 :storyinit。
  // DoL 的 Renderer 可能在 :storyinit 之前/之时就捕获 compile，迟到的包装器不生效。
  // 包装器按引用读 _compileHooks，稍后（如 clothing-layering 加载时）注册的钩子也能被读到。
  (function _earlyCompileHook() {
    if (typeof CanvasModel !== 'undefined') { _setupCompileHook(); return; }
    var n = 0;
    var t = setInterval(function () {
      n++;
      if (typeof CanvasModel !== 'undefined') { _setupCompileHook(); clearInterval(t); return; }
      if (n > 200) clearInterval(t);
    }, 25);
  })();

  // ================================================================
  //  统一注入时机：:storyready 一次性处理所有排队 + 挂载 compile 钩子
  //  （:storyinit 在 SugarCube/DoL 里并不存在，绝不能用作触发点）
  // ================================================================

  var _flushed = false;

  function _flush() {
    // ZIndices
    for (var i = 0; i < _zQueue.length; i++) { _applyZ(_zQueue[i]); }
    _zQueue = [];

    // 新增图层
    for (var i = 0; i < _layerQueue.length; i++) { _injectLayers(_layerQueue[i]); }
    _layerQueue = [];

    // 修改已有图层
    for (var i = 0; i < _patchQueue.length; i++) {
      var p = _patchQueue[i];
      if (p.name) { _applyPatch(p.name, p.fn); } else { _applyPatchAll(p.filter, p.fn); }
    }
    _patchQueue = [];

    // compile 钩子：在所有图层就绪后挂载
    _setupCompileHook();

    // 消费所有通过 onInit 注册的外部模块（clothing-addon 等）
    var _hooks = window.SusatoModel._initHooks || [];
    for (var _hi = 0; _hi < _hooks.length; _hi++) {
      try { _hooks[_hi](); } catch (e) {}
    }
    _hooks.length = 0;

    _flushed = true;

    // 切换为直接执行模式
    SR.addLayers = function (layers) { _injectLayers(layers); };
    SR.extendZIndices = function (map) { _applyZ(map); };
    SR.patchLayer = function (name, fn) { _applyPatch(name, fn); };
    SR.patchLayers = function (filter, fn) { _applyPatchAll(filter, fn); };
  }

  // ================================================================
  //  UI：可复用面板框架（基于 SugarCube 原生 Dialog）
  //
  //  openPanel(widgetName, opts) 把一个 <<widget>> 渲染进游戏原生 Dialog：
  //  自带主题化标题栏 + 关闭键 + Esc/点遮罩关闭，外观跟随玩家主题，
  //  不依赖 maplebirch、不手搓样式。任何子 mod 都能直接复用。
  //    opts.title      标题栏文字（默认空）
  //    opts.className  附加到 dialog 的 CSS 类
  //    opts.width      仅在原生 Dialog 不可用、回退手搓面板时生效（默认 400px）
  //
  //  触发按钮由 boot.json 的 TweeReplacer 注入 StoryCaption 源码
  //  （Story = Object.freeze，运行时注不进去，只能改 passage 源码）：
  //    <<button ...>><<run SusatoModel.ui.openPanel('某widget')>><</button>>
  //  或注入 <div data-susato-panel="某widget">，由下方文档级委托接管。
  // ================================================================

  var SU = window.SusatoModel.ui = window.SusatoModel.ui || {};

  var PANEL_ID = 'susato-panel';      // 回退 off-canvas 面板的 DOM id
  var PANEL_CLASS = 'susato-panel';   // 打到原生 dialog 上的标记类，用于只关自己的面板

  function _dialogUsable() {
    return typeof Dialog !== 'undefined' && Dialog.setup && Dialog.wiki && Dialog.open;
  }

  SU.closePanel = function () {
    // 原生 dialog 只关带 susato-panel 标记类的那个，避免误关游戏其它弹窗。
    // SugarCube 把 setup 的 class 加在 #ui-dialog 或 #ui-dialog-body 上（版本而异），两处都查。
    try {
      if (_dialogUsable() && Dialog.close) {
        var open = (typeof Dialog.isOpen === 'function') ? Dialog.isOpen() : true;
        var dlg = document.getElementById('ui-dialog');
        var body = document.getElementById('ui-dialog-body');
        var mine = /\bsusato-panel\b/.test((dlg && dlg.className) || '') ||
                   /\bsusato-panel\b/.test((body && body.className) || '');
        if (open && mine) Dialog.close();
      }
    } catch (e) {}
    // 回退面板也清一下
    var panel = document.getElementById(PANEL_ID);
    if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
  };

  // 打开一个渲染 <<widgetName>> 的面板。优先用原生 Dialog。
  SU.openPanel = function (widgetName, opts) {
    opts = opts || {};
    if (_dialogUsable()) {
      try {
        Dialog.setup(opts.title || '', (PANEL_CLASS + ' ' + (opts.className || '')).trim());
        Dialog.wiki('<<' + widgetName + '>>');
        Dialog.open();
        return;
      } catch (e) {}
    }
    _openFallback(widgetName, opts);   // 原生 Dialog 不可用时兜底
  };

  // 兜底：原生 Dialog 缺席时用一个跟随主题的 off-canvas 侧板
  function _openFallback(widgetName, opts) {
    var existing = document.getElementById(PANEL_ID);
    if (existing) {
      var same = existing.getAttribute('data-widget') === widgetName;
      if (existing.parentNode) existing.parentNode.removeChild(existing);
      if (same) return; // 再点同一触发 = 关闭
    }

    var panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.setAttribute('data-widget', widgetName);
    var width = opts.width || 400;
    panel.style.cssText =
      'position:fixed;top:0;right:0;width:' + width + 'px;max-width:100vw;height:100vh;' +
      'overflow-y:auto;background:var(--900);border-left:2px solid var(--700);z-index:9999;' +
      'padding:16px;color:var(--000);box-shadow:-4px 0 20px rgba(0,0,0,0.5);';

    var closeBtn = document.createElement('span');
    closeBtn.textContent = '关闭';
    closeBtn.style.cssText =
      'position:sticky;top:0;float:right;cursor:pointer;font-size:18px;color:var(--red);z-index:1;';
    closeBtn.onclick = SU.closePanel;
    panel.appendChild(closeBtn);

    var content = document.createElement('div');
    content.style.clear = 'both';
    panel.appendChild(content);

    document.body.appendChild(panel);

    // 渲染 widget 到目标元素：用 jQuery.wiki（wikifyEval 不接收目标元素）
    try {
      if (typeof $ !== 'undefined') { $(content).wiki('<<' + widgetName + '>>'); }
      else { new Wikifier(content, '<<' + widgetName + '>>'); }
    } catch (e) {}
  }

  // 向后兼容：deco 面板
  SU.closeDecoPanel = SU.closePanel;
  SU.openDecoPanel = function () { SU.openOverlay('susatoDeco', '前景背景', 'decoPanel'); };

  // ================================================================
  //  原生覆盖层：与本体 属性/社交 完全同一套窗口 UI（#customOverlay）
  //  复刻本体 overlayReplace widget（switch 写死 key 进不去，只能自己驱动）：
  //  - 再点同一按钮 = 关闭（toggle）
  //  - 收起当前选中的侧栏 Tab（T.buttons）
  //  - 标题栏完整复刻本体 titleXxx widget 结构：
  //      <<setupTabs>> + #overlayTabs 标签按钮 + <<closeButtonMobile>> + <<closeButton>>
  //    （右上角关闭键与移动端关闭按钮都来自本体 widget，随玩家选项走）
  //  原生容器不可用时回退 Dialog 面板。
  //    SusatoModel.ui.openOverlay('susatoEcon', '账本', 'susatoEconPanel')
  // ================================================================
  SU.openOverlay = function (key, title, widgetName) {
    try {
      var overlay = document.getElementById('customOverlay');
      if (overlay && typeof $ !== 'undefined') {
        // 再点同一按钮 = 关闭
        if (!overlay.classList.contains('hidden') && overlay.getAttribute('data-overlay') === key) {
          if (typeof window.closeOverlay === 'function') window.closeOverlay();
          return;
        }
        var T = (typeof State !== 'undefined' && State.temporary) ? State.temporary : null;
        try {
          if (T && T.buttons && T.buttons.activeTab != -1) {
            T.buttons.toggle();
            if (typeof window.updateOptions === 'function') window.updateOptions();
          }
        } catch (e) {}
        if (T) T.currentOverlay = key;
        $('#customOverlay').removeClass('hidden').parent().removeClass('hidden');
        $('#customOverlay').attr('data-overlay', key);
        // 标题栏 = 本体 titleXxx widget 同款结构（单标签）
        var titleBar =
          '<<setupTabs>>' +
          '<div id="overlayTabs" class="tab">' +
            '<<closeButtonMobile>>' +
            '<<button "' + (title || '') + '">>' +
              '<<toggleTab>>' +
              '<<replace #customOverlayContent>><<' + widgetName + '>><</replace>>' +
            '<</button>>' +
          '</div>' +
          '<<closeButton>>';
        $('#customOverlayTitle').empty().wiki(titleBar);
        $('#customOverlayContent').empty().wiki('<<' + widgetName + '>>');
        return;
      }
    } catch (e) {}
    SU.openPanel(widgetName, { title: title || '' });
  };

  // 文档级事件委托：任何带 data-susato-panel="widget" 的元素点击/回车都触发对应面板。
  // 绑在 document 上，扛住 StoryCaption 每回合重渲染。兼容旧的 #susato-deco-btn。
  function _bindClicks() {
    if (typeof $ === 'undefined') return;
    if (SU._panelClickBound) return;
    SU._panelClickBound = true;

    function widgetOf(el) {
      var w = el.getAttribute && el.getAttribute('data-susato-panel');
      if (w) return w;
      if (el.id === 'susato-deco-btn') return 'decoPanel'; // 兼容旧触发
      return null;
    }
    $(document).on('click', '[data-susato-panel], #susato-deco-btn', function (ev) {
      var w = widgetOf(this); if (!w) return;
      ev.preventDefault(); SU.openPanel(w);
    });
    $(document).on('keydown', '[data-susato-panel], #susato-deco-btn', function (ev) {
      if (ev.key !== 'Enter' && ev.key !== ' ') return;
      var w = widgetOf(this); if (!w) return;
      ev.preventDefault(); SU.openPanel(w);
    });
  }

  if (typeof $ !== 'undefined') {
    _bindClicks();
    $(document).one(':storyready', _bindClicks);
  }

  // ================================================================
  //  自定义名望框架
  //  子 mod 可注册新的 fame 类型，自动获得：
  //  - $fame[type] 变量初始化
  //  - allure 折扣（若配置 discount 阶梯）
  //  Social 页面显示由子 mod 自行用 TweeReplacer 注入（框架不做 DOM/passage 注入）
  //  SusatoModel.fame.register({ type:'order', name:'秩序', discount:[...] })
  // ================================================================

  var _fameTypes = {};

  window.SusatoModel.fame = {
    register: function (config) {
      if (!config || !config.type) return;
      if (_fameTypes[config.type]) return;
      _fameTypes[config.type] = config;
      // 如果 $fame 已存在，立即初始化
      try {
        if (typeof State !== 'undefined' && State.variables) {
          var V = State.variables;
          if (typeof V.fame !== 'object') V.fame = {};
          if (V.fame[config.type] === undefined) V.fame[config.type] = 0;
        }
      } catch (e) {}
    }
  };

  // 初始化所有已注册 fame 类型的 $fame[type] 变量
  function _initFameVars() {
    try {
      if (typeof State === 'undefined' || !State.variables) return;
      var V = State.variables;
      if (typeof V.fame !== 'object') V.fame = {};
      var types = Object.keys(_fameTypes);
      for (var i = 0; i < types.length; i++) {
        var t = types[i];
        if (V.fame[t] === undefined) V.fame[t] = 0;
      }
    } catch (e) {}
  }

  // allure 折扣：对配置了 discount 阶梯的 fame 类型生效
  function _applyAllureDiscount() {
    try {
      if (typeof State === 'undefined' || !State.variables) return;
      var V = State.variables;
      if (typeof V.allure === 'undefined') return;
      if (typeof V.fame !== 'object') return;

      var types = Object.keys(_fameTypes);
      for (var i = 0; i < types.length; i++) {
        var cfg = _fameTypes[types[i]];
        if (!cfg.discount) continue;

        var val = V.fame[types[i]] || 0;
        // discount = [{threshold: 200, pct: 5}, {threshold: 400, pct: 10}, ...]
        var pct = 0;
        for (var d = cfg.discount.length - 1; d >= 0; d--) {
          if (val >= cfg.discount[d].threshold) { pct = cfg.discount[d].pct; break; }
        }
        if (pct > 0) {
          V.allure = Math.floor(V.allure * (1 - pct / 100));
        }
      }
    } catch (e) {}
  }

  // 挂事件（只挂一次，jQuery 就绪后）
  function _setupFameHooks() {
    if (typeof $ === 'undefined') return;
    if (window.SusatoModel.fame._hooksSetup) return;
    window.SusatoModel.fame._hooksSetup = true;

    _initFameVars();

    $(document).on(':passageend', function () {
      _initFameVars();
      _applyAllureDiscount();
    });
  }

  // 消费 onInit 管道：在 _flush 时初始化变量+挂 allure 折扣钩子
  window.SusatoModel.onInit(function () {
    _setupFameHooks();
    _initFameVars();
  });

  // jQuery 已就绪则提前挂事件（_setupFameHooks 有守卫，不会重复）
  if (typeof $ !== 'undefined') {
    _setupFameHooks();
  }

  if (typeof $ !== 'undefined') {
    $(document).one(':storyready', _flush);
  } else {
    var _attempts = 0;
    var _t = setInterval(function () {
      _attempts++;
      if (typeof $ !== 'undefined') {
        clearInterval(_t);
        $(document).one(':storyready', _flush);
      } else if (_attempts > 200) { // 10s timeout
        clearInterval(_t);
      }
    }, 50);
  }
})();
