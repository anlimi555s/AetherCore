// tear-bodyshape.js — tears 和 basehead 图层按体型($bodyshape)独立读取 + 回退
// 依赖起源框架（susato-core 的 patchLayer）。
//
// 命名约定:
//   img/face/{facestyle}/tears-{N}_{bodyshape}.png   — 体型独立 tear
//   img/body/base-head_{bodyshape}.png               — 体型独立 basehead
// 回退: 体型号文件不存在则用原版通用路径。
//
// 和人模切换 (model-addon) 正交: 人模切换的 onCompile 改写全路径前缀,
// 本 mod 的 patchLayer 在 srcfn 层面改文件名。两者叠加: 人模切换选画风, 仪态独立图层选体型变体。

(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM || !SM.renderer) return;

  var _fileMap = null;
  var _patched = false;

  // 从 options 里取 bodyshape, 兜底 classic
  function _bodyshape(options) {
    if (options && options.body_type) return options.body_type;
    try {
      if (typeof V !== 'undefined' && V.player && V.player.bodyshape) return V.player.bodyshape;
    } catch (e) {}
    return 'classic';
  }

  // 扫全部已装 mod 的 imgFileList, 建全局文件名查找表
  function buildFileMap() {
    var map = {};
    try {
      var utils = window.modSC2DataManager;
      utils = utils && utils.getModUtils && utils.getModUtils();
      var names = utils && utils.getModListName && utils.getModListName();
      if (!Array.isArray(names)) return map;
      for (var m = 0; m < names.length; m++) {
        var mod = utils.getMod(names[m]);
        var list = mod && mod.bootJson && mod.bootJson.imgFileList;
        if (!Array.isArray(list)) continue;
        for (var i = 0; i < list.length; i++) {
          if (typeof list[i] === 'string') map[list[i]] = 1;
        }
      }
    } catch (e) {}
    return map;
  }

  function setup() {
    _fileMap = buildFileMap();

    if (!_patched) {
      _patched = true;
      var SR = SM.renderer;

      // --- tears 图层 ---
      SR.patchLayer('tears', function (layer) {
        var _orig = layer.srcfn;
        layer.srcfn = function (options) {
          var tears = options.tears;
          var facestyle = options.facestyle || 'default';
          var bs = _bodyshape(options);
          var bsPath = 'img/face/' + facestyle + '/tears-' + tears + '_' + bs + '.png';
          if (_fileMap[bsPath]) return bsPath;
          return _orig.call(this, options);
        };
      });

      // --- basehead 图层 ---
      SR.patchLayer('basehead', function (layer) {
        var _orig = layer.srcfn;
        layer.srcfn = function (options) {
          var bs = _bodyshape(options);
          var bsPath = 'img/body/base-head_' + bs + '.png';
          if (_fileMap[bsPath]) return bsPath;
          return _orig.call(this, options);
        };
      });
    }
  }

  // 首次安装（susato-core onInit 管道）
  if (SM.onInit) SM.onInit(setup);
  // storyready 补一次: 此时所有 mod 加载完毕, fileMap 最完整
  if (typeof $ !== 'undefined') $(document).one(':storyready', function () {
    setup();
  });
})();
