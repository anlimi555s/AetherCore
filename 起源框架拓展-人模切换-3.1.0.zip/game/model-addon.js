// model-addon.js -- 人模切换框架 v3.1
// 对标 hair-addon/skill-addon 家族：注册式 + 自动发现，镜子页切换，全局生效。
//
// v3 目录约定：
//   img/<改脸名>/ 完全镜像 img/ 结构，只放要替换的图。
//   img/<改脸名>/face/<仪态名>/ 每个子目录自动成为该改脸的仪态。
//   不同改脸完全独立，各自拥有完整的图片集。
//
// 原理：susato-core 的 onCompile 钩子拿到每层最终 src，
// 按当前改脸把 "img/<路径>" 改写为 "img/<改脸名>/<路径>"。
// boot.json 注册 ImageLoaderAddon，自定义路径由 ModLoader 图片管线服务。
//
// API:
//   改脸:
//     SusatoModel.model.register({ id, name, modName })
//     SusatoModel.model.select(id)        // '' = 默认
//     SusatoModel.model.list()
//     SusatoModel.model.current()
//   仪态:
//     SusatoModel.model.listPostures(faceId)
//     SusatoModel.model.selectPosture(faceId, postureId)
//     SusatoModel.model.currentPosture()
//
// 运行基础：susato-core 的 onCompile/onInit。
// 装载顺序契约：与 起源框架 同装时本 mod 须排在其后。

(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('model-addon')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.model) return;

  var STORAGE_KEY_FACE = 'susato_model_selected';
  var STORAGE_KEY_POSTURE = 'susato_posture_selected';
  var DISCOVER_PREFIX = 'img/';
  var FACE_DIR = 'face/';

  var _registry = {};
  var _order = [];
  var _fileMaps = {};
  var _postures = {};

  function _load(key) {
    try { return localStorage.getItem(key) || ''; } catch (e) { return ''; }
  }
  function _save(key, id) {
    try { localStorage.setItem(key, id || ''); } catch (e) {}
  }

  var _current = _load(STORAGE_KEY_FACE);
  var _currentPosture = _load(STORAGE_KEY_POSTURE);

  function _modUtils() {
    try {
      var mgr = window.modSC2DataManager;
      return (mgr && mgr.getModUtils && mgr.getModUtils()) || null;
    } catch (e) { return null; }
  }

  function _imgListOf(modName) {
    try {
      var utils = _modUtils();
      var mod = utils && utils.getMod && utils.getMod(modName);
      var list = mod && mod.bootJson && mod.bootJson.imgFileList;
      return Array.isArray(list) ? list : null;
    } catch (e) { return null; }
  }

  function _buildFileMap(modName, prefix) {
    var list = _imgListOf(modName);
    if (!list) return null;
    var map = {}, head = prefix + '/', found = false;
    for (var i = 0; i < list.length; i++) {
      var p = list[i];
      if (typeof p === 'string' && p.indexOf(head) === 0) { map[p] = 1; found = true; }
    }
    return found ? map : null;
  }

  function _register(cfg) {
    if (!cfg || !cfg.id || !cfg.name || !cfg.modName || _registry[cfg.id]) return false;
    cfg.prefix = cfg.prefix || (DISCOVER_PREFIX + cfg.id);
    if (cfg.prefix.charAt(cfg.prefix.length - 1) === '/') cfg.prefix = cfg.prefix.slice(0, -1);
    _registry[cfg.id] = cfg;
    _order.push(cfg.id);
    _fileMaps[cfg.id] = _buildFileMap(cfg.modName, cfg.prefix);
    return true;
  }

  var _gameDirs = { body:1, bodywriting:1, clothes:1, decorations:1, face:1, hair:1, misc:1, sex:1, transformations:1, ui:1 };

  function _discover() {
    var utils = _modUtils();
    var names;
    try { names = utils && utils.getModListName && utils.getModListName(); } catch (e) { names = null; }
    if (!Array.isArray(names)) return;
    for (var m = 0; m < names.length; m++) {
      var list = _imgListOf(names[m]);
      if (!list) continue;
      var seenFaces = {};
      for (var i = 0; i < list.length; i++) {
        var p = list[i];
        if (typeof p !== 'string' || p.indexOf(DISCOVER_PREFIX) !== 0) continue;
        var rest = p.slice(DISCOVER_PREFIX.length);
        var cut = rest.indexOf('/');
        if (cut <= 0) continue;
        var faceName = rest.slice(0, cut);
        if (!faceName || _gameDirs[faceName]) continue;
        var afterFace = rest.slice(cut + 1);
        if (afterFace.indexOf(FACE_DIR) !== 0) continue;
        var afterFaceDir = afterFace.slice(FACE_DIR.length);
        var cut2 = afterFaceDir.indexOf('/');
        if (cut2 <= 0) continue;
        var postureName = afterFaceDir.slice(0, cut2);
        if (!postureName || _gameDirs[postureName]) continue;
        if (!seenFaces[faceName]) {
          seenFaces[faceName] = 1;
          _register({ id: faceName, name: faceName, modName: names[m] });
        }
        if (!_postures[faceName]) _postures[faceName] = { _order: [] };
        if (!_postures[faceName][postureName]) {
          _postures[faceName][postureName] = { id: postureName, name: postureName };
          _postures[faceName]._order.push(postureName);
        }
      }
    }
  }

  SM.model = {
    register: function (cfg) { return _register(cfg); },

    registerBlobPack: function (id, name, resolveFn) {
      if (!id || !resolveFn) return false;
      if (_registry[id]) return true;
      _registry[id] = { id: id, name: name || id, modName: '', prefix: '', _blobResolve: resolveFn };
      _order.push(id);
      _fileMaps[id] = null;
      return true;
    },

    select: function (id) {
      id = id || '';
      if (id && !_registry[id]) return false;
      _current = id;
      _save(STORAGE_KEY_FACE, id);
      if (!id) {
        _currentPosture = '';
        _save(STORAGE_KEY_POSTURE, '');
      } else {
        var postures = _postures[id];
        if (postures && _currentPosture && !postures[_currentPosture]) {
          _currentPosture = '';
          _save(STORAGE_KEY_POSTURE, '');
        }
      }
      _redrawAll();
      return true;
    },

    list: function () {
      var out = [];
      for (var i = 0; i < _order.length; i++) out.push(_registry[_order[i]]);
      return out;
    },

    current: function () { return _current; },

    listPostures: function (faceId) {
      var p = _postures[faceId];
      if (!p) return [];
      var out = [];
      for (var i = 0; i < p._order.length; i++) out.push(p[p._order[i]]);
      return out;
    },

    selectPosture: function (faceId, postureId) {
      faceId = faceId || '';
      postureId = postureId || '';
      if (!faceId || !_postures[faceId]) return false;
      if (postureId && !_postures[faceId][postureId]) return false;
      _currentPosture = postureId;
      _save(STORAGE_KEY_POSTURE, postureId);
      _redrawAll();
      return true;
    },

    currentPosture: function () { return _currentPosture; },
  };

  function _redrawAll() {
    try {
      if (typeof Renderer !== 'undefined' && Renderer.CanvasModels) {
        var keys = Object.keys(Renderer.CanvasModels);
        for (var i = 0; i < keys.length; i++) {
          var mdl = Renderer.CanvasModels[keys[i]];
          if (mdl && typeof mdl.redraw === 'function') {
            try { mdl.redraw(); } catch (e) {}
          }
        }
      }
    } catch (e) {}
  }

  function _installCompileHook() {
    var SR = SM.renderer;
    if (!SR || !SR.onCompile || SM.model._hookInstalled) return;
    SM.model._hookInstalled = true;

    SR.onCompile(function (specs) {
      var id = _current;
      if (!id || !_registry[id] || !specs) return;
      var cfg = _registry[id];
      var prefix = cfg.prefix + '/';
      var map = _fileMaps[id];
      var blobResolve = cfg._blobResolve;
      var posture = _currentPosture;

      for (var i = 0; i < specs.length; i++) {
        var s = specs[i];
        if (!s || typeof s.src !== 'string' || s.src.indexOf('img/') !== 0) continue;
        if (blobResolve) {
          var relPath = s.src.slice(4);
          var blobUrl = blobResolve('face/' + relPath);
          if (blobUrl) { s.src = blobUrl; continue; }
        }
        // 全镜像: img/<路径> -> img/<改脸>/<路径>
        var rel = s.src.slice(4);
        var ns = prefix + rel;

        // v3.1: 仪态改写 — face/<原facestyle>/ -> face/<仪态名>/
        if (posture) {
          var faceIdx = ns.indexOf('/face/');
          if (faceIdx >= 0) {
            var afterFace = ns.slice(faceIdx + 6);
            var slashAfterStyle = afterFace.indexOf('/');
            if (slashAfterStyle > 0) {
              var postureNs = ns.slice(0, faceIdx + 6) + posture + afterFace.slice(slashAfterStyle);
              // 仪态路径有文件则用它，否则保留基础镜像路径
              if (!map || map[postureNs]) ns = postureNs;
            }
          }
          // base-head 也用仪态里的 basehead
          var bhIdx = ns.indexOf('/body/base-head');
          if (bhIdx >= 0) {
            var afterBh = ns.slice(bhIdx + 15);
            var postureBaseheadNs = ns.slice(0, bhIdx) + '/face/' + posture + '/basehead' + afterBh;
            if (!map || map[postureBaseheadNs]) ns = postureBaseheadNs;
          }
        }
        if (!map || map[ns]) s.src = ns;
      }
      return specs;
    });
  }

  _installCompileHook();

  var _alreadyFlushed = false;

  function _flush() {
    if (_alreadyFlushed) return;
    _alreadyFlushed = true;
    _installCompileHook();
    _discover();
    for (var i = 0; i < _order.length; i++) {
      var id = _order[i];
      var r = _registry[id];
      if (!_fileMaps[id]) _fileMaps[id] = _buildFileMap(r.modName, r.prefix);
    }
    if (_current && _registry[_current]) SM.model.select(_current);
    else if (_current) { _current = ''; _save(STORAGE_KEY_FACE, ''); }
  }

  if (SM.onInit) SM.onInit(_flush);
  if (typeof $ !== 'undefined') {
    $(document).one(':storyready', _flush);
  }
  // 兜底：外部 mod 脚本可能在 :storyready 之后加载
  setTimeout(function () { _flush(); }, 100);
})();
