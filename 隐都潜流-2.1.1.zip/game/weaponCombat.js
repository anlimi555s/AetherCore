// weaponCombat.js — 武器战斗辅助
// 拳套战斗动作通过 leftweaponnew / rightweaponnew widget 注入到 _leftaction/_rightaction,
// 走本体 lefthit / righthit 动作类型, 无需本模块做 DOM 注入。
// 本模块仅提供伤害计算供参考。

(function () {
  'use strict';

  if (window.KHWeaponCombat) return;
  var W = window.KHWeaponCombat = {};

  function calcDamage() {
    var base = 200;
    try {
      var phys = (typeof V !== 'undefined' && typeof V.physique === 'number') ? V.physique : 0;
      var wc = (typeof V !== 'undefined' && typeof V.weaponCombat === 'number') ? V.weaponCombat : 0;
      var physMult = 1 + (phys / 1000) * 0.5;
      var wcMult = 1 + (Math.floor(wc / 200)) * 0.25;
      return Math.round(base * physMult * wcMult);
    } catch (e) { return base; }
  }

  W.calcDamage = calcDamage;
})();
