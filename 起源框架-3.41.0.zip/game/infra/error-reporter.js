// ==================================================================
//  error-reporter v1.0 -- 游戏内错误控制台
//  吸收自 DoL Plus (game/00-framework-tools/01-error/error.js).
//  提供运行时错误收集、DOM 面板展示、复制导出。
//
//  API:
//   SM.errors.report(message, data)   -- 上报错误
//   SM.errors.show() / hide()         -- 显示/隐藏错误面板
//   SM.errors.toggle()                -- 切换面板显示
//   SM.errors.clear()                 -- 清空错误日志
//   SM.errors.getAll()                -- 获取全部错误日志 [{message, data, time}]
//   SM.errors.copyAll()               -- 复制全部错误到剪贴板
//
//  依赖: 无 (纯 JS + DOM)
//  消费方: 全部模块 (开发调试), 管理器
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.errors) return;

  var CONFIG = {
    maxLogs: 100,
    reporterId: 'susato-error-reporter'
  };

  var _log = [];
  var _reporterEl = null;

  // ================================================================
  //  核心 API
  // ================================================================
  var errors = {
    report: function (message, data) {
      var entry = {
        message: String(message || ''),
        data: data,
        time: new Date()
      };
      while (_log.length >= CONFIG.maxLogs) _log.shift();
      _log.push(entry);

      // 如果面板已打开则实时更新
      if (_reporterEl && !_reporterEl.classList.contains('hidden')) {
        _updatePanel();
      }

      // 同时输出到 console
      try {
        console.warn('[Susato] ' + entry.message, entry.data || '');
      } catch (e) {}
    },

    show: function () {
      _ensurePanel();
      _reporterEl.classList.remove('hidden');
      _updatePanel();
    },

    hide: function () {
      if (_reporterEl) _reporterEl.classList.add('hidden');
    },

    toggle: function () {
      _ensurePanel();
      if (_reporterEl.classList.contains('hidden')) {
        errors.show();
      } else {
        errors.hide();
      }
    },

    clear: function () {
      _log.length = 0;
      if (_reporterEl) _updatePanel();
    },

    getAll: function () {
      return _log.slice();
    },

    copyAll: function () {
      try {
        var text = '';
        for (var i = 0; i < _log.length; i++) {
          var e = _log[i];
          text += '[' + e.time.toISOString() + '] ' + e.message;
          if (e.data !== undefined) text += ' | ' + JSON.stringify(e.data);
          text += '\n';
        }
        var ta = document.createElement('textarea');
        ta.style.cssText = 'position:fixed;top:-9999px;';
        ta.value = text;
        document.body.appendChild(ta);
        ta.focus(); ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        return true;
      } catch (e) {
        return false;
      }
    }
  };

  // ================================================================
  //  DOM 面板
  // ================================================================
  function _ensurePanel() {
    if (_reporterEl) return;

    _reporterEl = document.createElement('div');
    _reporterEl.id = CONFIG.reporterId;
    _reporterEl.className = 'hidden';
    _reporterEl.style.cssText =
      'position:fixed;bottom:0;left:0;right:0;max-height:40vh;z-index:99999;' +
      'background:var(--900,#1a1a1a);border-top:2px solid var(--700,#444);' +
      'font-family:monospace;font-size:12px;overflow-y:auto;padding:0;' +
      'box-shadow:0 -4px 20px rgba(0,0,0,0.5);';

    // 工具栏
    var toolbar = document.createElement('div');
    toolbar.style.cssText =
      'position:sticky;top:0;display:flex;gap:8px;padding:8px 12px;' +
      'background:var(--800,#222);border-bottom:1px solid var(--700,#444);z-index:1;';
    toolbar.innerHTML =
      '<span style="font-weight:bold;color:var(--red,#e44);">Error Console</span>' +
      '<span style="flex:1;"></span>' +
      '<button id="' + CONFIG.reporterId + '-copy" style="cursor:pointer;background:var(--700,#444);color:var(--000,#fff);border:none;padding:2px 8px;border-radius:3px;">Copy All</button>' +
      '<button id="' + CONFIG.reporterId + '-clear" style="cursor:pointer;background:var(--700,#444);color:var(--000,#fff);border:none;padding:2px 8px;border-radius:3px;">Clear</button>' +
      '<button id="' + CONFIG.reporterId + '-close" style="cursor:pointer;background:var(--red,#e44);color:#fff;border:none;padding:2px 8px;border-radius:3px;">Close</button>';
    _reporterEl.appendChild(toolbar);

    // 消息列表
    var list = document.createElement('div');
    list.id = CONFIG.reporterId + '-list';
    list.style.cssText = 'padding:8px 12px;';
    _reporterEl.appendChild(list);

    document.body.appendChild(_reporterEl);

    // 事件绑定
    document.getElementById(CONFIG.reporterId + '-close').onclick = function () { errors.hide(); };
    document.getElementById(CONFIG.reporterId + '-clear').onclick = function () { errors.clear(); };
    document.getElementById(CONFIG.reporterId + '-copy').onclick = function () {
      var ok = errors.copyAll();
      this.textContent = ok ? 'Copied!' : 'Failed';
      var btn = this;
      setTimeout(function () { btn.textContent = 'Copy All'; }, 2000);
    };
  }

  function _updatePanel() {
    var list = document.getElementById(CONFIG.reporterId + '-list');
    if (!list) return;
    list.innerHTML = '';

    if (_log.length === 0) {
      list.innerHTML = '<div style="color:var(--500,#888);padding:4px;">No errors logged.</div>';
      return;
    }

    for (var i = 0; i < _log.length; i++) {
      var entry = _log[i];
      var row = document.createElement('div');
      row.style.cssText =
        'padding:4px 0;border-bottom:1px solid var(--800,#333);' +
        'color:var(--red,#e44);';
      var time = entry.time.toLocaleTimeString();
      row.textContent = '[' + time + '] ' + entry.message;
      if (entry.data !== undefined) {
        try {
          row.textContent += ' | ' + JSON.stringify(entry.data);
        } catch (e) {}
      }
      list.appendChild(row);
    }
  }

  // ================================================================
  //  全局错误捕获
  // ================================================================
  if (typeof window !== 'undefined') {
    window.addEventListener('error', function (e) {
      errors.report('Uncaught: ' + e.message, {
        file: e.filename,
        line: e.lineno,
        col: e.colno
      });
    });
  }

  SM.errors = errors;
})();
