// ==================================================================
//  module-system v2.0 -- 起源框架引擎脊柱
//  模块注册 + 拓扑排序 + 循环检测 + 三阶段生命周期。
//  susato-core 的 _flush 委托给本系统执行所有注册模块的初始化。
//  旧 SM.onInit(fn) 自动作为"default"模块（无依赖）纳入管理体系。
//
//  API:
//   SM.modules.register(name, initFn, opts)
//     opts.deps: 依赖模块名数组
//     opts.phase: 'preInit'|'init'|'postInit'（默认'init'）
//     opts.exposed: 将返回值挂到 SM[name]
//     opts.legacy: true 来自 SM.onInit 迁移（不报重复注册警告）
//
//   SM.modules.runAll() -- 按阶段+拓扑序执行全部注册模块
//   SM.modules.get(name) -- 取已激活模块
//   SM.modules.state(name) -- 查模块状态
//   SM.modules.list() -- 列出全部模块及状态
//   SM.modules.graph() -- 返回依赖图 {name: [deps]}
//
//  状态流转: registered -> preInit -> init -> active  (-> error)
//
// 依赖: susato-core.js (SM.events, SM.onInit)
// ==================================================================

(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM || !SM.events) {
    console.error('[module-system] SM.events 不可用');
    return;
  }
  if (SM._modulesV2) return;
  SM._modulesV2 = true;

  var _registry = {};   // name -> {name, initFn, deps, phase, exposed, state, legacy}
  var _active = {};     // name -> return value

  function _stateOf(name) {
    var m = _registry[name];
    return m ? m.state : 'unregistered';
  }

  function _topoSort(names) {
    var indeg = {}, adj = {}, i, j;
    for (i = 0; i < names.length; i++) {
      indeg[names[i]] = 0;
      adj[names[i]] = [];
    }
    for (i = 0; i < names.length; i++) {
      var deps = (_registry[names[i]] && _registry[names[i]].deps) || [];
      for (j = 0; j < deps.length; j++) {
        if (adj[deps[j]]) {
          adj[deps[j]].push(names[i]);
          indeg[names[i]]++;
        }
      }
    }
    var queue = [], result = [];
    for (i = 0; i < names.length; i++) {
      if (indeg[names[i]] === 0) queue.push(names[i]);
    }
    while (queue.length) {
      var cur = queue.shift();
      result.push(cur);
      for (j = 0; j < adj[cur].length; j++) {
        if (--indeg[adj[cur][j]] === 0) queue.push(adj[cur][j]);
      }
    }
    if (result.length < names.length) {
      var missing = [];
      for (i = 0; i < names.length; i++) {
        if (result.indexOf(names[i]) < 0) missing.push(names[i]);
      }
      console.error('[module-system] 循环依赖: ' + missing.join(' -> '));
    }
    return result;
  }

  function _runOne(name) {
    var m = _registry[name];
    if (!m || m.state === 'active' || m.state === 'error') return;

    // 检查依赖是否全部 active（或至少已完成）
    if (m.deps && m.deps.length) {
      for (var i = 0; i < m.deps.length; i++) {
        var ds = _stateOf(m.deps[i]);
        if (ds === 'error') {
          console.error('[module-system] ' + name + ': 依赖 ' + m.deps[i] + ' 初始化失败，跳过');
          m.state = 'error';
          return;
        }
        if (ds !== 'active' && ds !== m.phase) {
          return; // 依赖未就绪，等待
        }
      }
    }

    try {
      m.state = m.phase;
      var result = m.initFn();
      if (result !== undefined) _active[name] = result;
      m.state = 'active';
      if (m.exposed && result !== undefined) {
        SM[name] = result;
      }
    } catch (e) {
      m.state = 'error';
      console.error('[module-system] ' + name + ' 初始化失败: ' + (e.message || e));
    }
  }

  function _runPhase(phase) {
    var names = [];
    for (var n in _registry) {
      if (Object.prototype.hasOwnProperty.call(_registry, n)) {
        var m = _registry[n];
        if (m.phase === phase && m.state === 'registered') names.push(n);
      }
    }
    if (!names.length) return 0;

    var sorted = _topoSort(names);
    var count = 0;
    for (var i = 0; i < sorted.length; i++) {
      _runOne(sorted[i]);
      if (_registry[sorted[i]] && _registry[sorted[i]].state === 'active') count++;
    }
    return count;
  }

  // 兼容计数器：SM.onInit 迁移来的 legacy 模块用递增 id
  var _legacyId = 0;

  // ---------------- 公开 API ----------------

  SM.modules = {
    register: function (name, initFn, opts) {
      if (!name || typeof initFn !== 'function') return false;
      if (_registry[name]) {
        if (!(opts && opts.legacy)) {
          console.warn('[module-system] ' + name + ' 重复注册，跳过');
        }
        return false;
      }
      opts = opts || {};
      _registry[name] = {
        name: name,
        initFn: initFn,
        deps: opts.deps || [],
        phase: opts.phase || 'init',
        exposed: !!opts.exposed,
        state: 'registered'
      };

      // storyready 已过：立即尝试执行（sticky 回放）
      if (SM.events._storyreadyFired) {
        try { _runPhase('preInit'); } catch (e) {}
        try { _runPhase('init'); } catch (e) {}
        try { _runPhase('postInit'); } catch (e) {}
      }

      return true;
    },

    runAll: function () {
      var total = 0;
      try { total += _runPhase('preInit'); } catch (e) { console.error('[module-system] preInit: ' + (e.message || e)); }
      try { total += _runPhase('init'); } catch (e) { console.error('[module-system] init: ' + (e.message || e)); }
      try { total += _runPhase('postInit'); } catch (e) { console.error('[module-system] postInit: ' + (e.message || e)); }
      return total;
    },

    get: function (name) { return _active[name]; },
    state: function (name) { return _stateOf(name); },

    list: function () {
      return Object.keys(_registry).map(function (k) {
        var m = _registry[k];
        return { name: m.name, phase: m.phase, deps: (m.deps || []).slice(), state: m.state };
      });
    },

    graph: function () {
      var g = {};
      for (var n in _registry) {
        if (Object.prototype.hasOwnProperty.call(_registry, n)) {
          g[n] = (_registry[n].deps || []).slice();
        }
      }
      return g;
    }
  };

  // ---------------- 接管 SM.onInit ----------------

  // 旧 addon 调 SM.onInit(fn) → 注册为 legacy 模块 → runAll 时按拓扑序执行。
  // 不再同时走事件通道，避免 runAll + 事件回调双重执行。
  var _origOnInit = SM.onInit;
  SM.onInit = function (fn) {
    if (typeof fn !== 'function') return;
    var name = '_legacy_' + (++_legacyId);
    // register 内部在 storyreadyFired 时会立即执行 _runPhase，
    // 不需要再手动调 fn()——避免双重执行。
    SM.modules.register(name, fn, { phase: 'init', legacy: true });
  };

  // 迁移 susato-core 初始化时可能已经 push 到 _initHooks 的残留回调
  if (SM._initHooks && SM._initHooks.length) {
    for (var hi = 0; hi < SM._initHooks.length; hi++) {
      if (typeof SM._initHooks[hi] === 'function') {
        var hn = '_legacy_hook_' + hi;
        SM.modules.register(hn, SM._initHooks[hi], { phase: 'init', legacy: true });
      }
    }
    SM._initHooks.length = 0;
  }

  // ================================================================
  //  Bootstrap：声明框架模块依赖图。
  //  已迁移的模块（state-addon）在自己文件中调用 SM.modules.register()，
  //  此处仅声明尚未迁移的模块的依赖关系。
  //  修改依赖关系只改这里，不改 boot.json。
  // ================================================================

  // susato-core — 框架根模块（IIFE 加载即就绪，此处注册使依赖图可解析）
  SM.modules.register('susato-core', function () {
    return true;
  }, { phase: 'preInit', exposed: false });

  // state-addon 已在自身文件中注册 (deps: [susato-core], phase: preInit)

  SM.modules.register('npc-addon', function () {
    // npc-addon.js IIFE 已在加载时注册 API
    // init: 故事变量初始化 + Social 页渲染
    if (SM.npc && SM.npc._init) SM.npc._init();
    return SM.npc;
  }, { deps: ['susato-core', 'state-addon'], exposed: false });

  SM.modules.register('clothing-addon', function () {
    // clothing-addon.js IIFE 已在加载时注册 CL.add API
    // init: flush 排队物品到 setup.clothes + 校验 outfit 引用
    if (SM.clothing && SM.clothing._flush) SM.clothing._flush();
    return SM.clothing;
  }, { deps: ['susato-core', 'state-addon'], exposed: false });

  SM.modules.register('hair-addon', function () {
    return SM.hair;
  }, { deps: ['susato-core', 'state-addon'], exposed: false });

  SM.modules.register('skill-addon', function () {
    return SM.skill;
  }, { deps: ['susato-core', 'state-addon'], exposed: false });

  SM.modules.register('economy-addon', function () {
    return SM.economy;
  }, { deps: ['susato-core', 'state-addon'], exposed: false });

  SM.modules.register('location-addon', function () {
    return SM.location;
  }, { deps: ['susato-core'], exposed: false });

  SM.modules.register('content-addon', function () {
    return SM.content;
  }, { deps: ['susato-core'], exposed: false });

  SM.modules.register('npc-schedule', function () {
    return SM.npc && SM.npc._scheduleInited;
  }, { deps: ['npc-addon', 'state-addon'], exposed: false });

  SM.modules.register('character-addon', function () {
    return SM.character;
  }, { deps: ['susato-core', 'state-addon'], exposed: false });

  SM.modules.register('named-npc', function () {
    return SM.NamedNPC;
  }, { deps: ['susato-core'], exposed: false });

  SM.modules.register('combat-manager', function () {
    return SM.combat;
  }, { deps: ['susato-core', 'state-addon'], exposed: false });

  // i18n 已在 IIFE 中通过 SM.onInit 注册了 init 回调，这里只需声明依赖
  SM.modules.register('i18n', function () {
    return SM.i18n;
  }, { deps: ['susato-core'], exposed: false });

  SM.modules.register('manager', function () {
    return SM.manager;
  }, { deps: ['susato-core', 'state-addon'], exposed: false });

  // tab-manager 和 state-bar 纯 UI 工具，IIFE 加载即就绪，此处声明依赖
  SM.modules.register('tab-manager', function () {
    return SM.tab;
  }, { deps: ['susato-core'], exposed: false });

  SM.modules.register('state-bar', function () {
    return SM.ui && SM.ui.stateBar;
  }, { deps: ['susato-core'], exposed: false });

  // rand/migration/hook-system 无依赖，无需注册（纯工具函数，IIFE 加载即就绪）

  // ================================================================
  //  启动：storyready 时执行全部注册模块
  //  这替代了旧 susato-core _flush 中手动遍历 _initHooks 的逻辑
  // ================================================================

  SM.events.once(':storyready', function () {
    SM.events._storyreadyFired = true;
    var count = SM.modules.runAll();
    try { console.log('[module-system] 引擎初始化完成: ' + count + ' 个模块'); } catch (e) {}
  });
})();
