// ==================================================================
//  npc-schedule v1.0 -- NPC 时间状态机
//  吸收自 DoL-NewWorld (game/bailey-expansion/bailey-stats.js).
//  泛化的 NPC 日程调度: 按时段映射状态, 支持默认状态。
//
//  API:
//   SM.npc.schedule.define(name, zones)
//     定义 NPC 日程。zones = [{state, start, end}, ...]。
//     start/end 为 "HH:MM" 格式。最后一个不带 end 的为默认状态。
//     例:
//       SM.npc.schedule.define('bailey', [
//         { state: 'leaving', start: '05:30', end: '06:30' },
//         { state: 'away',    start: '06:30', end: '19:00' },
//         { state: 'asleep',  start: '02:00', end: '05:30' },
//         { state: 'home' }  // 默认
//       ]);
//
//   SM.npc.schedule.get(name, hour, minute) -> string
//     获取指定时刻的 NPC 状态。hour/minute 默认取当前游戏时间。
//     例: SM.npc.schedule.get('bailey', 20, 0) -> 'home'
//
//   SM.npc.schedule.now(name) -> string
//     当前游戏时间的 NPC 状态 (自动读取 Time.hour / Time.minute)。
//
//   SM.npc.schedule.remove(name)
//     删除已定义的日程。
//
//  依赖: 无 (纯 JS, 不依赖 SugarCube)
//  消费方: 内容 mod (隐都潜流 NPC 日程)
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (!SM.npc) SM.npc = {};
  if (SM.npc.schedule) return;

  var _schedules = {};

  function _minuteOfDay(hour, minute) {
    return (hour || 0) * 60 + (minute || 0);
  }

  function _parseTime(str) {
    if (!str) return null;
    var parts = String(str).split(':');
    return { h: parseInt(parts[0], 10) || 0, m: parseInt(parts[1], 10) || 0 };
  }

  function define(name, zones) {
    if (!name || !Array.isArray(zones) || zones.length === 0) return false;
    var parsed = [];
    for (var i = 0; i < zones.length; i++) {
      var z = zones[i];
      var start = z.start ? _parseTime(z.start) : null;
      var end = z.end ? _parseTime(z.end) : null;
      parsed.push({ state: z.state, startMin: start ? _minuteOfDay(start.h, start.m) : null, endMin: end ? _minuteOfDay(end.h, end.m) : null });
    }
    _schedules[name] = parsed;
    return true;
  }

  function get(name, hour, minute) {
    var zones = _schedules[name];
    if (!zones) return null;

    var t;
    if (hour !== undefined && minute !== undefined) {
      t = _minuteOfDay(hour, minute);
    } else {
      try {
        if (typeof Time !== 'undefined') { t = _minuteOfDay(Time.hour, Time.minute); }
        else { t = _minuteOfDay(new Date().getHours(), new Date().getMinutes()); }
      } catch (e) { t = 0; }
    }

    for (var i = 0; i < zones.length; i++) {
      var z = zones[i];
      if (z.startMin !== null && z.endMin !== null) {
        // 带 start/end 的区间: start <= t < end
        if (t >= z.startMin && t < z.endMin) return z.state;
      } else {
        // 默认状态（无 end）
        return z.state;
      }
    }
    return null;
  }

  function now(name) {
    return get(name);
  }

  function remove(name) {
    delete _schedules[name];
  }

  SM.npc.schedule = Object.freeze({
    define: define,
    get: get,
    now: now,
    remove: remove
  });
})();
