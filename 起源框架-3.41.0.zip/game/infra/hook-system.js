// ==================================================================
//  hook-system v1.0 -- 零补丁钩子系统
//  吸收自 Dol-Optimization v1.0.82 AsAPI 的 onMacro + Proxy 模式。
//  不碰游戏源码，通过宏拦截和函数代理注入逻辑。
//
//  API:
//    SM.hook.macro(name, fn)     -- 宏执行后触发（fn 在原 handler 之后调用）
//    SM.hook.macroBefore(name,fn)-- 宏执行前触发
//    SM.hook.function(name, fn, phase) -- 全局函数代理
//      phase: 'before' | 'after' | 'around'
//      'before': fn(args) 在原函数之前调用
//      'after':  fn(result, args) 在原函数之后调用
//      'around': fn(originalFn, thisArg, args) 包裹原函数
//    SM.hook.functionRestore(name) -- 恢复原始函数
//
//  依赖: SugarCube Macro API (Macro.get/delete/add)
//  消费方: 需要拦截游戏逻辑的任何模块
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.hook) return;

  var _macroHooks = {};     // name -> {before: [fn], after: [fn]}
  var _fnOriginals = {};    // name -> original function
  var _fnProxied = {};      // name -> is currently proxied

  // ---- 宏钩子 ----

  function _wrapMacro(name) {
    if (_macroHooks[name]._wrapped) return;
    _macroHooks[name]._wrapped = true;

    try {
      var originalMacro = Macro.get(name);
      if (!originalMacro) return;

      var oldHandler = originalMacro.handler;
      Macro.delete(name);
      Macro.add(name, {
        handler: function () {
          var self = this;
          var args = arguments;

          // before 钩子
          var beforeList = _macroHooks[name].before;
          for (var i = 0; i < beforeList.length; i++) {
            try { beforeList[i].apply(self, args); } catch (e) {}
          }

          // 原始逻辑
          oldHandler.apply(self, args);

          // after 钩子（异步，不阻塞原始流程）
          var afterList = _macroHooks[name].after;
          if (afterList.length) {
            setTimeout(function () {
              for (var j = 0; j < afterList.length; j++) {
                try { afterList[j].apply(self, args); } catch (e) {}
              }
            }, 10);
          }
        }
      });
    } catch (e) {
      try { console.warn('[hook-system] 宏 "' + name + '" 包装失败: ' + (e.message || e)); } catch (ignore) {}
    }
  }

  // ---- 函数代理 ----

  function _proxyFunction(name, phase) {
    if (_fnProxied[name]) return; // 已经代理过

    try {
      var parts = name.split('.');
      var fn;
      var parent = window;
      for (var i = 0; i < parts.length - 1; i++) {
        parent = parent[parts[i]];
        if (!parent) return;
      }
      var fnName = parts[parts.length - 1];
      fn = parent[fnName];
      if (typeof fn !== 'function') return;

      _fnOriginals[name] = fn;
      _fnProxied[name] = true;

      var hooks = _macroHooks['fn:' + name] || { before: [], after: [], around: [] };
      // 确保 hooks 存在
      if (!_macroHooks['fn:' + name]) {
        _macroHooks['fn:' + name] = hooks;
      }

      parent[fnName] = new Proxy(fn, {
        apply: function (target, thisArg, args) {
          // before
          for (var b = 0; b < hooks.before.length; b++) {
            try { hooks.before[b].call(thisArg, args); } catch (e) {}
          }

          var result;
          if (hooks.around.length) {
            // around: 最后一个 around 接管执行
            var wrapFn = hooks.around[hooks.around.length - 1];
            result = wrapFn.call(thisArg, target, thisArg, args);
          } else {
            result = target.apply(thisArg, args);
          }

          // after
          for (var a = 0; a < hooks.after.length; a++) {
            try { hooks.after[a].call(thisArg, result, args); } catch (e) {}
          }

          return result;
        }
      });
    } catch (e) {
      try { console.warn('[hook-system] 函数 "' + name + '" 代理失败: ' + (e.message || e)); } catch (ignore) {}
    }
  }

  // ---- 公开 API ----

  SM.hook = {
    // 宏执行后触发
    macro: function (name, fn) {
      if (typeof fn !== 'function' || !name) return;
      if (!_macroHooks[name]) _macroHooks[name] = { before: [], after: [] };
      _macroHooks[name].after.push(fn);
      _wrapMacro(name);
    },

    // 宏执行前触发
    macroBefore: function (name, fn) {
      if (typeof fn !== 'function' || !name) return;
      if (!_macroHooks[name]) _macroHooks[name] = { before: [], after: [] };
      _macroHooks[name].before.push(fn);
      _wrapMacro(name);
    },

    // 全局函数代理
    // phase: 'before' | 'after' | 'around'
    functionHook: function (name, fn, phase) {
      if (typeof fn !== 'function' || !name) return;
      phase = phase || 'after';
      var key = 'fn:' + name;
      if (!_macroHooks[key]) _macroHooks[key] = { before: [], after: [], around: [] };
      _macroHooks[key][phase].push(fn);
      _proxyFunction(name, phase);
    },

    // 恢复原始函数
    functionRestore: function (name) {
      if (!_fnProxied[name]) return false;
      try {
        var parts = name.split('.');
        var parent = window;
        for (var i = 0; i < parts.length - 1; i++) {
          parent = parent[parts[i]];
          if (!parent) return false;
        }
        var fnName = parts[parts.length - 1];
        if (_fnOriginals[name]) {
          parent[fnName] = _fnOriginals[name];
          delete _fnOriginals[name];
          _fnProxied[name] = false;
          return true;
        }
      } catch (e) {}
      return false;
    },

    // 查询钩子状态
    list: function () {
      var macros = Object.keys(_macroHooks).filter(function (k) { return !k.startsWith('fn:'); });
      var fns = Object.keys(_macroHooks).filter(function (k) { return k.startsWith('fn:'); }).map(function (k) { return k.slice(3); });
      return { macros: macros, functions: fns };
    }
  };
})();
