// ==================================================================
//  dynamic-manager v1.0 -- 动态系统统一入口
//  对标 maplebirch DynamicManager: Time + State + Weather 三合枢纽。
//  当前把已有的 SM.time / SM.vars / SM.notify 收进 SM.dynamic 命名空间。
//  StateManager 和 WeatherManager 为后续版本预留。
//
//  API:
//    SM.dynamic.time      -- 时间调度 (委托 SM.time)
//    SM.dynamic.vars      -- 变量托管 (委托 SM.vars)
//    SM.dynamic.notify    -- 统一消息 (委托 SM.notify)
//    SM.dynamic.onEnter(passage, fn)  -- 进入 passage 时执行(StateManager 占位)
//    SM.dynamic.onLeave(passage, fn)  -- 离开 passage 时执行(StateManager 占位)
//    SM.dynamic.weather   -- 天气系统(占位)
//
//  依赖: state-addon.js (SM.time, SM.vars, SM.notify)
//  消费方: 各 addon 统一通过 SM.dynamic 访问运行时设施
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.dynamic) return;

  // 进入 passage 的钩子 (StateManager gate 占位)
  var _onEnter = [];
  // 离开 passage 的钩子 (StateManager append 占位)
  var _onLeave = [];

  SM.dynamic = {
    // 时间调度 (委托)
    get time() { return SM.time; },

    // 变量托管 (委托)
    get vars() { return SM.vars; },

    // 统一消息 (委托)
    get notify() { return SM.notify; },

    // 天气 (占位)
    weather: {
      get current() { return 'clear'; },
      setLayer: function () {},
      getEffect: function () { return null; }
    },

    // ---- StateManager gate: passage 拦截替换 (吸收自 LongerCombat) ----
    // gate 在 passage 渲染后、显示前拦截，条件满足时替换内容。
    // config: { cond, output, forceExit, mode }
    //   cond:       function() -> bool    -- 触发条件
    //   output:     function() -> string  -- 替换内容(HTML/Twee宏)
    //   forceExit:  function() -> bool    -- 强制退出gate的条件(如战斗结束)
    //   mode:       'replace'|'prepend'|'append' (默认 'replace')
    _gates: [],
    gate: function (config) {
      if (!config || typeof config.cond !== 'function') return;
      config.mode = config.mode || 'replace';
      config.output = config.output || (function () { return ''; });
      SM.dynamic._gates.push(config);
    },

    // StateManager: passage 进入/离开钩子
    onEnter: function (passage, fn) {
      if (typeof fn !== 'function') return;
      _onEnter.push({ passage: passage, fn: fn });
    },

    onLeave: function (passage, fn) {
      if (typeof fn !== 'function') return;
      _onLeave.push({ passage: passage, fn: fn });
    },

    // 内部: passage 生命周期触发 (由 SusatoTextAddon 或 passageend 事件驱动)
    _fireEnter: function (passageName) {
      for (var i = 0; i < _onEnter.length; i++) {
        if (!_onEnter[i].passage || _onEnter[i].passage === passageName) {
          try { _onEnter[i].fn(passageName); } catch (e) {}
        }
      }
    },

    _fireLeave: function (passageName) {
      for (var i = 0; i < _onLeave.length; i++) {
        if (!_onLeave[i].passage || _onLeave[i].passage === passageName) {
          try { _onLeave[i].fn(passageName); } catch (e) {}
        }
      }
    }
  };

  // ---- Wikifier 状态监控 (吸收自 Dynamicest mod) ----
  // 用 Wikifier 渲染游戏宏到临时 DOM，对比前后差异，检测数值变化。
  // 完全不碰源码，兼容任何合法注册的属性/NPC/特质。
  var _watchers = [];       // [{macro, interval, lastText, onChange}]
  var _watchTimer = null;
  var _watchRunning = false;

  SM.dynamic.watch = function (macro, onChange, interval) {
    if (typeof onChange !== 'function') return;
    interval = interval || 5; // 默认每 5 个 passage 检测一次
    _watchers.push({
      macro: macro,           // 如 "<<social>>", "<<characteristics>>", "<<traits>>"
      interval: interval,
      tick: 0,
      lastMap: {},            // title -> innerText
      onChange: onChange      // function(title, oldText, newText, element)
    });
  };

  SM.dynamic._runWatchers = function () {
    if (_watchRunning) return;
    _watchRunning = true;
    try {
      for (var i = 0; i < _watchers.length; i++) {
        var w = _watchers[i];
        w.tick++;
        if (w.tick < w.interval) continue;
        w.tick = 0;

        try {
          var div = document.createElement('div');
          if (typeof Wikifier !== 'undefined') {
            new Wikifier(div, w.macro);
          } else {
            div.innerHTML = '';
            continue;
          }

          // 收集当前所有有 title 的元素
          var currentMap = {};
          var elements = div.querySelectorAll('[class*="title"], [class*="name"], .relation-name, .characteristic-title, .trait span, .relation-box, .characteristic-box, .trait');
          for (var j = 0; j < elements.length; j++) {
            var el = elements[j];
            var title = el.getAttribute('title') || el.getAttribute('data-title') || '';
            if (!title) {
              // 尝试从子元素提取标题
              var titleEl = el.querySelector('.relation-name, .characteristic-title, span');
              title = titleEl ? titleEl.innerText.trim() : el.innerText.trim().split('\n')[0];
            }
            if (title && title.length < 80) {
              currentMap[title] = { text: el.innerText, el: el };
            }
          }

          // 对比变化
          for (var title in currentMap) {
            if (Object.prototype.hasOwnProperty.call(currentMap, title)) {
              var cur = currentMap[title];
              var last = w.lastMap[title];
              if (last && last.text !== cur.text) {
                try { w.onChange(title, last.text, cur.text, cur.el); } catch (e) {}
              }
            }
          }

          // 检测新出现的条目
          for (var title in currentMap) {
            if (Object.prototype.hasOwnProperty.call(currentMap, title) && !w.lastMap[title]) {
              try { w.onChange(title, null, currentMap[title].text, currentMap[title].el); } catch (e) {}
            }
          }

          w.lastMap = currentMap;
        } catch (e) {}
      }
    } finally {
      _watchRunning = false;
    }
  };

  // 在 storyready 时挂载 passage 生命周期监听
  if (SM.onInit) {
    SM.onInit(function () {
      if (typeof $ !== 'undefined') {
        var _prevPassage = '';

        // gate 拦截：在 passage 渲染后、显示前执行
        $(document).on(':passagerender', function (ev) {
          try {
            var gates = SM.dynamic._gates;
            if (!gates || !gates.length) return;
            for (var i = 0; i < gates.length; i++) {
              var g = gates[i];
              var match = false;
              try { match = g.cond(); } catch (e) {}
              if (!match) continue;

              // forceExit 检查
              if (g.forceExit) {
                try { if (g.forceExit()) continue; } catch (e) {}
              }

              var content = '';
              try { content = g.output(); } catch (e) {}

              if (g.mode === 'replace' && ev.content) {
                ev.content.innerHTML = '';
                try { new Wikifier(ev.content, content); } catch (e) { ev.content.innerHTML = content; }
              } else if (g.mode === 'prepend' && ev.content) {
                var div = document.createElement('div');
                try { new Wikifier(div, content); } catch (e) { div.innerHTML = content; }
                ev.content.insertBefore(div, ev.content.firstChild);
              } else if (g.mode === 'append' && ev.content) {
                var div2 = document.createElement('div');
                try { new Wikifier(div2, content); } catch (e) { div2.innerHTML = content; }
                ev.content.appendChild(div2);
              }
            }
          } catch (e) {}
        });

        $(document).on(':passageend', function () {
          try {
            var current = (typeof State !== 'undefined' && State.passage) || '';
            if (_prevPassage && _prevPassage !== current) {
              SM.dynamic._fireLeave(_prevPassage);
            }
            SM.dynamic._fireEnter(current);
            SM.dynamic._runWatchers();
            _prevPassage = current;
          } catch (e) {}
        });
      }
    });
  }
})();
