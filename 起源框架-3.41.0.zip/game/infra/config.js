// ==================================================================
//  config v1.0 -- 持久化 UI 配置管理
//  对标 maplebirch Variables 类：角色/NPC/UI 偏好持久存储。
//  底层用 IndexedDB (idb-service)，降级到 localStorage。
//
//  API:
//    SM.config.get(key)            -- 读取配置项
//    SM.config.set(key, value)     -- 写入配置项
//    SM.config.all()               -- 读取全部配置 {key: value}
//    SM.config.defaults(defs)      -- 批量设置默认值(不覆盖已有)
//    SM.config.onChange(key, fn)   -- 变更回调
//
//  依赖: idb-service.js (可选降级到 localStorage)
//  消费方: character-addon, manager, palette
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};

  var _config = {};           // 内存缓存
  var _listeners = {};        // key -> [fn]
  var _storeName = 'config';
  var _useIDB = false;

  function _notify(key, value) {
    var ls = _listeners[key];
    if (ls) {
      for (var i = 0; i < ls.length; i++) {
        try { ls[i](value); } catch (e) {}
      }
    }
  }

  function _loadLegacy() {
    try {
      var raw = localStorage.getItem('susato_config');
      if (raw) {
        var parsed = JSON.parse(raw);
        for (var k in parsed) {
          if (Object.prototype.hasOwnProperty.call(parsed, k)) _config[k] = parsed[k];
        }
      }
    } catch (e) {}
  }

  function _saveLegacy() {
    try { localStorage.setItem('susato_config', JSON.stringify(_config)); } catch (e) {}
  }

  function _init() {
    // 尝试 IndexedDB，失败则降级 localStorage
    if (SM.idb && SM.idb.open) {
      SM.idb.open().then(function () {
        return SM.idb.getAll(_storeName);
      }).then(function (rows) {
        for (var i = 0; i < rows.length; i++) {
          _config[rows[i].id] = rows[i].value;
        }
        _useIDB = true;
      }).catch(function () {
        _loadLegacy();
      });
    } else {
      _loadLegacy();
    }
  }

  SM.config = {
    get: function (key) {
      return _config[key];
    },

    set: function (key, value) {
      _config[key] = value;
      _notify(key, value);
      if (_useIDB && SM.idb) {
        SM.idb.put(_storeName, { id: key, value: value }).catch(function () {});
      }
      _saveLegacy(); // 双写：IDB 失败时 localStorage 兜底
    },

    all: function () {
      var copy = {};
      for (var k in _config) {
        if (Object.prototype.hasOwnProperty.call(_config, k)) copy[k] = _config[k];
      }
      return copy;
    },

    defaults: function (defs) {
      if (!defs) return;
      for (var k in defs) {
        if (Object.prototype.hasOwnProperty.call(defs, k) && !(k in _config)) {
          _config[k] = defs[k];
        }
      }
    },

    onChange: function (key, fn) {
      if (typeof fn !== 'function') return;
      if (!_listeners[key]) _listeners[key] = [];
      _listeners[key].push(fn);
    }
  };

  // 延迟初始化：等 idb-service 加载后
  if (SM.onInit) {
    SM.onInit(function () {
      try { _init(); } catch (e) {}
    });
  } else {
    _loadLegacy();
  }
})();
