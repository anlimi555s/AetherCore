// ==================================================================
//  sm-observable v1.0 -- ObservableValue 响应式值
//  吸收自 DoL Plus (game/00-framework-tools/observable.js).
//  Vue 风格的响应式原语: 订阅/取消/DOM 绑定/自动解绑。
//
//  API:
//   var val = new SM.ObservableValue(defaultValue)
//   val.value            -- 获取/设置当前值 (setter 自动通知订阅者)
//   val.subscribe(fn)    -- 注册变更回调 fn(newValue, oldValue)
//   val.unsubscribe(fn)  -- 移除回调
//   val.bindText(el)     -- 绑定 DOM 元素 textContent, DOM 移除时自动解绑
//   val.domSubscribe(el, fn) -- DOM 订阅, 元素移除时自动解绑
//   val.peek()           -- 只读当前值, 不触发通知
//
//   SM.ObservableValue.fromObject(obj) -- 浅包装对象每个属性为 ObservableValue
//
//  特性:
//  - 嵌套 setter 排队执行, 防止无限循环 (最多 999 层)
//  - domSubscribe 在元素脱离 DOM 时自动解绑
//  - 严格相等检查: oldValue === newValue 时跳过通知
//
//  依赖: 无 (纯 JS)
//  消费方: UI 面板 / 状态栏 / 管理器
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.ObservableValue) return;

  // DOM 检测辅助
  function inDOM(node) {
    return document.body.contains(node);
  }

  function ObservableValue(defaultValue) {
    this._value = defaultValue;
    this._listeners = [];
    this._mutating = false;
    this._nextValues = null;
  }

  ObservableValue.prototype.subscribe = function (onChange) {
    if (typeof onChange !== 'function') return;
    this._listeners.push(onChange);
  };

  ObservableValue.prototype.unsubscribe = function (onChange) {
    var idx = this._listeners.indexOf(onChange);
    if (idx >= 0) this._listeners.splice(idx, 1);
  };

  ObservableValue.prototype.domSubscribe = function (element, onchange) {
    var self = this;
    this.subscribe(function (newValue, oldValue) {
      if (onchange(newValue, oldValue) === false) return false;
      return inDOM(element);
    });
    return element;
  };

  ObservableValue.prototype.bindText = function (element) {
    element.textContent = this._value;
    this.domSubscribe(element, function (newValue) {
      element.textContent = newValue;
    });
    return element;
  };

  ObservableValue.prototype.peek = function () {
    return this._value;
  };

  ObservableValue.prototype._notifyListeners = function (newValue, oldValue) {
    var remove = [];
    var listeners = this._listeners.slice();
    for (var i = 0; i < listeners.length; i++) {
      var listener = listeners[i];
      try {
        var keep = listener(newValue, oldValue);
        if (keep === false) remove.push(listener);
      } catch (e) {
        remove.push(listener);
        try { console.error('[ObservableValue] listener error:', e); } catch (ignore) {}
      }
    }
    for (var j = 0; j < remove.length; j++) {
      this.unsubscribe(remove[j]);
    }
  };

  Object.defineProperty(ObservableValue.prototype, 'value', {
    get: function () {
      return this._value;
    },
    set: function (newValue) {
      // 嵌套 setter: 排队而非立即递归
      if (this._mutating) {
        this._nextValues.push(newValue);
        return;
      }

      var oldValue = this._value;
      if (oldValue === newValue) return;
      this._value = newValue;

      this._mutating = true;
      this._nextValues = [];

      this._notifyListeners(newValue, oldValue);

      // 处理嵌套 setter 队列 (最多 999 次防止死循环)
      var n = 0;
      while (this._nextValues.length > 0) {
        if (n++ > 999) {
          try { console.error('[ObservableValue] possible infinite loop'); } catch (ignore) {}
          break;
        }
        oldValue = newValue;
        newValue = this._nextValues.shift();
        this._notifyListeners(newValue, oldValue);
      }
      this._mutating = false;
      this._nextValues = null;
    },
    enumerable: true,
    configurable: true
  });

  // 静态: 浅包装对象属性
  ObservableValue.fromObject = function (obj) {
    var keys = Object.keys(obj);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      obj[key] = new ObservableValue(obj[key]);
    }
    return obj;
  };

  SM.ObservableValue = ObservableValue;
})();
