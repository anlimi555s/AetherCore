// ==================================================================
//  enumerators v1.0 -- 双向查找枚举工厂
//  吸收自 DoL Plus (game/03-JavaScript/02-Helpers/Enumerators.js).
//  用 Object.freeze + Object.defineProperties 创建枚举。
//
//  API:
//   SM.enum.define(name, values)
//     定义命名枚举。values 为 {KEY: number, ...}。
//     返回冻结对象, 支持 KEY->value 正向查找和 .from.value(v)->"KEY" 反向查找。
//
//     例:
//       SM.enum.define('SexTypes', {
//         ALL_DICKS: 3, ALL_MALES: 2, BOTH: 0,
//         ALL_FEMALES: -2, ALL_VAGINAS: -3
//       });
//       SM.enum.SexTypes.ALL_MALES     // -> 2
//       SM.enum.SexTypes.from.value(2) // -> "ALL_MALES"
//
//   SM.enum.get(name) -> object|null
//     获取已定义的枚举。未定义返回 null。
//
//   SM.enum.list() -> string[]
//     返回所有已定义枚举名。
//
//  依赖: 无
//  消费方: 战斗系统 / 内容 mod
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.enum) return;

  var _store = {};

  function _enumBase() {
    return {
      from: {
        value: function (toFind) {
          var keys = Object.keys(this);
          for (var i = 0; i < keys.length; i++) {
            if (keys[i] !== 'from' && this[keys[i]] === toFind) return keys[i];
          }
          return null;
        },
        writable: false,
        enumerable: false,
        configurable: false
      }
    };
  }

  function define(name, values) {
    if (!name || typeof name !== 'string') return null;
    if (!values || typeof values !== 'object') return null;
    if (_store[name]) return _store[name]; // 不可重复定义

    var def = Object.freeze(Object.defineProperties(
      Object.assign({}, values),
      _enumBase()
    ));

    _store[name] = def;
    SM.enum[name] = def;
    return def;
  }

  function get(name) {
    return _store[name] || null;
  }

  function list() {
    return Object.keys(_store);
  }

  SM.enum = Object.freeze({
    define: define,
    get: get,
    list: list
  });
})();
