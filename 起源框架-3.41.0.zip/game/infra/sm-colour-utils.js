// ==================================================================
//  sm-colour-utils v1.0 -- RGB/HSL 颜色转换
//  吸收自 DoL Plus (game/03-JavaScript/02-Helpers/colour-utils.js).
//  纯函数, 无副作用, 无外部依赖。
//
//  API:
//   SM.colour.hue({r, g, b})        -> 0-360
//   SM.colour.saturation({r, g, b})  -> 0-100
//   SM.colour.lightness({r, g, b})   -> 0-100
//   SM.colour.rgbToHsl(r, g, b)      -> {h, s, l}
//   SM.colour.hslToRgb(h, s, l)      -> {r, g, b}
//   SM.colour.parse(hexOrRgb)        -> {r, g, b}  (解析 "#ff0000" 或 "rgb(255,0,0)")
//   SM.colour.lerp(c1, c2, t)        -> {r, g, b}  (线性插值)
//
//  依赖: 无
//  消费方: 主题系统 / 染色系统 / UI
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.colour) return;

  // ---- 内部: 归一化 RGB -> 中间值缓存 ----

  function ConversionObject(rgb) {
    rgb = Object.assign({}, { r: 0, g: 0, b: 0 }, rgb);
    this.rNorm = Math.clamp(rgb.r, 0, 255) / 255;
    this.gNorm = Math.clamp(rgb.g, 0, 255) / 255;
    this.bNorm = Math.clamp(rgb.b, 0, 255) / 255;
    this.cMax = Math.max(this.rNorm, this.gNorm, this.bNorm);
    this.cMin = Math.min(this.rNorm, this.gNorm, this.bNorm);
    this.delta = this.cMax - this.cMin;
  }

  function _helper(rgb) {
    return rgb instanceof ConversionObject ? rgb : new ConversionObject(rgb);
  }

  // ---- 公共 API ----

  function hue(rgb) {
    var h = _helper(rgb);
    if (h.delta === 0) return 0;
    var deg = 0;
    switch (h.cMax) {
      case h.rNorm: deg = 60 * (((h.gNorm - h.bNorm) / h.delta) % 6); break;
      case h.gNorm: deg = 60 * (((h.bNorm - h.rNorm) / h.delta) + 2); break;
      case h.bNorm: deg = 60 * (((h.rNorm - h.gNorm) / h.delta) + 4); break;
    }
    return Math.round(deg < 0 ? deg + 360 : deg);
  }

  function saturation(rgb) {
    var h = _helper(rgb);
    if (h.cMax === 0) return 0;
    return Math.round((h.delta / h.cMax) * 100);
  }

  function lightness(rgb) {
    var h = _helper(rgb);
    return Math.round(h.cMax * 100);
  }

  function rgbToHsl(r, g, b) {
    var h = _helper({ r: r, g: g, b: b });
    var hValue = hue(h);
    var sValue = saturation(h);
    var lValue = Math.round(((h.cMax + h.cMin) / 2) * 100);
    return { h: hValue, s: sValue, l: lValue };
  }

  function hslToRgb(h, s, l) {
    h = ((h % 360) + 360) % 360;
    s = Math.clamp(s, 0, 100) / 100;
    l = Math.clamp(l, 0, 100) / 100;

    if (s === 0) {
      var v = Math.round(l * 255);
      return { r: v, g: v, b: v };
    }

    var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    var p = 2 * l - q;

    function _hueToRgb(t) {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    }

    return {
      r: Math.round(_hueToRgb((h / 360 + 1 / 3) % 1) * 255),
      g: Math.round(_hueToRgb(h / 360) * 255),
      b: Math.round(_hueToRgb((h / 360 - 1 / 3 + 1) % 1) * 255)
    };
  }

  function parse(input) {
    if (!input) return null;
    var s = String(input).trim();

    // hex
    var hex = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(s) ||
              /^#?([a-f\d])([a-f\d])([a-f\d])$/i.exec(s);
    if (hex) {
      return {
        r: parseInt(hex[1].length === 1 ? hex[1] + hex[1] : hex[1], 16),
        g: parseInt(hex[2].length === 1 ? hex[2] + hex[2] : hex[2], 16),
        b: parseInt(hex[3].length === 1 ? hex[3] + hex[3] : hex[3], 16)
      };
    }

    // rgb(r, g, b)
    var rgb = /rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i.exec(s);
    if (rgb) {
      return { r: +rgb[1], g: +rgb[2], b: +rgb[3] };
    }

    return null;
  }

  function lerp(c1, c2, t) {
    t = Math.clamp(t, 0, 1);
    return {
      r: Math.round(c1.r + (c2.r - c1.r) * t),
      g: Math.round(c1.g + (c2.g - c1.g) * t),
      b: Math.round(c1.b + (c2.b - c1.b) * t)
    };
  }

  SM.colour = Object.freeze({
    hue: hue,
    saturation: saturation,
    lightness: lightness,
    rgbToHsl: rgbToHsl,
    hslToRgb: hslToRgb,
    parse: parse,
    lerp: lerp
  });
})();
