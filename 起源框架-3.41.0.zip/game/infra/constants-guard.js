// ==================================================================
//  constants-guard v1.0 -- 不可变常量保护
//  吸收自 DoL Plus (game/00-framework-tools/constants-loader.js).
//  将对象冻结为只读常量, debug 模式下修改触发报错。
//
//  API:
//   SM.constants.define(name, obj)     -- 定义命名常量对象 (Object.freeze + getter-only)
//   SM.constants.get(name)             -- 获取已注册的常量对象
//   SM.constants.wrap(obj)             -- 冻结并返回只读包装 (getter-only)
//   SM.constants.isDefined(name)       -- 检查常量是否已定义
//
//  特性:
//  - Object.freeze 阻止属性新增/删除
//  - getter 返回原值, setter 在 debug 模式触发 Errors.report
//  - 支持嵌套对象递归冻结
//  - 允许类型: boolean, number, string, bigint
//
//  依赖: 无
//  消费方: 全局常量定义
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.constants) return;

  var _store = {};
  var ALLOWED_TYPES = ['boolean', 'bigint', 'number', 'string'];

  function isAllowedType(value) {
    return ALLOWED_TYPES.indexOf(typeof value) >= 0;
  }

  function isDebug() {
    try {
      if (typeof V !== 'undefined' && V.debug) return true;
      if (typeof State !== 'undefined' && State.variables && State.variables.debug) return true;
    } catch (e) {}
    return false;
  }

  function wrapValue(value, path) {
    if (value !== null && typeof value === 'object') {
      if (Array.isArray(value)) {
        return Object.freeze(value.map(function (v) {
          return v !== null && typeof v === 'object' ? wrapValue(v, path) : v;
        }));
      }
      return wrapObject(value, path);
    }
    return value;
  }

  function wrapObject(obj, parentPath) {
    var fragment = {};
    var keys = Object.keys(obj);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      var value = obj[key];
      var fullPath = (parentPath || '') + '.' + key;

      if (value !== null && typeof value === 'object') {
        Object.defineProperty(fragment, key, {
          value: wrapValue(value, fullPath),
          writable: false,
          configurable: false,
          enumerable: true
        });
      } else if (isAllowedType(value)) {
        // 值类型: getter 返回原值, setter 在 debug 下报警
        Object.defineProperty(fragment, key, {
          get: function () { return value; },
          set: function () {
            if (!isDebug()) return;
            try { console.warn('[constants] Attempted to modify constant "' + fullPath + '"'); } catch (e) {}
            if (SM.errors && typeof SM.errors.report === 'function') {
              SM.errors.report('Modification of constant attempted: ' + fullPath, {
                key: key,
                value: value,
                path: fullPath
              });
            }
          },
          configurable: false,
          enumerable: true
        });
      }
    }
    return Object.freeze(fragment);
  }

  SM.constants = {
    define: function (name, obj) {
      if (!name || typeof name !== 'string') return false;
      if (!obj || typeof obj !== 'object') return false;
      if (_store[name]) return false; // 不可重复定义
      _store[name] = wrapObject(obj, name);
      return true;
    },

    get: function (name) {
      return _store[name] || null;
    },

    wrap: function (obj) {
      return wrapObject(obj, '');
    },

    isDefined: function (name) {
      return name in _store;
    },

    keys: function () {
      return Object.keys(_store);
    }
  };
})();
