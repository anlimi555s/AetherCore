// ==================================================================
//  sm-datetime v1.0 -- DateTime 类 + TimeConstants 不可变常量
//  吸收自 DoL Plus (game/00-framework-tools/10-time/).
//  提供完整日期时间 API: 算术/比较/月相/季节因子/星期/格式化。
//  不依赖 SugarCube, 纯 JS 实现。
//
//  API:
//   SM.DateTime.now()                    -- 当前游戏时间 DateTime
//   new SM.DateTime(2022, 9, 4, 7)      -- 从日期时间构造
//   new SM.DateTime(timestamp)           -- 从时间戳构造
//   new SM.DateTime(otherDateTime)       -- 复制构造
//
//   实例方法:
//   dt.addDays(n) / addMonths(n) / addYears(n)
//   dt.addHours(n) / addMinutes(n) / addSeconds(n)
//   dt.compareWith(other) -> {years, months, days, hours, minutes, seconds}
//   dt.dayDifference(other) -> number
//   dt.between(start, end) -> bool
//   dt.toTimestamp(year, month, day, hour, minute, second)
//   dt.fromTimestamp(timestamp)
//
//   实例 getters:
//   dt.year / month / day / hour / minute / second / timeStamp
//   dt.midnight / weekDay / weekDayName / monthName
//   dt.dayState (night/dawn/day/dusk)
//   dt.moonPhaseFraction / seasonFactor
//   dt.fractionOfDay / fractionOfYear / yearDay
//   dt.weekEnd / lastDayOfMonth / isFirstDayOfMonth / isLastDayOfMonth
//
//   静态方法:
//   SM.DateTime.isLeapYear(year) -> bool
//   SM.DateTime.getDaysOfMonthFromYear(year) -> [31,28,...]
//   SM.DateTime.getDaysOfYear(year) -> 365|366
//   SM.DateTime.MIN_DATE / MAX_DATE
//
//   常量:
//   SM.DateTime.TIME -- TimeConstants (secondsPerDay 等)
//
//  依赖: 无
//  消费方: 起源框架全部模块、内容 mod
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.DateTime) return; // 单例守卫

  // ================================================================
  //  TimeConstants -- 不可变时间常量
  // ================================================================
  var TIME = Object.freeze({
    secondsPerDay: 86400,
    secondsPerHour: 3600,
    secondsPerMinute: 60,
    minutesPerHour: 60,
    standardYearMonths: Object.freeze([31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]),
    leapYearMonths: Object.freeze([31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]),
    synodicMonth: 29.53058867,
    MIN_DATE: Object.freeze({ timeStamp: 0, year: 1, month: 1, day: 1, hour: 0, minute: 0, second: 0 }),
    MAX_DATE: Object.freeze({ timeStamp: 315537897599, year: 9999, month: 12, day: 31, hour: 23, minute: 59, second: 59 })
  });

  // ================================================================
  //  DateTime 类
  // ================================================================
  function DateTime(year, month, day, hour, minute, second) {
    if (arguments.length === 1) {
      if (year instanceof DateTime) {
        // 复制构造
        this.year = year.year;
        this.month = year.month;
        this.day = year.day;
        this.hour = year.hour;
        this.minute = year.minute;
        this.second = year.second;
        this.timeStamp = year.timeStamp;
        return;
      }
      // 从时间戳构造
      if (year < TIME.MIN_DATE.timeStamp || year > TIME.MAX_DATE.timeStamp) {
        throw new Error('DateTime: timestamp out of range [' + TIME.MIN_DATE.timeStamp + ', ' + TIME.MAX_DATE.timeStamp + ']');
      }
      this.fromTimestamp(year);
      return;
    }
    this.toTimestamp(year || 2020, month || 1, day || 1, hour || 0, minute || 0, second || 0);
  }

  // ---- 静态方法 ----

  DateTime.isLeapYear = function (year) {
    return year !== 0 && year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  };

  DateTime.getTotalDaysSinceStart = function (year) {
    return (year - 1) * 365 + Math.floor((year - 1) / 4) - Math.floor((year - 1) / 100) + Math.floor((year - 1) / 400);
  };

  DateTime.getDaysOfMonthFromYear = function (year) {
    return DateTime.isLeapYear(year) ? TIME.leapYearMonths : TIME.standardYearMonths;
  };

  DateTime.getDaysOfYear = function (year) {
    return DateTime.isLeapYear(year) ? 366 : 365;
  };

  Object.defineProperties(DateTime, {
    MIN_DATE: {
      get: function () {
        return Object.freeze(Object.assign(Object.create(DateTime.prototype), TIME.MIN_DATE));
      }
    },
    MAX_DATE: {
      get: function () {
        return Object.freeze(Object.assign(Object.create(DateTime.prototype), TIME.MAX_DATE));
      }
    },
    TIME: { value: TIME, writable: false, configurable: false }
  });

  // ---- 实例方法 ----

  DateTime.prototype.toTimestamp = function (year, month, day, hour, minute, second) {
    if (year < TIME.MIN_DATE.year || year > TIME.MAX_DATE.year) {
      throw new Error('DateTime: year must be between ' + TIME.MIN_DATE.year + ' and ' + TIME.MAX_DATE.year);
    }
    if (month < 1 || month > 12) throw new Error('DateTime: month must be 1-12');
    var daysInMonth = DateTime.getDaysOfMonthFromYear(year);
    if (day < 1 || day > daysInMonth[month - 1]) {
      throw new Error('DateTime: day must be 1-' + daysInMonth[month - 1] + ' for month ' + month);
    }

    var totalDays = DateTime.getTotalDaysSinceStart(year) +
      daysInMonth.slice(0, month - 1).reduce(function (a, b) { return a + b; }, 0) +
      day - 1;
    var totalSeconds = totalDays * TIME.secondsPerDay +
      hour * TIME.secondsPerHour + minute * TIME.secondsPerMinute + second;

    this.timeStamp = totalSeconds;
    this.year = year;
    this.month = month;
    this.day = day;
    this.hour = hour;
    this.minute = minute;
    this.second = second;
    return this;
  };

  DateTime.prototype.fromTimestamp = function (timestamp) {
    var year = 1;
    var month = 0;
    var day = Math.trunc(timestamp / TIME.secondsPerDay);
    var hour = Math.trunc(timestamp / TIME.secondsPerHour);
    var minute = Math.trunc(timestamp / TIME.secondsPerMinute);
    var second = timestamp;
    var averageDaysPerYear = 365.25;

    var remainingDays = day;
    while (remainingDays >= DateTime.getDaysOfYear(year)) {
      year += Math.trunc(remainingDays / averageDaysPerYear) || 1;
      remainingDays = day - DateTime.getTotalDaysSinceStart(year);
    }
    day = remainingDays;

    var daysPerMonth = DateTime.getDaysOfMonthFromYear(year);
    while (day >= daysPerMonth[month]) {
      day -= daysPerMonth[month++];
      if (month > 11) { month = 0; year++; }
    }

    this.timeStamp = timestamp;
    this.year = year;
    this.month = month + 1;
    this.day = day + 1;
    this.hour = hour % 24;
    this.minute = minute % 60;
    this.second = second % 60;
    return this;
  };

  DateTime.prototype.addDays = function (days) {
    if (!days) return this;
    this.fromTimestamp(this.timeStamp + days * TIME.secondsPerDay);
    return this;
  };

  DateTime.prototype.addMonths = function (months) {
    if (!months) return this;
    var addedMonths = this.month + months;
    var newYear = this.year + Math.floor((addedMonths - 1) / 12);
    var newMonth = addedMonths <= 0 ? addedMonths + 12 : ((addedMonths - 1) % 12) + 1;
    var newDay = Math.min(this.day, DateTime.getDaysOfMonthFromYear(newYear)[newMonth - 1]);
    this.toTimestamp(newYear, newMonth, newDay, this.hour, this.minute, this.second);
    return this;
  };

  DateTime.prototype.addYears = function (years) {
    if (!years) return this;
    var newYear = this.year + years;
    var daysInMonth = DateTime.getDaysOfMonthFromYear(newYear);
    var newDay = Math.min(this.day, daysInMonth[this.month - 1]);
    this.toTimestamp(newYear, this.month, newDay, this.hour, this.minute, this.second);
    return this;
  };

  DateTime.prototype.addHours = function (hours) {
    if (!hours) return this;
    this.timeStamp += hours * TIME.secondsPerHour;
    this.fromTimestamp(this.timeStamp);
    return this;
  };

  DateTime.prototype.addMinutes = function (minutes) {
    if (!minutes) return this;
    this.timeStamp += minutes * TIME.secondsPerMinute;
    this.fromTimestamp(this.timeStamp);
    return this;
  };

  DateTime.prototype.addSeconds = function (seconds) {
    if (!seconds) return this;
    this.timeStamp += seconds;
    this.fromTimestamp(this.timeStamp);
    return this;
  };

  DateTime.prototype.compareWith = function (other, getSeconds) {
    var diffSeconds = other.timeStamp - this.timeStamp;
    if (getSeconds) return diffSeconds;

    var sign = Math.sign(diffSeconds);
    diffSeconds = Math.abs(diffSeconds);

    var years = Math.floor(diffSeconds / (TIME.secondsPerDay * 365.25));
    diffSeconds -= years * TIME.secondsPerDay * 365;

    var months = Math.floor(diffSeconds / (TIME.secondsPerDay * 30));
    diffSeconds -= months * TIME.secondsPerDay * 30;

    var days = Math.floor(diffSeconds / TIME.secondsPerDay);
    diffSeconds -= days * TIME.secondsPerDay;

    var hours = Math.floor(diffSeconds / TIME.secondsPerHour);
    diffSeconds -= hours * TIME.secondsPerHour;

    var minutes = Math.floor(diffSeconds / TIME.secondsPerMinute);
    diffSeconds -= minutes * TIME.secondsPerMinute;

    return {
      years: years * sign,
      months: months * sign,
      days: days * sign,
      hours: hours * sign,
      minutes: minutes * sign,
      seconds: diffSeconds * sign
    };
  };

  DateTime.prototype.dayDifference = function (other) {
    return (other.midnight.timeStamp - this.midnight.timeStamp) / TIME.secondsPerDay;
  };

  DateTime.prototype.between = function (startDate, endDate) {
    return this.timeStamp >= startDate.timeStamp && this.timeStamp <= endDate.timeStamp;
  };

  DateTime.prototype.getFirstWeekdayOfMonth = function (weekDay) {
    var date = new DateTime(this.year, this.month, 1);
    return date.addDays((weekDay - date.weekDay + 7) % 7);
  };

  DateTime.prototype.getNextWeekdayDate = function (weekDay) {
    var days = ((7 + weekDay - this.weekDay - 1) % 7) + 1;
    return new DateTime(this).addDays(days);
  };

  DateTime.prototype.getPreviousWeekdayDate = function (weekDay) {
    var days = ((7 + weekDay - this.weekDay) % 7) - 7;
    return new DateTime(this).addDays(days);
  };

  DateTime.prototype.isFirstDayOfMonth = function () {
    return this.day === 1;
  };

  DateTime.prototype.isLastDayOfMonth = function () {
    return this.day === DateTime.getDaysOfMonthFromYear(this.year)[this.month - 1];
  };

  // ---- Getters ----

  Object.defineProperties(DateTime.prototype, {
    midnight: {
      get: function () {
        var m = new DateTime(this);
        m.timeStamp -= this.hour * TIME.secondsPerHour + this.minute * TIME.secondsPerMinute + this.second;
        m.hour = 0; m.minute = 0; m.second = 0;
        return m;
      }
    },
    weekDay: {
      get: function () {
        var daysSinceStart = DateTime.getTotalDaysSinceStart(this.year + 1);
        var daysInMonth = TIME.standardYearMonths.slice(0, this.month - 1).reduce(function (a, b) { return a + b; }, 0);
        var isLeap = DateTime.isLeapYear(this.year) && this.month < 3;
        // 2022-09-04 is Sunday (offset 6). 可通过 V.weekDayOffset 覆写.
        var offset = 6;
        try {
          if (typeof V !== 'undefined' && typeof V.weekDayOffset === 'number') offset = V.weekDayOffset;
        } catch (e) {}
        var totalDays = daysSinceStart + daysInMonth + this.day - Number(isLeap) + offset;
        return (totalDays % 7) + 1;
      }
    },
    weekDayName: {
      get: function () {
        var names = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return names[this.weekDay - 1];
      }
    },
    monthName: {
      get: function () {
        var names = ['January', 'February', 'March', 'April', 'May', 'June',
          'July', 'August', 'September', 'October', 'November', 'December'];
        return names[this.month - 1];
      }
    },
    weekEnd: {
      get: function () { return this.weekDay === 7 || this.weekDay === 1; }
    },
    lastDayOfMonth: {
      get: function () { return DateTime.getDaysOfMonthFromYear(this.year)[this.month - 1]; }
    },
    yearDay: {
      get: function () {
        var daysPerMonth = DateTime.getDaysOfMonthFromYear(this.year);
        return daysPerMonth.slice(0, this.month - 1).reduce(function (a, b) { return a + b; }, 0) + this.day;
      }
    },
    dayState: {
      get: function () {
        if (this.hour < 6) return 'night';
        if (this.hour < 9) return 'dawn';
        if (this.hour < 18) return 'day';
        if (this.hour < 21) return 'dusk';
        return 'night';
      }
    },
    moonPhaseFraction: {
      get: function () {
        var referenceNewMoon = new DateTime(2022, 1, 2, 18, 33);
        var phaseFraction = ((this.timeStamp - referenceNewMoon.timeStamp) /
          (TIME.synodicMonth * TIME.secondsPerDay)) % 1;
        phaseFraction = (phaseFraction + 1) % 1;
        if (phaseFraction >= 0.48 && phaseFraction <= 0.52) return 0.5;
        if (phaseFraction < 0.02 || phaseFraction > 0.98) return 0;
        return Math.round(phaseFraction * 100) / 100;
      }
    },
    fractionOfDay: {
      get: function () { return (this.hour * 60 + this.minute) / 1440; }
    },
    fractionOfDayFromNoon: {
      get: function () { return (((this.hour + 12) % 24) * 60 + this.minute) / 1440; }
    },
    fractionOfYear: {
      get: function () { return this.yearDay / DateTime.getDaysOfYear(this.year); }
    },
    simplifiedDayFactor: {
      get: function () {
        var timeInHours = this.hour + this.minute / 60;
        return (Math.sin((Math.PI / 12) * timeInHours - Math.PI / 2) + 1) / 2;
      }
    },
    seasonFactor: {
      get: function () {
        var summerSolstice = new DateTime(this.year, 6, 21);
        var winterSolstice = new DateTime(this.year, 12, 21);
        var previousSolstice, nextSolstice, nextSolsticeFactor;

        if (this.timeStamp < summerSolstice.timeStamp) {
          previousSolstice = new DateTime(this.year - 1, 12, 21);
          nextSolstice = summerSolstice;
          nextSolsticeFactor = 0;
        } else if (this.timeStamp < winterSolstice.timeStamp) {
          previousSolstice = summerSolstice;
          nextSolstice = winterSolstice;
          nextSolsticeFactor = 1;
        } else {
          previousSolstice = winterSolstice;
          nextSolstice = new DateTime(this.year + 1, 6, 21);
          nextSolsticeFactor = 0;
        }

        var total = nextSolstice.timeStamp - previousSolstice.timeStamp;
        var elapsed = this.timeStamp - previousSolstice.timeStamp;
        var factor = elapsed / total;
        return nextSolsticeFactor === 1 ? factor : 1 - factor;
      }
    }
  });

  // ---- 静态快捷方法 ----

  DateTime.now = function () {
    try {
      if (typeof Time !== 'undefined' && Time.date instanceof DateTime) {
        return new DateTime(Time.date);
      }
      if (typeof State !== 'undefined' && State.variables && typeof State.variables.timeStamp === 'number') {
        var startDate;
        try { startDate = State.variables.startDate; } catch (e) {}
        return new DateTime((startDate || 0) + State.variables.timeStamp);
      }
    } catch (e) {}
    return new DateTime(2022, 9, 4, 7);
  };

  SM.DateTime = DateTime;
})();
