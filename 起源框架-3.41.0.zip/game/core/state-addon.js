// ==================================================================
//  state-addon v1.1 -- 起源框架运行时地基
//  变量托管、统一消息、日界调度、时间代理。
//
//  API:
//   SusatoModel.vars.define(name, defaultValue)
//   SusatoModel.vars.defineAll({ name: default, ... })
//   SusatoModel.notify(text, style)
//   SusatoModel.notifyFlush()
//
//   SusatoModel.time.onDay(fn)
//   SusatoModel.time.onWeek(fn)
//   SusatoModel.time.every(days, fn)
//
//   SusatoModel.time.proxyPass()           -- v1.1 激活时间代理模式
//   SusatoModel.time.onPass(pos, fn)       -- v1.1 Time.pass 前后钩子
//     pos: 'before' | 'after'
//     fn(timeData): {passed, prev, current, sec, min, hour, day, week}
//   SusatoModel.time.onMinute(fn)          -- v1.1 每分钟回调
//   SusatoModel.time.onHour(fn)            -- v1.1 每小时回调
//
//  代理模式说明:
//    包装游戏原生 Time.pass，能在游戏衰减/结算之前(before)和之后(after)插入逻辑。
//    before 钩子: 游戏时间流逝前触发，适合"先保存当前值"的场景。
//    after 钩子:  游戏时间流逝后触发，适合"在游戏结算后再做处理"的场景。
//    onDay/onWeek/every 保持原有行为(在 passageend 触发，等同于 after)。
//
// 存档状态: $susatoNotices, $susatoTimeDay
//
// 依赖: susato-core.js (SusatoModel.onInit)
// 消费方: economy-addon、skill-addon、隐都潜流
// ==================================================================

(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.vars) return; // load-once 守卫
  if (!SM.onInit) {
    SM._initHooks = SM._initHooks || [];
    SM.onInit = function (fn) { SM._initHooks.push(fn); };
  }

  function _V() {
    return (typeof State !== 'undefined' && State.variables) ? State.variables : null;
  }

  function _clone(v) {
    if (v === null || typeof v !== 'object') return v;
    try { return JSON.parse(JSON.stringify(v)); } catch (e) { return v; }
  }

  // ---------------- 变量托管 ----------------

  var _defs = {}; // name -> defaultValue

  function _applyVars() {
    var V = _V();
    if (!V) return;
    for (var name in _defs) {
      if (Object.prototype.hasOwnProperty.call(_defs, name) && V[name] === undefined) {
        V[name] = _clone(_defs[name]);
      }
    }
  }

  SM.vars = {
    define: function (name, defaultValue) {
      if (typeof name !== 'string' || !name.length) return;
      if (!(name in _defs)) _defs[name] = defaultValue;
      _applyVars(); // 声明即尝试应用（storyready 之后注册的也立即生效）
    },
    defineAll: function (obj) {
      if (!obj || typeof obj !== 'object') return;
      for (var k in obj) if (Object.prototype.hasOwnProperty.call(obj, k)) {
        if (!(k in _defs)) _defs[k] = obj[k];
      }
      _applyVars();
    },
    apply: _applyVars,
  };

  // ---------------- 统一消息 ----------------

  var STYLES = { gold: 1, red: 1, teal: 1, green: 1, blue: 1 };

  function _queue() {
    var V = _V();
    if (!V) return null;
    if (!Array.isArray(V.susatoNotices)) V.susatoNotices = [];
    return V.susatoNotices;
  }

  SM.notify = function (text, style) {
    var q = _queue();
    if (!q || text === undefined || text === null || text === '') return;
    q.push({ t: String(text), c: (style && STYLES[style]) ? style : 'gold' });
  };

  SM.notifyFlush = function () {
    var q = _queue();
    if (!q || !q.length) return;
    try {
      var target = document.getElementById('passage-content') ||
                   document.querySelector('.passage');
      if (!target) return;
      var box = document.createElement('div');
      for (var i = 0; i < q.length; i++) {
        var span = document.createElement('span');
        span.className = q[i].c || 'gold';
        span.textContent = q[i].t;
        box.appendChild(span);
        box.appendChild(document.createElement('br'));
      }
      box.appendChild(document.createElement('br'));
      target.insertBefore(box, target.firstChild);
      q.length = 0;
    } catch (e) {}
  };

  // ---------------- 时间调度（日界 + 周界 + 累加器） ----------------

  var _dayHooks = [];
  var _weekHooks = [];
  var _accumHooks = []; // {period, fn, lastDay}

  function _tickDay() {
    var V = _V();
    if (!V || V.statFreeze) return;
    if (typeof Time === 'undefined' || typeof Time.days !== 'number') return;
    var today = Time.days;
    if (typeof V.susatoTimeDay !== 'number') { V.susatoTimeDay = today; return; }
    if (today === V.susatoTimeDay) return;
    if (today < V.susatoTimeDay) { V.susatoTimeDay = today; return; }
    var prev = V.susatoTimeDay;
    V.susatoTimeDay = today;

    // 日界回调
    for (var i = 0; i < _dayHooks.length; i++) {
      try { _dayHooks[i](today, prev); } catch (e) {}
    }

    // 周界回调（用 Time.days 整除判断，对齐本体周概念）
    if (typeof Time.weekDay === 'number') {
      var prevWeekDay = (prev + 3) % 7; // approximate
      // 简化：用 day diff 对 7 取模
      var dayDiff = today - prev;
      if (dayDiff > 0) {
        var crossedWeek = Math.floor(today / 7) !== Math.floor(prev / 7);
        if (crossedWeek) {
          for (var w = 0; w < _weekHooks.length; w++) {
            try { _weekHooks[w](today, prev); } catch (e) {}
          }
        }
      }
    }

    // 累加器回调（如每 28 天、每 3 天）
    for (var a = 0; a < _accumHooks.length; a++) {
      var acc = _accumHooks[a];
      if (typeof acc.lastDay !== 'number') acc.lastDay = prev;
      // 从 lastDay+1 开始逐日补结
      var d = acc.lastDay + 1;
      var cap = today + acc.period;
      while (d <= today && d <= cap) {
        // 判断 d 是否落入 period 节奏：d 与 lastDay 的差是 period 的整数倍
        if ((d - acc.lastDay) % acc.period === 0 && d > acc.lastDay) {
          try { acc.fn(d, acc.lastDay); } catch (e) {}
          acc.lastDay = d;
        }
        d++;
      }
      if (acc.lastDay < today) acc.lastDay = today;
    }
  }

  SM.time = {
    onDay: function (fn) { if (typeof fn === 'function') _dayHooks.push(fn); },
    onWeek: function (fn) { if (typeof fn === 'function') _weekHooks.push(fn); },
    every: function (days, fn) {
      if (typeof fn !== 'function' || typeof days !== 'number' || days < 1) return;
      _accumHooks.push({ period: days, fn: fn, lastDay: undefined });
    },
    lastDay: function () { var V = _V(); return V ? V.susatoTimeDay : undefined; },

    // ---- v1.1 时间代理 (吸收 SCML TimeHandle) ----

    _proxyActive: false,
    _beforeHooks: [],
    _afterHooks: [],
    _minuteHooks: [],
    _hourHooks: [],
    _origPass: null,
    _lastDateTime: null,

    // 激活代理模式: 包装 Time.pass
    proxyPass: function () {
      if (SM.time._proxyActive) return;
      if (typeof Time === 'undefined' || typeof Time.pass !== 'function' || typeof Time.date !== 'object') return;
      if (Time.pass._susatoProxy) return; // 已被包装

      SM.time._origPass = Time.pass;
      var self = SM.time;

      Time.pass = function (passtime) {
        // 构建时间数据
        var prevDate = Time.date;
        var passData = {
          passed: passtime,
          prev: prevDate,
          current: null   // 在原始 pass 后填充
        };

        // before 钩子
        for (var b = 0; b < self._beforeHooks.length; b++) {
          try { self._beforeHooks[b](passData); } catch (e) {}
        }

        // 执行原始 Time.pass
        var fragment = self._origPass(passtime) || '';

        // 获取当前时间
        var curDate = Time.date;
        passData.current = curDate;

        // 计算时间差
        if (prevDate && curDate) {
          var sec = passtime;
          var min = Math.floor(sec / 60);
          var hour = Math.floor(sec / 3600);
          var day = 0, week = 0;

          // 日界检测 (跨自然日)
          if (typeof prevDate.day === 'number' && typeof curDate.day === 'number') {
            day = curDate.day - prevDate.day;
            if (day < 0) day += (prevDate.lastDayOfMonth || 30);
            // 如果月份也变了
            if (curDate.month !== prevDate.month) {
              day = Math.floor(sec / 86400);
            }
            if (day > 0 && curDate.weekDay !== prevDate.weekDay) {
              week = 1 + Math.floor((day - 1) / 7);
            }
          }

          passData.sec = sec;
          passData.min = min;
          passData.hour = hour;
          passData.day = day;
          passData.week = week;

          // 细粒度钩子
          if (min > 0 && self._minuteHooks.length) {
            for (var m = 0; m < self._minuteHooks.length; m++) {
              try { self._minuteHooks[m](passData); } catch (e) {}
            }
          }
          if (hour > 0 && self._hourHooks.length) {
            for (var h = 0; h < self._hourHooks.length; h++) {
              try { self._hourHooks[h](passData); } catch (e) {}
            }
          }
        }

        // after 钩子
        for (var a = 0; a < self._afterHooks.length; a++) {
          try { self._afterHooks[a](passData); } catch (e) {}
        }

        return fragment;
      };
      Time.pass._susatoProxy = true;
      SM.time._proxyActive = true;
      SM.time._lastDateTime = Time.date;
    },

    // Time.pass 前后钩子
    onPass: function (pos, fn) {
      if (typeof fn !== 'function') return;
      if (pos === 'before') SM.time._beforeHooks.push(fn);
      else if (pos === 'after') SM.time._afterHooks.push(fn);
    },

    // 每分钟回调 (要求先调用 proxyPass)
    onMinute: function (fn) {
      if (typeof fn === 'function') SM.time._minuteHooks.push(fn);
    },

    // 每小时回调 (要求先调用 proxyPass)
    onHour: function (fn) {
      if (typeof fn === 'function') SM.time._hourHooks.push(fn);
    }
  };

  // ---------------- 启动 ----------------

  var _hooksSetup = false;
  function _setupHooks() {
    if (_hooksSetup || typeof $ === 'undefined') return;
    _hooksSetup = true;
    $(document).on(':passageend', function () {
      _applyVars();
      _tickDay();
      SM.notifyFlush();
    });
  }

  // 通过 ModuleSystem 注册（module-system.js 在 state-addon 之前加载时可用）
  // 降级：若 module-system 不存在，回退 SM.onInit
  if (typeof SM.modules === 'object' && typeof SM.modules.register === 'function') {
    SM.modules.register('state-addon', function () {
      _applyVars();
      _setupHooks();
    }, { deps: ['susato-core'], phase: 'preInit' });
  } else {
    SM.onInit(function () {
      _applyVars();
      _setupHooks();
    });
  }

  // jQuery :passageend 直接绑定（每页触发，非 sticky）
  if (typeof $ !== 'undefined') {
    _setupHooks();
  }
})();
