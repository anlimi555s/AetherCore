// ==================================================================
//  scene-system v1.0 -- 结构化叙事内容系统
//  吸收自 SCML Simple Framework v2.0.5 的 Scene/Event 模式。
//  场景 = 类型 + 幕 + 阶段 + 分支，让复杂分支剧情可管理。
//
//  API:
//    new SM.Scene(config)            -- 创建场景
//      config: { type, episode, title, npcs, phases, branches }
//    scene.start()                   -- 开始场景(记录 startTime + exit)
//    scene.phase(n)                  -- 进入第 n 阶段
//    scene.branch(id, data)          -- 分支记录
//    scene.isActive()                -- 场景是否活跃
//    scene.isPhase(n)                -- 是否在阶段 n
//    scene.hasBranch(id)             -- 是否走过某个分支
//    scene.end()                     -- 结束场景
//
//    SM.Scene.registerSeries(id, config) -- 注册系列场景模板
//    SM.Scene.getSeries(id)              -- 取系列模板
//
//  依赖: state-addon.js (SM.vars.define)
//  消费方: 隐都潜流 (结构化剧情/分支管理)
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.Scene) return;

  var _series = {};  // seriesId -> template config

  function Scene(config) {
    config = config || {};
    this.type = config.type || 'scene';
    this.episode = config.episode || 1;
    this.title = config.title || '';
    this.npcs = config.npcs || [];
    this.phases = config.phases || [];  // [{id, title, onEnter, onExit}]
    this.branches = [];                 // taken branch IDs
    this.maxPhase = config.phases ? config.phases.length : 0;

    this._active = false;
    this._currentPhase = 0;
    this._startTime = 0;
    this._exit = '';
    this._phaseData = {};  // phase-specific data
  }

  Scene.prototype = {
    start: function () {
      try {
        this._startTime = (typeof Time !== 'undefined' && Time.days) || 0;
        this._exit = (typeof State !== 'undefined' && State.passage) || '';
        this._active = true;
        this._currentPhase = 0;

        // 初始化场景变量
        if (SM.vars && this.title) {
          SM.vars.define('_scene_' + this.title, {
            active: true,
            phase: 0,
            branches: [],
            startTime: this._startTime
          });
        }

        // 触发 onEnter
        if (this.phases[0] && typeof this.phases[0].onEnter === 'function') {
          this.phases[0].onEnter(this);
        }
      } catch (e) {}
      return this;
    },

    phase: function (n) {
      if (!this._active) return this;
      n = parseInt(n) || 0;
      if (n < 0 || n > this.maxPhase) return this;

      var old = this._currentPhase;
      this._currentPhase = n;

      // 更新故事变量
      try {
        if (typeof V !== 'undefined' && this.title) {
          var v = V['_scene_' + this.title];
          if (v) v.phase = n;
        }
      } catch (e) {}

      // 触发旧阶段 onExit
      if (this.phases[old] && typeof this.phases[old].onExit === 'function') {
        try { this.phases[old].onExit(this); } catch (e) {}
      }

      // 触发新阶段 onEnter
      if (this.phases[n] && typeof this.phases[n].onEnter === 'function') {
        try { this.phases[n].onEnter(this); } catch (e) {}
      }

      return this;
    },

    next: function () {
      return this.phase(this._currentPhase + 1);
    },

    branch: function (id, data) {
      if (this.branches.indexOf(id) >= 0) return this;
      this.branches.push(id);
      this._phaseData['branch_' + id] = data || {};

      try {
        if (typeof V !== 'undefined' && this.title) {
          var v = V['_scene_' + this.title];
          if (v && Array.isArray(v.branches)) v.branches.push(id);
        }
      } catch (e) {}

      return this;
    },

    isActive: function () { return this._active; },
    isPhase: function (n) { return this._active && this._currentPhase === n; },
    hasBranch: function (id) { return this.branches.indexOf(id) >= 0; },
    currentPhase: function () { return this._currentPhase; },

    getData: function (key) { return this._phaseData[key]; },
    setData: function (key, value) { this._phaseData[key] = value; return this; },

    end: function () {
      this._active = false;
      try {
        if (typeof V !== 'undefined' && this.title) {
          var v = V['_scene_' + this.title];
          if (v) v.active = false;
        }
      } catch (e) {}
      return this;
    },

    // 从系列模板恢复场景状态
    restore: function () {
      try {
        if (typeof V !== 'undefined' && this.title) {
          var v = V['_scene_' + this.title];
          if (v && v.active) {
            this._active = true;
            this._currentPhase = v.phase || 0;
            this.branches = v.branches || [];
            this._startTime = v.startTime || 0;
          }
        }
      } catch (e) {}
      return this;
    }
  };

  // 工厂
  SM.Scene = function (config) { return new Scene(config); };

  // 系列模板
  SM.Scene.registerSeries = function (id, config) {
    if (!id || !config) return false;
    _series[id] = config;
    return true;
  };

  SM.Scene.getSeries = function (id) {
    return _series[id] || null;
  };

  // 从系列模板创建场景实例
  SM.Scene.fromSeries = function (seriesId, overrides) {
    var tmpl = _series[seriesId];
    if (!tmpl) return null;
    var config = {};
    for (var k in tmpl) {
      if (Object.prototype.hasOwnProperty.call(tmpl, k)) config[k] = tmpl[k];
    }
    if (overrides) {
      for (var kk in overrides) {
        if (Object.prototype.hasOwnProperty.call(overrides, kk)) config[kk] = overrides[kk];
      }
    }
    return new Scene(config);
  };
})();
