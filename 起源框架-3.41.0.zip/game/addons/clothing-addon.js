// ==================================================================
//  clothing-addon v1.2 — 衣服运行时注册框架
//  一行 add() 替代 JSON 文件 + ModdedClothesAddon + additionFile 全部中间层。
//  未指定的字段自动填槽位默认值，index 自动分配，注册期 outfit 引用校验。
//  v1.2: 适配 DoL 0.5.11.9+ —— 衣服实例化走本体 ClothesItem 类(类字段默认值
//  + autofill), 0.5.10.12 及更早自动降级纯对象。
//
//  API:
//    SusatoModel.clothing.add(slot, spec)
//    SusatoModel.clothing.addClothing(slot, spec) — 同上别名
//    slot: upper | lower | under_upper | under_lower | over_upper | over_lower | head | over_head | face | neck | hands | handheld | legs | feet
//
//  依赖: susato-core.js (SusatoModel.onInit)
//  消费方: clothing-data.js (全部衣服数据)
// ==================================================================
(function () {
  'use strict';

  window.SusatoModel = window.SusatoModel || {};
  var SC = window.SusatoModel.clothing = window.SusatoModel.clothing || {};

  // ==================== 字段默认值表（按 slot） ====================
  var BASE = {
    description: '', state_top_base: 'chest', state_base: 'waist',
    state_top: 'chest', state: 'waist',
    exposed_base: 0, exposed: 0,
    gender: 'n', femininity: 0, warmth: 0, cost: 500, plural: 0,
    colour: 0, colour_sidebar: 0, colour_combat: 0, colour_options: [],
    shop: ['clothing'], type: [],
    accessory: 0, accessory_colour: 0, accessory_colour_options: [],
    accessory_colour_sidebar: 0, accessory_colour_combat: 0,
    word: 'a', iconFile: 'placeholder.png', accIcon: 0,
    cursed: 0, location: 0, mainImage: 1, back_img: 0,
    name: '',  // auto-fill from variable if empty
  };

  var SLOT_DEFAULTS = {
    upper: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0, bustresize: 0,
      one_piece: 0, strap: 0, open: 0,
      sleeve_img: 0, sleeve_acc_img: 0,
      breast_img: 0, breast_acc_img: 0, penis_img: 0,
      leftImage: 0, rightImage: 0, notuck: 0, pregType: 0,
    },
    lower: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0, rearresize: 0,
      one_piece: 0, skirt: 0, skirt_down: 0, short: 0,
      vagina_exposed_base: 0, vagina_exposed: 0,
      anus_exposed_base: 0, anus_exposed: 0,
      collared: 0, has_collar: 0,
      sleeve_img: 0, sleeve_acc_img: 0,
    },
    under_upper: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0, bustresize: 0,
      one_piece: 0, strap: 0, open: 0,
      sleeve_img: 0, breast_img: 0, breast_acc_img: 0,
      leftImage: 0, rightImage: 0, notuck: 0, pregType: 0,
    },
    under_lower: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
      vagina_exposed_base: 0, vagina_exposed: 0,
      anus_exposed_base: 0, anus_exposed: 0,
      collared: 0, has_collar: 0,
    },
    over_upper: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0, bustresize: 0,
      one_piece: 0, strap: 0, open: 0,
      sleeve_img: 0, breast_img: 0, breast_acc_img: 0,
      leftImage: 0, rightImage: 0, notuck: 0, pregType: 0,
    },
    over_lower: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0,
      skirt: 0, skirt_down: 0, short: 0,
      vagina_exposed_base: 0, vagina_exposed: 0,
      anus_exposed_base: 0, anus_exposed: 0,
      collared: 0, has_collar: 0,
    },
    head: {
      integrity: 100, integrity_max: 100, fabric_strength: 30,
      reveal: 0,
    },
    over_head: {
      integrity: 100, integrity_max: 100, fabric_strength: 30,
      reveal: 0,
    },
    face: {
      integrity: 100, integrity_max: 100, fabric_strength: 30,
      reveal: 0,
    },
    neck: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
    },
    hands: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
    },
    handheld: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
    },
    legs: {
      integrity: 100, integrity_max: 100, fabric_strength: 20,
      reveal: 0,
    },
    feet: {
      integrity: 200, integrity_max: 200, fabric_strength: 30,
      reveal: 0, plural: 1, heels: 0,
    },
  };

  // ==================== 核心注册函数 ====================
  function _buildItem(slot, spec) {
    var defs = SLOT_DEFAULTS[slot] || {};
    var item = {};

    // 合并 BASE + slot defaults + spec
    var keys = {};
    Object.keys(BASE).forEach(function (k) { keys[k] = 1; });
    Object.keys(defs).forEach(function (k) { keys[k] = 1; });
    if (spec) { Object.keys(spec).forEach(function (k) { keys[k] = 1; }); }

    // spec 字段校验: 不在 BASE 和 slot defaults 中的 key 发出警告(以 _ 开头的私有字段除外)
    if (spec) {
      var known = {}; Object.keys(BASE).forEach(function(k){known[k]=1;}); Object.keys(defs).forEach(function(k){known[k]=1;});
      Object.keys(spec).forEach(function(k){
        if (!known[k] && k.indexOf('_') !== 0) {
          try { console.warn('[clothing-addon] unknown field "' + k + '" in item ' + (spec.variable || '(unknown)')); } catch (e) {}
        }
      });
    }

    Object.keys(keys).forEach(function (k) {
      if (spec && spec.hasOwnProperty(k)) {
        item[k] = spec[k];
      } else if (defs.hasOwnProperty(k)) {
        item[k] = defs[k];
      } else if (BASE.hasOwnProperty(k)) {
        item[k] = BASE[k];
      }
    });

    // auto-fill name from variable if missing
    if ((!item.name || item.name === '') && item.variable) {
      item.name = item.variable.toLowerCase();
    }
    // auto-fill name_cap from variable if missing
    if (!item.name_cap && item.cn_name_cap) {
      item.name_cap = item.cn_name_cap;
    }

    // 11.9+ 适配: 本体衣服定义已类化为 ClothesItem (new ClothesItem({...}))
    // 实例化后获得类字段默认值(integrity=100/warmth=0/cost=10000/accessory=0/...)
    // 与 autofill(name_cap/set/one_piece/colour_sidebar/accessory_colour_sidebar)。
    // 0.5.10.12 及更早无此类, 降级为纯对象(duck typing 兼容)。
    // 注意: 构造器会删除 undefined 字段, 故必须保证 BASE/SLOT_DEFAULTS 兜底值
    // 已覆盖框架意图的所有字段; modder 等自定义字段经 Object.keys(props) 复制保留。
    if (typeof window !== 'undefined' && typeof window.ClothesItem === 'function') {
      try {
        item = new window.ClothesItem(item);
      } catch (e) {
        try { console.warn('[clothing-addon] ClothesItem 实例化失败, 降级纯对象: ' + (e.message || e)); } catch (e2) {}
      }
    }

    return item;
  }

  function _getNextIndex(slot) {
    try {
      var arr = setup.clothes[slot];
      if (!Array.isArray(arr) || arr.length === 0) return 0;
      var max = 0;
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] && typeof arr[i].index === 'number' && arr[i].index > max) {
          max = arr[i].index;
        }
      }
      return max + 1;
    } catch (e) { return 0; }
  }

  function _inject(slot, spec) {
    if (typeof slot !== 'string') return false;
    try {
      if (typeof setup === 'undefined' || !setup.clothes) return false;
    } catch (e) { return false; }
    // 如果该 slot 数组尚未初始化，开一个空数组（不要 return false）
    if (!Array.isArray(setup.clothes[slot])) {
      setup.clothes[slot] = [];
    }

    var item = _buildItem(slot, spec);
    if (!item.variable) { return false; }

    // 去重：同 variable 不重复注册
    for (var i = 0; i < setup.clothes[slot].length; i++) {
      if (setup.clothes[slot][i] && setup.clothes[slot][i].variable === item.variable) {
        return false; // already registered
      }
    }

    item.index = (spec && spec.index && spec.index >= 0) ? spec.index : _getNextIndex(slot);
    if (!item.name || item.name === '') item.name = item.variable.toLowerCase();
    item.slot = slot;  // 商店"全部"视图用 _item.slot 定位物品所在槽位
    setup.clothes[slot].push(item);
    if (!_flushed) _injected.push(item); // flush 后统一校验; 晚注册的在 SC.add 里即时校验

    // 提示文件夹名（渲染器用 原始 variable 拼路径，不要 normaliseFileName）
    if (typeof console !== 'undefined') {
      console.log('[clothing-addon] ' + slot + '/' + item.variable + ' (index=' + item.index + ', folder=' + item.variable + ')');
    }
    return item;
  }

  // ==================== outfit 引用校验 ====================
  // 本体 getTrueWarmth / 商店人台按 (name, modder) 双等解析 outfit 配对，
  // 解析失败没有 undefined 防护，直接 "reading 'warmth'" 崩商店（Nightdress 案根因：
  // 框架把 name 自动小写化，引用里的大写字母永远配不上）。
  // 注册期把引用解析一遍，失败就报错并剥掉该 outfit 字段——宁可散件也不崩店。
  function _resolveRef(refSlot, refName, modder) {
    if (refName === 'broken' || refName === 'split') return true; // 本体损坏态占位，跳过
    var arr = setup.clothes[refSlot];
    if (!Array.isArray(arr)) return false;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && arr[i].name === refName && arr[i].modder === modder) return true;
    }
    return false;
  }

  function _validateOutfit(item) {
    var bad = [];
    if (item.outfitPrimary && typeof item.outfitPrimary === 'object') {
      Object.keys(item.outfitPrimary).forEach(function (s) {
        if (!_resolveRef(s, item.outfitPrimary[s], item.modder)) {
          bad.push('outfitPrimary.' + s + ' -> "' + item.outfitPrimary[s] + '"');
        }
      });
      if (bad.length) delete item.outfitPrimary;
    }
    if (item.outfitSecondary) {
      var sec = item.outfitSecondary;
      if (!Array.isArray(sec) || sec.length % 2 !== 0) {
        bad.push('outfitSecondary 格式错误(须 [slot, name, ...] 偶数长度)');
        delete item.outfitSecondary;
      } else {
        for (var i = 0; i < sec.length; i += 2) {
          if (!_resolveRef(sec[i], sec[i + 1], item.modder)) {
            bad.push('outfitSecondary ' + sec[i] + ' -> "' + sec[i + 1] + '"');
          }
        }
        if (bad.length) delete item.outfitSecondary;
      }
    }
    if (bad.length && typeof console !== 'undefined') {
      console.error('[clothing-addon] ' + item.slot + '/' + item.variable +
        ' outfit 引用解析失败, 已剥除 outfit 字段防商店崩溃: ' + bad.join('; ') +
        ' (解析条件是 name+modder 双等, 注意 name 缺省时会从 variable 自动小写化)');
    }
    return bad.length === 0;
  }

  // ==================== 公共 API ====================
  var _queue = [];
  var _flushed = false;
  var _injected = []; // 本框架注册成功的物品, flush 后统一校验 outfit 引用

  function _flushClothing() {
    for (var i = 0; i < _queue.length; i++) {
      _inject(_queue[i].slot, _queue[i].spec);
    }
    _queue = [];
    _flushed = true;
    // 全部注入完再统一校验(引用可以指向队列里靠后注册的物品)
    for (var k = 0; k < _injected.length; k++) {
      try { _validateOutfit(_injected[k]); } catch (e) {}
    }
    _injected = [];
    // 应用所有排队的数据补丁(在 add 之后、breast-system fixClothingData 之前)
    _applyPatches();
    // 切换为直接执行模式(晚注册的单件即时校验, 此时全量物品已在场)
    SC.add = function (slot, spec) {
      var it = _inject(slot, spec);
      if (it) { try { _validateOutfit(it); } catch (e) {} }
    };
    SC.addClothing = SC.add;
    SC.patchItem = function (slot, variable, overrides) {
      if (!slot || !variable || !overrides) return;
      var arr = setup.clothes[slot];
      if (!Array.isArray(arr)) return;
      for (var j = 0; j < arr.length; j++) {
        if (arr[j] && arr[j].variable === variable) {
          var keys = Object.keys(overrides);
          for (var k = 0; k < keys.length; k++) { arr[j][keys[k]] = overrides[keys[k]]; }
          break;
        }
      }
    };
  }

  SC.add = function (slot, spec) {
    if (!slot || !spec) return;
    if (_flushed) { _inject(slot, spec); }
    else { _queue.push({ slot: slot, spec: spec }); }
  };
  SC.addClothing = SC.add;

  // 修补现有物品: 修改 setup.clothes 中已存在的物品字段(替代 ReplacePatcher 编译期补丁)
  // SC.patchItem('upper', 'school_shirt', { breast_acc_img: 1 })
  // flush 前排队、flush 后即时执行。同 variable 的多次 patch 会合并(后覆盖前)。
  var _patches = [];
  function _applyPatches() {
    for (var i = 0; i < _patches.length; i++) {
      var p = _patches[i];
      var arr = setup.clothes[p.slot];
      if (!Array.isArray(arr)) continue;
      for (var j = 0; j < arr.length; j++) {
        if (arr[j] && arr[j].variable === p.variable) {
          var keys = Object.keys(p.overrides);
          for (var k = 0; k < keys.length; k++) { arr[j][keys[k]] = p.overrides[keys[k]]; }
          break;
        }
      }
    }
    _patches = [];
  }

  SC.patchItem = function (slot, variable, overrides) {
    if (!slot || !variable || !overrides) return;
    if (_flushed) {
      // 即时执行
      var arr = setup.clothes[slot];
      if (!Array.isArray(arr)) return;
      for (var j = 0; j < arr.length; j++) {
        if (arr[j] && arr[j].variable === variable) {
          var keys = Object.keys(overrides);
          for (var k = 0; k < keys.length; k++) { arr[j][keys[k]] = overrides[keys[k]]; }
          break;
        }
      }
    } else {
      _patches.push({ slot: slot, variable: variable, overrides: overrides });
    }
  };

  // ==================== 启动：挂到 susato-core 的共享 init 管道 ====================
  // 不再有自己的 :storyready 处理器和独立队列，全走 SusatoModel.onInit。
  // 注意：本文件可能早于 susato-core 加载，此时 SM.onInit 未定义，
  // 须改用 SM._initHooks，susato-core 加载后自动迁移。
  var SM = window.SusatoModel || {};
  SM._initHooks = SM._initHooks || [];
  SM._initHooks.push(function () {
    try { _flushClothing(); } catch (e) {}
  });
})();
