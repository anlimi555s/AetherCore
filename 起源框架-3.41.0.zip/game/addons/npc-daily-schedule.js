// ==================================================================
//  npc-daily-schedule v1.0 -- NPC 日程系统
//  对标 maplebirch NPCSchedules。声明式日程 + 位置解析。
//
//  API:
//   SusatoModel.npc.schedule(npcName, config)
//     config: {
//       daily: [{ time: 9, location: 'Boxing Gym' }, ...],
//       special: [{ condition: fn, location: 'Black Market', id: 'night' }, ...]
//     }
//
//   SusatoModel.npc.whereIs(npcName) -- 返回当前时段 NPC 所在位置
//
// 依赖: npc-addon.js, state-addon.js (SM.time)
// 消费方: 隐都潜流 (维托/凯瑟琳/迪冷)
// ==================================================================

(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM || !SM.npc) return;
  if (SM.npc._scheduleInited) return;
  SM.npc._scheduleInited = true;

  var _schedules = {}; // npcName -> { daily: [], specials: [] }

  // 解析 daily: 找到当前小时所在的 daily slot
  function _dailyLocation(daily, hour) {
    // daily slots 按 time 排序，返回最近的不超过当前小时的 slot 的 location
    var sorted = daily.slice().sort(function (a, b) { return (a.time || 0) - (b.time || 0); });
    var found = null;
    for (var i = 0; i < sorted.length; i++) {
      if (sorted[i].time <= hour) found = sorted[i];
      else break;
    }
    return found ? found.location : null;
  }

  // 解析 special: 找到第一个满足 condition 的
  function _specialLocation(specials) {
    for (var i = 0; i < specials.length; i++) {
      var s = specials[i];
      try {
        if (typeof s.condition === 'function' && s.condition()) {
          return s.location;
        }
      } catch (e) {}
    }
    return null;
  }

  SM.npc.schedule = function (npcName, config) {
    if (!npcName || !config) return false;
    if (!_schedules[npcName]) _schedules[npcName] = { daily: [], specials: [] };

    var sch = _schedules[npcName];

    // daily
    if (Array.isArray(config.daily)) {
      for (var d = 0; d < config.daily.length; d++) {
        sch.daily.push({
          time: config.daily[d].time || 0,
          location: config.daily[d].location || ''
        });
      }
    }

    // special（条件式日程）
    if (Array.isArray(config.special)) {
      for (var s = 0; s < config.special.length; s++) {
        sch.specials.push({
          id: config.special[s].id || ('spec_' + s),
          condition: config.special[s].condition || (function () { return false; }),
          location: config.special[s].location || ''
        });
      }
    }

    return true;
  };

  // 查询 NPC 当前所在位置
  SM.npc.whereIs = function (npcName) {
    var sch = _schedules[npcName];
    if (!sch) return null;

    // special 优先
    var specLoc = _specialLocation(sch.specials);
    if (specLoc) return specLoc;

    // 回退 daily
    try {
      var hour = (typeof Time !== 'undefined' && typeof Time.hour === 'number') ? Time.hour : 12;
      return _dailyLocation(sch.daily, hour);
    } catch (e) { return null; }
  };

  // 获取完整日程（供 UI 渲染）
  SM.npc.getSchedule = function (npcName) {
    return _schedules[npcName] || null;
  };
})();
