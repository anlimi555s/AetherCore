// ==================================================================
//  encounter-system v1.0 -- 声明式条件遭遇系统
//  吸收 Realistic Childbirth 的 birthDialog/birthPrompts 模式:
//    条件匹配表 + 文本变体池 + 状态效果 + 冷却/重复控制。
//  用于任何需要"按条件选文本+自动应用效果"的场景:
//    战斗对话、探索风味、NPC 互动、分娩/仪式等特殊遭遇。
//
//  API:
//    SM.encounter.define(id, config)      -- 注册遭遇模板
//    SM.encounter.get(id)                 -- 取遭遇模板
//    SM.encounter.eval(id, context)       -- 在给定 context 下评估遭遇
//      返回 { text, color, effects, matched }
//        text:    选中的文本(数组拼接为字符串)
//        color:   文本颜色标签
//        effects: 本次匹配产生的状态效果 { stress: -10, ... }
//        matched: 是否匹配到任何条目
//    SM.encounter.evalAll(id, context)    -- 返回所有匹配的条目(用于一次性展示多个)
//
//  config 格式:
//    {
//      dialog: [                          -- 对话条目表
//        [conditions, texts, effects, limit],
//        ...
//      ]
//      prompts: {                         -- 动作提示(可选)
//        slotName: {
//          actionName: [texts, color],
//          ...
//        }
//      }
//    }
//
//  conditions 格式 (声明式, 全部 AND):
//    { stat: value }      -- 精确匹配: V.stat === value
//    { stat: [min, max] } -- 范围匹配: min <= V.stat <= max
//    { stat: "string" }   -- 字符串匹配
//    {}                   -- 无条件, 始终匹配
//
//  texts 格式:
//    [["文本片段1", "文本片段2"], ["颜色1", "颜色2"]]
//    -- 每个位置随机选一个变体, 最终拼接
//    ["单文本", "颜色"]
//    -- 或简写为两元素数组
//
//  effects 格式:
//    { stress: -10, pain: 5, fatigue: 20 }
//    -- 键名对应 V 上的变量, 正加负减
//    {}  -- 无效果
//
//  limit: 冷却/次数控制
//    -1   -- 无限重复
//    0    -- 仅一次(默认)
//    N>0  -- 最多 N 次
//
//  依赖: state-addon.js (State.variables)
//  消费方: 隐都潜流 (所有结构化遭遇), 战斗系统
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('encounter')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM._encounterV1) return;

  var _registry = {};   // id -> config
  var _tracker = {};    // id -> { entryIndex: timesUsed }

  // ================================================================
  //  条件匹配
  // ================================================================
  function matchCondition(cond, V) {
    if (!cond || Object.keys(cond).length === 0) return true;
    for (var key in cond) {
      if (!Object.prototype.hasOwnProperty.call(cond, key)) continue;
      var expected = cond[key];
      var actual = V[key];

      // 数组: [min, max] 范围
      if (Array.isArray(expected) && expected.length === 2 && typeof expected[0] === 'number') {
        if (typeof actual !== 'number' || actual < expected[0] || actual > expected[1]) return false;
      }
      // 精确匹配
      else if (actual !== expected) {
        return false;
      }
    }
    return true;
  }

  // ================================================================
  //  文本选择
  // ================================================================
  function pickText(texts) {
    if (!Array.isArray(texts)) return { text: String(texts || ''), color: 'default' };

    // 格式: [["text1","text2"], ["color1","color2"]]
    if (Array.isArray(texts[0]) && Array.isArray(texts[1])) {
      var parts = texts[0];
      var colors = texts[1];
      var pickedParts = [];
      for (var i = 0; i < parts.length; i++) {
        pickedParts.push(Array.isArray(parts[i]) ? parts[i][Math.floor(Math.random() * parts[i].length)] : parts[i]);
      }
      var color = colors[Math.floor(Math.random() * colors.length)];
      return { text: pickedParts.join(''), color: color || 'default' };
    }

    // 格式: ["text", "color"]
    if (texts.length === 2 && typeof texts[0] === 'string' && typeof texts[1] === 'string') {
      return { text: texts[0], color: texts[1] };
    }

    return { text: String(texts), color: 'default' };
  }

  // ================================================================
  //  状态效果应用
  // ================================================================
  function applyEffects(effects, V) {
    if (!effects || Object.keys(effects).length === 0) return;
    for (var key in effects) {
      if (!Object.prototype.hasOwnProperty.call(effects, key)) continue;
      var delta = effects[key];
      if (typeof V[key] === 'number' && typeof delta === 'number') {
        V[key] += delta;
      }
    }
  }

  // ================================================================
  //  冷却控制
  // ================================================================
  function checkLimit(id, entryIndex, limit) {
    if (limit === undefined || limit === null) limit = 1; // 默认仅一次
    if (limit < 0) return true; // 无限

    if (!_tracker[id]) _tracker[id] = {};
    var used = _tracker[id][entryIndex] || 0;
    if (used >= limit) return false;

    _tracker[id][entryIndex] = used + 1;
    return true;
  }

  function resetTracker(id) {
    if (id) delete _tracker[id];
    else _tracker = {};
  }

  // ================================================================
  //  核心评估
  // ================================================================
  function evalEncounter(id, context, allMode) {
    var cfg = _registry[id];
    if (!cfg || !cfg.dialog) {
      return allMode ? [] : { text: '', color: 'default', effects: {}, matched: false };
    }

    var V = (context && context.V) || (typeof State !== 'undefined' && State.variables) || {};
    var dialog = cfg.dialog;
    var results = [];
    var totalEffects = {};

    for (var i = 0; i < dialog.length; i++) {
      var entry = dialog[i];
      if (!Array.isArray(entry) || entry.length < 2) continue;

      var conditions = entry[0];     // {} 或 [{stat:val}, {range}, {}, {flags}]
      var texts = entry[1];          // [["text"], ["color"]]
      var effects = entry[2] || {};  // {stat: delta}
      var limit = entry[3];          // repeat limit

      // 支持条件数组(多组条件 OR)
      var condArray = Array.isArray(conditions) && Array.isArray(conditions[0]) ? conditions : [conditions];
      // 实际用的是 4 元组条件: [静态条件, 范围条件, 一次性标记, 互斥标记]
      // 简化: 取第一个非空条件对象
      var effectiveCond = {};
      for (var c = 0; c < condArray.length; c++) {
        if (condArray[c] && typeof condArray[c] === 'object' && Object.keys(condArray[c]).length > 0) {
          Object.assign(effectiveCond, condArray[c]);
        }
      }

      if (!matchCondition(effectiveCond, V)) continue;
      if (!checkLimit(id, i, limit)) continue;

      var picked = pickText(texts);
      applyEffects(effects, V);
      Object.assign(totalEffects, effects);

      if (!allMode) {
        return { text: picked.text, color: picked.color, effects: totalEffects, matched: true, entryIndex: i };
      }
      results.push({ text: picked.text, color: picked.color, effects: Object.assign({}, effects), entryIndex: i });
    }

    if (allMode) return results;
    return { text: '', color: 'default', effects: {}, matched: false };
  }

  // ================================================================
  //  动作提示评估
  // ================================================================
  function evalPrompt(id, slot, action) {
    var cfg = _registry[id];
    if (!cfg || !cfg.prompts) return null;

    var slotPrompts = cfg.prompts[slot];
    if (!slotPrompts) return null;

    var prompt = slotPrompts[action];
    if (!prompt) return null;

    return pickText(prompt);
  }

  function evalAllPrompts(id, slots) {
    var cfg = _registry[id];
    if (!cfg || !cfg.prompts) return {};

    var result = {};
    var targetSlots = slots || Object.keys(cfg.prompts);
    for (var s = 0; s < targetSlots.length; s++) {
      var slot = targetSlots[s];
      var slotPrompts = cfg.prompts[slot];
      if (!slotPrompts) continue;
      result[slot] = {};
      for (var action in slotPrompts) {
        if (!Object.prototype.hasOwnProperty.call(slotPrompts, action)) continue;
        result[slot][action] = pickText(slotPrompts[action]);
      }
    }
    return result;
  }

  // ================================================================
  //  公开 API
  // ================================================================
  SM.encounter = {
    define: function (id, config) {
      if (!id || !config) return false;
      _registry[id] = {
        dialog: config.dialog || [],
        prompts: config.prompts || {}
      };
      return true;
    },

    get: function (id) {
      return _registry[id] || null;
    },

    eval: function (id, context) {
      return evalEncounter(id, context, false);
    },

    evalAll: function (id, context) {
      return evalEncounter(id, context, true);
    },

    prompt: function (id, slot, action) {
      return evalPrompt(id, slot, action);
    },

    prompts: function (id, slots) {
      return evalAllPrompts(id, slots);
    },

    reset: function (id) {
      resetTracker(id);
    },

    resetAll: function () {
      resetTracker(null);
    },

    list: function () {
      return Object.keys(_registry);
    }
  };

  SM._encounterV1 = true;

  // 模块注册——可能早于 module-system 加载，走 _initHooks 延迟注册
  SM._initHooks = SM._initHooks || [];
  SM._initHooks.push(function () {
    if (typeof SM.modules === 'object' && typeof SM.modules.register === 'function') {
      SM.modules.register('encounter', function () {
        return SM.encounter;
      }, { deps: ['susato-core'], phase: 'postInit' });
    }
  });

})();
