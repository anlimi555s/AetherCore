// ==================================================================
//  combat-manager v1.2 -- 战斗动作注册、选项注入与多部位文本
//  对标 maplebirch CombatManager + CombatActions +
//  吸收 Cheat Extended CE_CombatSkill (per-slot actionCond + message回调) +
//  吸收 Realistic Childbirth birthPrompts (多部位动作文本变体).
//
//  API:
//    SM.combat.add(key, config)       -- 注册战斗动作
//    SM.combat.get(key)               -- 取动作配置
//    SM.combat.list(filter)           -- 列出动作(可选过滤器)
//    SM.combat.render(options)        -- 渲染当前可用动作为选项列表
//    SM.combat.execute(key)           -- 执行指定动作
//    SM.combat.onExecute(fn)          -- 注册全局执行回调
//    SM.combat.onMessage(fn)          -- 注册消息处理回调
//    SM.combat.setSlotPrompts(slot, prompts) -- [v1.2] 注册部位动作文本
//    SM.combat.getSlotPrompt(slot, action)   -- [v1.2] 取随机文本变体
//    SM.combat.getSlotPrompts(slot)          -- [v1.2] 取部位全部文本
//
//  动作配置:
//    { key, name, cond, display, value, color, difficulty, effect, order,
//      actionType, actionCond, message }
//    cond:       function() -> bool   -- 共用条件(返回false则整体不可用)
//    display:    string               -- 显示文本
//    value:      number               -- 伤害/效果值
//    color:      string               -- 选项颜色 (red/blue/green/purple/teal/gold)
//    difficulty: number               -- 难度等级 (0-5, 影响成功率)
//    effect:     function(ctx)        -- 执行效果回调 (ctx含player/npc/target等)
//    order:      number               -- 排序权重(小在前)
//    actionType: string[]             -- 适用部位(默认['leftaction'])
//                                       如 ['leftaction','rightaction','feetaction']
//    actionCond: { slot: function() } -- 各部位额外条件(可选, 共用cond满足后二次过滤)
//                                       如 { leftaction: () => V.leftarm == 0 }
//    message:    function(ctx) -> str -- 执行后显示的消息(可选)
//
//  依赖: susato-core.js (SM.onInit)
//  消费方: 隐都潜流 (拳击馆战斗), 后续战斗内容
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('combat')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.combat && SM.combat._actionsV1) return;
  // 保留已有 SM.combat API (combat-extended 的 flow 函数等)
  // 后续 SM.combat 赋新值后合并回去
  var _existingCombat = SM.combat || {};

  var _actions = {};       // key -> config
  var _order = [];         // key[]
  var _execHooks = [];     // [(ctx, action)]
  var _msgHooks = [];      // [(ctx, action, messageText)]
  var _renderHooks = [];   // [(actionList, options)]
  var _slotPrompts = {};   // v1.2 多部位动作文本: { slot: { action: [texts, color] } }
  var _context = {
    player: null,          // { pain, arousal, fatigue, ... }
    npc: null,             // { name, health, ... }
    npcTargets: {          // 按部位索引目标 NPC (吸收自 CE ctx.target)
      left: null,
      right: null,
      feet: null,
      mouth: null,
      chest: null,
      thigh: null,
      vagina: null,
      anus: null
    },
    round: 0,
    damage: 0,
    slot: 'leftaction'     // 当前执行的部位
  };

  // 条件求值：支持函数 (()->bool)、字符串 ($var 检查)、布尔
  function _evalCond(cond) {
    if (typeof cond === 'function') {
      try { return cond(_context); } catch (e) { return true; }
    }
    if (typeof cond === 'string') {
      try {
        if (typeof State !== 'undefined' && State.variables) {
          return !!State.variables[cond];
        }
      } catch (e) { return true; }
    }
    return cond !== false;
  }

  // 默认动作模板
  var DEFAULTS = {
    color: 'blue',
    difficulty: 0,
    value: 1,
    order: 100,
    display: '',
    actionType: ['leftaction'],
    actionCond: null,
    message: null,
    cond: function () { return true; },
    effect: function () {}
  };

  function _fillDefaults(cfg) {
    var out = {};
    for (var k in DEFAULTS) {
      if (Object.prototype.hasOwnProperty.call(DEFAULTS, k)) {
        out[k] = (cfg && cfg[k] !== undefined) ? cfg[k] : DEFAULTS[k];
      }
    }
    if (cfg) {
      for (var kk in cfg) {
        if (Object.prototype.hasOwnProperty.call(cfg, kk) && !(kk in DEFAULTS)) {
          out[kk] = cfg[kk];
        }
      }
    }
    return out;
  }

  var _actionsAPI = {
    add: function (key, config) {
      if (!key) return false;
      config = config || {};
      if (!config.name && !config.display) return false;
      config.key = key;
      _actions[key] = _fillDefaults(config);
      if (_order.indexOf(key) < 0) _order.push(key);
      _order.sort(function (a, b) {
        return (_actions[a].order || 100) - (_actions[b].order || 100);
      });
      return true;
    },

    get: function (key) {
      return _actions[key] || null;
    },

    list: function (filter) {
      var out = [];
      for (var i = 0; i < _order.length; i++) {
        var a = _actions[_order[i]];
        if (!filter || filter(a, _context)) out.push(a);
      }
      return out;
    },

    remove: function (key) {
      if (!_actions[key]) return false;
      delete _actions[key];
      var idx = _order.indexOf(key);
      if (idx >= 0) _order.splice(idx, 1);
      return true;
    },

    // ---- v1.3 toNativeActions 输出 _leftaction 格式 ----
    // 替代旧 render() 手搓 HTML。输出可直接喂给 DoL 原生
    //  _leftaction["显示名"] = "key" 对象 + <<generateCombatAction>> 渲染。
    // slot: 'leftaction'|'rightaction'|'feetaction'|...
    // 返回 { displayName: key, ... } 或 {}
    toNativeActions: function (slot) {
      slot = slot || 'leftaction';
      var result = {};
      for (var i = 0; i < _order.length; i++) {
        var a = _actions[_order[i]];
        if (!_evalCond(a.cond)) continue;
        // actionType 过滤
        var types = a.actionType || ['leftaction'];
        if (types.indexOf(slot) < 0) continue;
        // actionCond 过滤
        if (a.actionCond && typeof a.actionCond[slot] === 'function') {
          try { if (!a.actionCond[slot]()) continue; } catch (e) { continue; }
        }
        var val = typeof a.value === 'function' ? a.value() : (a.value || 0);
        var label = (a.display || a.name) + (val ? ' (+' + val + ')' : '');
        result[label] = a.key;
      }
      return result;
    },

    // 渲染当前可用动作为选项列表 (保留供自定义 UI 使用)
    render: function (options) {
      if (options) {
        if (options.player) _context.player = options.player;
        if (options.npc) _context.npc = options.npc;
        if (options.round) _context.round = options.round;
        if (options.npcTargets) _context.npcTargets = options.npcTargets;
      }

      var available = [];
      for (var i = 0; i < _order.length; i++) {
        var a = _actions[_order[i]];
        if (_evalCond(a.cond)) available.push(a);
      }

      for (var r = 0; r < _renderHooks.length; r++) {
        try { _renderHooks[r](available, options || {}); } catch (e) {}
      }

      return available;
    },

    renderForSlot: function (slot, options) {
      var all = SM.combat.render(options);
      if (!slot) return all;
      return all.filter(function (a) {
        var types = a.actionType || ['leftaction'];
        if (types.indexOf(slot) < 0) return false;
        if (a.actionCond && typeof a.actionCond[slot] === 'function') {
          try { if (!a.actionCond[slot]()) return false; } catch (e) { return false; }
        }
        return true;
      });
    },

    // v1.2 多部位动作文本
    setSlotPrompts: function (slot, prompts) {
      if (!slot || !prompts) return false;
      _slotPrompts[slot] = prompts;
      return true;
    },

    getSlotPrompt: function (slot, action) {
      var slotData = _slotPrompts[slot];
      if (!slotData) return null;
      var prompt = slotData[action];
      if (!prompt) return null;

      if (Array.isArray(prompt) && Array.isArray(prompt[0])) {
        var texts = prompt[0];
        var colors = prompt[1];
        var pickedTexts = [];
        for (var i = 0; i < texts.length; i++) {
          pickedTexts.push(Array.isArray(texts[i]) ? texts[i][Math.floor(Math.random() * texts[i].length)] : texts[i]);
        }
        return { text: pickedTexts.join(''), color: (Array.isArray(colors) ? colors[Math.floor(Math.random() * colors.length)] : colors) || 'default' };
      }

      if (Array.isArray(prompt) && prompt.length === 2 && typeof prompt[0] === 'string') {
        return { text: prompt[0], color: prompt[1] || 'default' };
      }

      return { text: String(prompt), color: 'default' };
    },

    getSlotPrompts: function (slot) {
      var slotData = _slotPrompts[slot];
      if (!slotData) return null;
      var result = {};
      for (var action in slotData) {
        if (Object.prototype.hasOwnProperty.call(slotData, action)) {
          result[action] = SM.combat.getSlotPrompt(slot, action);
        }
      }
      return result;
    },

    listSlotPrompts: function () {
      return Object.keys(_slotPrompts);
    },

    execute: function (key, slot) {
      var a = _actions[key];
      if (!a) return false;
      if (!_evalCond(a.cond)) return false;

      _context.slot = slot || (a.actionType && a.actionType[0]) || 'leftaction';
      _context.damage = a.value || 1;

      try { a.effect(_context); }
      catch (e) { try { console.warn('[combat] ' + key + ' effect error: ' + (e.message || e)); } catch (ignore) {} }

      for (var i = 0; i < _execHooks.length; i++) {
        try { _execHooks[i](_context, a); } catch (e) {}
      }

      if ((_msgHooks.length > 0) && typeof a.message === 'function') {
        var msgText = '';
        try { msgText = a.message(_context) || ''; } catch (e) {}
        if (msgText) {
          for (var j = 0; j < _msgHooks.length; j++) {
            try { _msgHooks[j](_context, a, msgText); } catch (e) {}
          }
        }
      }

      return true;
    },

    onExecute: function (fn) {
      if (typeof fn === 'function') _execHooks.push(fn);
    },

    onMessage: function (fn) {
      if (typeof fn === 'function') _msgHooks.push(fn);
    },

    onRender: function (fn) {
      if (typeof fn === 'function') _renderHooks.push(fn);
    },

    context: function () {
      return {
        player: _context.player,
        npc: _context.npc,
        npcTargets: _context.npcTargets,
        round: _context.round,
        damage: _context.damage,
        slot: _context.slot
      };
    },

    reset: function () {
      _context.player = null;
      _context.npc = null;
      _context.npcTargets = {
        left: null, right: null, feet: null, mouth: null,
        chest: null, thigh: null, vagina: null, anus: null
      };
      _context.round = 0;
      _context.damage = 0;
      _context.slot = 'leftaction';
    },

    _syncNative: function () {
      try {
        if (typeof setup === 'undefined' || !Array.isArray(setup.modCombatActions)) return 0;
        var existing = {};
        for (var i = 0; i < setup.modCombatActions.length; i++) {
          if (setup.modCombatActions[i] && setup.modCombatActions[i].value) {
            existing[setup.modCombatActions[i].value] = 1;
          }
        }
        var added = 0;
        for (var j = 0; j < _order.length; j++) {
          var a = _actions[_order[j]];
          if (!a || !a.key) continue;
          if (existing[a.key]) continue;
          var native = {
            displayname: [a.name, a.name],
            value: a.key,
            type: 'leftaction',
            mainType: 'Default',
            color: a.color || 'blue',
            condition: a.cond || function () { return true; }
          };
          setup.modCombatActions.push(native);
          existing[a.key] = 1;
          added++;
        }
        return added;
      } catch (e) { return 0; }
    }
  };

  // 合并: 保留 combat-extended 已有 API, 加上动作注册 API
  if (_existingCombat) {
    SM.combat = _existingCombat;
  }
  if (!SM.combat) {
    SM.combat = {};
  }
  for (var _ak in _actionsAPI) {
    if (Object.prototype.hasOwnProperty.call(_actionsAPI, _ak)) {
      SM.combat[_ak] = _actionsAPI[_ak];
    }
  }
  SM.combat._actionsV1 = true;

  // storyready 时同步原生战斗动作
  SM._initHooks = SM._initHooks || [];
  SM._initHooks.push(function () {
    try { SM.combat._syncNative(); } catch (e) {}
  });
})();
