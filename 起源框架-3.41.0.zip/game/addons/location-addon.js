// ==================================================================
//  location-addon v1.0 -- 地点背景图层引擎
//  声明式注册自定义地点背景（base/emissive/reflective/layerTop）。
//  对标 maplebirch Patch.configureLocation，用于隐都潜流新增地点。
//
//  API:
//   SusatoModel.location.define(name, config)
//     config: { folder, base, emissive, reflective, layerTop, condition }
//     每个图层可以是 {src, opacity, blendMode} 或返回上述对象的函数
//
//   SusatoModel.location.current() -- 返回当前匹配的地点配置
//
// 依赖: susato-core.js (SM.events, SM.renderer)
// 消费方: 隐都潜流 (庄园/银行/拳馆/黑市)
// ==================================================================

(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM) return;

  // 防重复初始化
  if (SM.location && SM.location._bgInited) return;
  var _bgInited = true;

  var _locations = {};  // name -> config

  function _resolve(v, ctx) {
    if (typeof v === 'function') {
      try { return v(ctx); } catch (e) { return null; }
    }
    return v;
  }

  // 构建 HTML 字符串：多层 img 叠加 + CSS 定位
  function _buildHTML(config) {
    var layers = [];
    var folder = config.folder || '';
    if (folder && !folder.endsWith('/')) folder += '/';

    var defs = [
      { key: 'base', z: 0 },
      { key: 'reflective', z: 1 },
      { key: 'emissive', z: 2 },
      { key: 'layerTop', z: 3 }
    ];

    for (var i = 0; i < defs.length; i++) {
      var d = defs[i];
      var layer = _resolve(config[d.key]);
      if (!layer || !layer.src) continue;
      var src = folder + layer.src;
      var opacity = layer.opacity !== undefined ? layer.opacity : 1;
      var blend = layer.blendMode || 'normal';
      layers.push(
        '<img src="' + src + '" ' +
        'style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;' +
        'z-index:' + d.z + ';opacity:' + opacity + ';' +
        (blend !== 'normal' ? 'mix-blend-mode:' + blend + ';' : '') +
        '" ' +
        'data-susato-location="' + d.key + '">'
      );
    }
    return layers.length ?
      '<div class="susato-location-bg" style="position:absolute;inset:0;overflow:hidden;pointer-events:none;">' +
      layers.join('') + '</div>' : '';
  }

  // 注入到当前 passage DOM
  function _injectToDOM(html) {
    try {
      var target = document.getElementById('passage-content') ||
                   document.querySelector('.passage');
      if (!target) return;
      // 防重复
      var existing = target.querySelector('.susato-location-bg');
      if (existing) existing.parentNode.removeChild(existing);
      // 插入为 passage-content 的第一个子元素
      var wrap = document.createElement('div');
      wrap.innerHTML = html;
      var el = wrap.firstChild;
      if (el) target.insertBefore(el, target.firstChild);
    } catch (e) {}
  }

  SM.location = SM.location || {};
  SM.location._bgInited = true;

  SM.location.define = function (name, config) {
      if (!name || !config) return false;
      _locations[name] = config;
      return true;
    };

  // 移除地点配置
  SM.location.remove = function (name) {
      delete _locations[name];
    };

  // 获取当前生效的地点配置（按 $location 匹配）
  SM.location.current = function () {
      try {
        var loc = (typeof V !== 'undefined' && V.location) || '';
        // 精确匹配优先
        if (_locations[loc]) return _locations[loc];
        // 遍历 condition
        for (var n in _locations) {
          if (Object.prototype.hasOwnProperty.call(_locations, n)) {
            var cfg = _locations[n];
            var cond = _resolve(cfg.condition);
            if (cond) return cfg;
          }
        }
      } catch (e) {}
      return null;
    };

  // 手动应用指定地点背景
  SM.location.apply = function (name) {
      var cfg = _locations[name || ''] || this.current();
      if (!cfg) return false;
      var html = _buildHTML(cfg);
      if (html) _injectToDOM(html);
      return !!html;
    };

  // 获取所有已注册地点名
  SM.location.list = function () {
      return Object.keys(_locations);
    };

  // 每次进入新 passage 自动应用（passageend 走 jQuery，非 sticky）
  if (typeof $ !== 'undefined') {
    $(document).on(':passageend', function () {
      SM.location.apply();
    });
  }
})();
