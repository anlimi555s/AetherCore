// ==================================================================
//  character-addon v1.1 -- 统一角色系统
//  角色身份单一事实源，协调改脸/身体部件/变形/宠物各子系统。
//  不替代现有系统(SM.model/SM.breast等)，提供注册、协调和管线钩子。
//
//  API:
//    SM.character.identity          -- 当前角色身份快照(只读)
//    SM.character.faces.*           -- 改脸注册/选择/仪态
//    SM.character.body.*            -- 身体部件配置注册
//    SM.character.use/process       -- pre/post 管线钩子
//    SM.character.transform.*       -- 变形管线(占位)
//    SM.character.pet.*             -- 宠物(占位)
//    SM.character.mask(x,rot,swap,w,h) -- 面具变换参数(v1.1)
//    SM.character.patchCanvasModel()   -- CanvasModel 预处理注入(v1.1)
//    SM.character.faceStyleSrcFn(name) -- 脸型图层 srcfn 工厂(v1.1)
//
//  依赖: susato-core.js (SM.events, SM.renderer, SM.onInit)
//         state-addon.js (SM.vars.define)
//         model-addon.js (SM.model -- 可选，不存在时自维护注册表)
//  消费方: 内容包(breast-system/righthand等迁移目标)、隐都潜流(变形/宠物)
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('character')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.character) return;

  // ---- 私有状态 ----
  var _identity = {
    face: '',
    posture: '',
    bodyMods: {},
    transforms: {}
  };

  var _bodyParts = {};       // partName -> config
  var _transforms = {};      // name -> {type, options, level}
  var _pets = {};            // id -> config
  var _preHooks = [];        // [{handler, target}]
  var _postHooks = [];       // [{handler, target}]
  var _ownFaceRegistry = {}; // 降级自维护注册表(SM.model不存在时)
  var _ownFaceOrder = [];

  // ---- 内部工具 ----

  function _matchTarget(target, modelName, model) {
    if (!target) return true;
    if (typeof target === 'string') return modelName === target;
    if (Array.isArray(target)) return target.indexOf(modelName) >= 0;
    if (typeof target === 'function') {
      try { return target(modelName, model); } catch (e) { return false; }
    }
    return false;
  }

  function _loadFaceFromStorage() {
    try { return localStorage.getItem('susato_model_selected') || ''; } catch (e) { return ''; }
  }

  function _loadPostureFromStorage() {
    try { return localStorage.getItem('susato_posture_selected') || ''; } catch (e) { return ''; }
  }

  function _syncIdentityFromModel() {
    if (SM.model) {
      _identity.face = SM.model.current() || '';
      _identity.posture = SM.model.currentPosture() || '';
    } else {
      _identity.face = _loadFaceFromStorage();
      _identity.posture = _loadPostureFromStorage();
    }
  }

  // ---- 公开 API ----

  SM.character = {
    // identity 是只读快照。修改走 faces.select / transform.apply 等专用方法。
    get identity() {
      _syncIdentityFromModel();
      return {
        face: _identity.face,
        posture: _identity.posture,
        bodyMods: _identity.bodyMods,
        transforms: _identity.transforms
      };
    },

    // ======== 脸型/人模 ========
    faces: {
      register: function (cfg) {
        if (!cfg || !cfg.id || !cfg.name) return false;
        if (SM.model) return SM.model.register(cfg);
        // 降级：自维护
        if (_ownFaceRegistry[cfg.id]) return false;
        cfg.prefix = cfg.prefix || ('img/' + cfg.id);
        _ownFaceRegistry[cfg.id] = cfg;
        _ownFaceOrder.push(cfg.id);
        return true;
      },

      select: function (id) {
        id = id || '';
        if (SM.model) {
          var ok = SM.model.select(id);
          if (ok) _identity.face = id;
          return ok;
        }
        // 降级
        if (id && !_ownFaceRegistry[id]) return false;
        _identity.face = id;
        _identity.posture = '';
        try { localStorage.setItem('susato_model_selected', id); } catch (e) {}
        try { localStorage.setItem('susato_posture_selected', ''); } catch (e) {}
        return true;
      },

      current: function () {
        if (SM.model) return SM.model.current();
        return _identity.face;
      },

      list: function () {
        if (SM.model) return SM.model.list();
        var out = [];
        for (var i = 0; i < _ownFaceOrder.length; i++) out.push(_ownFaceRegistry[_ownFaceOrder[i]]);
        return out;
      },

      listPostures: function (faceId) {
        if (SM.model) return SM.model.listPostures(faceId);
        return [];
      },

      selectPosture: function (faceId, postureId) {
        if (SM.model) {
          var ok = SM.model.selectPosture(faceId, postureId);
          if (ok) _identity.posture = postureId || '';
          return ok;
        }
        return false;
      },

      currentPosture: function () {
        if (SM.model) return SM.model.currentPosture();
        return _identity.posture;
      }
    },

    // ======== 身体部件配置 ========
    body: {
      register: function (partName, config) {
        if (!partName || !config) return false;
        _bodyParts[partName] = config;
        return true;
      },

      get: function (partName) {
        return _bodyParts[partName] || null;
      },

      list: function () {
        var out = [];
        for (var k in _bodyParts) {
          if (Object.prototype.hasOwnProperty.call(_bodyParts, k)) {
            out.push({ name: k, config: _bodyParts[k] });
          }
        }
        return out;
      }
    },

    // ======== 管线钩子 ========
    // type: 'pre' | 'post'
    // handler: function(options, model) -- model 可能为 undefined
    // target: 可选筛选器 (string | string[] | function(modelName, model))
    use: function (type, handler, target) {
      if (typeof handler !== 'function') return this;
      if (type === 'pre') {
        _preHooks.push({ handler: handler, target: target || null });
      } else if (type === 'post') {
        _postHooks.push({ handler: handler, target: target || null });
      }
      return this;
    },

    // 手动触发已注册的管线处理器
    process: function (type, options, model) {
      if (!options) return;
      var modelName = (model && model.name) || (options.name) || '';
      var hooks = type === 'pre' ? _preHooks : (type === 'post' ? _postHooks : null);
      if (!hooks) return;
      for (var i = 0; i < hooks.length; i++) {
        var h = hooks[i];
        if (_matchTarget(h.target, modelName, model)) {
          try { h.handler(options, model); } catch (e) {}
        }
      }
    },

    // ======== 变形管线(占位) ========
    transform: {
      register: function (name, type, options) {
        if (!name || !type) return false;
        _transforms[name] = { type: type, options: options || {}, level: 0 };
        return true;
      },

      apply: function (name, change) {
        var t = _transforms[name];
        if (!t) return false;
        t.level = Math.max(0, Math.min(10, (t.level || 0) + (change || 0)));
        _identity.transforms[name] = t.level;
        return true;
      },

      level: function (name) {
        var t = _transforms[name];
        return t ? t.level : 0;
      },

      list: function () {
        var out = [];
        for (var k in _transforms) {
          if (Object.prototype.hasOwnProperty.call(_transforms, k)) {
            out.push({ name: k, type: _transforms[k].type, level: _transforms[k].level });
          }
        }
        return out;
      }
    },

    // ======== 宠物(占位) ========
    pet: {
      register: function (config) {
        if (!config || !config.id) return false;
        _pets[config.id] = config;
        return true;
      },

      render: function (id, target, options) {
        // 占位：后续版本实现 CanvasModel 宠物渲染
        return false;
      },

      remove: function (id) {
        if (!_pets[id]) return false;
        delete _pets[id];
        return true;
      }
    },

    // ======== 脸型 srcfn 工厂（对标 maplebirch faceStyleSrcFn）========
    // 根据脸型参数动态计算图层图片路径。
    // name: 字符串模板("img/face/{facestyle}/{facevariant}.png") 或 function(options) -> path
    // 返回: function(layerOptions) -> path (可用作 CanvasModel 图层的 srcfn)
    faceStyleSrcFn: function (name) {
      if (typeof name === 'function') {
        return function (layerOptions) {
          var opts = layerOptions || {};
          if (!opts.facestyle) opts.facestyle = SM.character.identity.face || 'default';
          if (!opts.facevariant) opts.facevariant = 'default';
          var result = name(opts);
          return Array.isArray(result) ? result[0] : result;
        };
      }
      var template = String(name || 'img/face/{facestyle}/{facevariant}.png');
      return function (layerOptions) {
        var opts = layerOptions || {};
        var fs = opts.facestyle || SM.character.identity.face || 'default';
        var fv = opts.facevariant || 'default';
        return template.replace(/\{facestyle\}/g, fs).replace(/\{facevariant\}/g, fv);
      };
    },

    // ======== mask() -- 面具变换参数 (v1.1) ========
    // 对标 maplebirch mask()：返回画布变换参数字符串。
    // x: 水平偏移(px), rotation: 旋转角度(deg), swap: 水平翻转, width/height: 目标尺寸
    // 返回格式可用作 canvas drawImage 参数或 CSS transform
    mask: function (x, rotation, swap, width, height) {
      var parts = [];
      if (x !== undefined && x !== 0) parts.push('x:' + x);
      if (rotation) parts.push('rot:' + rotation);
      if (swap) parts.push('swap:1');
      if (width) parts.push('w:' + width);
      if (height) parts.push('h:' + height);
      return parts.join(',');
    },

    // ======== patchCanvasModel -- CanvasModel 预处理注入 (v1.1) ========
    // 对标 maplebirch Character.patchCanvasModel：
    // 在 CanvasModel.compile 前注入 pre 处理器，compile 后注入 post 处理器。
    // 必须在 :storyready 之前调用(编译期装，不能等事件)。
    patchCanvasModel: function () {
      if (SM.character._canvasPatched) return;
      SM.character._canvasPatched = true;

      try {
        if (typeof CanvasModel === 'undefined') return;
        var _origCompile = CanvasModel.prototype.compile;
        var self = this;

        CanvasModel.prototype.compile = function () {
          // pre: 编译前同步身份 + 跑 pre 处理器
          self.process('pre', this.options || {}, this);

          // 原始 compile
          var result = _origCompile.apply(this, arguments);

          // post: 编译后跑 post 处理器(拿到最终 spec)
          if (this._spec) {
            for (var i = 0; i < this._spec.length; i++) {
              self.process('post', this._spec[i], this);
            }
          }

          return result;
        };
      } catch (e) {
        try { console.warn('[character-addon] patchCanvasModel: ' + (e.message || e)); } catch (ignore) {}
      }
    }
  };

  // ---- 渲染管线集成 ----

  // 在 onCompile 中注册最优先钩子：先同步身份 -> 跑 pre 处理器 -> 让下游钩子跑 -> 跑 post 处理器
  var _compileHookInstalled = false;

  function _installCompileHook() {
    var SR = SM.renderer;
    if (!SR || !SR.onCompile || _compileHookInstalled) return;
    _compileHookInstalled = true;

    SR.onCompile(function (specs) {
      if (!specs) return specs;

      // 1. 同步身份状态
      _syncIdentityFromModel();

      // 2. 对每个 spec 跑 pre 处理器
      // (specs 是编译后的图层数组，每个 spec 有 src/name 等字段)
      for (var i = 0; i < specs.length; i++) {
        SM.character.process('pre', specs[i], null);
      }

      // 3. 让下游钩子正常处理(不干预)

      // 4. post 处理器在返回前跑
      for (var j = 0; j < specs.length; j++) {
        SM.character.process('post', specs[j], null);
      }

      return specs;
    });
  }

  // ---- 初始化 ----

  function _init() {
    // 同步初始身份
    _syncIdentityFromModel();

    // 安装渲染钩子
    _installCompileHook();

    // 注册默认身体部件(来自现有系统，仅声明存在)
    if (SM.breast) {
      SM.character.body.register('breast', {
        description: '胸差系统 (breast-system v3.0)',
        managedBy: 'breast-system'
      });
    }

    // 将已有 bodyMods 从 identity 同步到 body registry
    // (后续版本各系统迁移时通过 SM.character.body.register 自行注册)
  }

  SM._initHooks = SM._initHooks || [];
  SM._initHooks.push(function () {
    try { _init(); } catch (e) {
      try { console.warn('[character-addon] init error: ' + (e.message || e)); } catch (ignore) {}
    }
  });
})();
