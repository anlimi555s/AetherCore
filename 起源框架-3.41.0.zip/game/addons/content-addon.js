// ==================================================================
//  content-addon v1.0 -- 注册式内容注入
//  对标 maplebirch Patch.addAntiques / addFoodstuff / addBodywriting。
//  手写数据表 -> 一行 register 注册。
//
//  API:
//   SusatoModel.content.registerAntique(key, config)
//     config: { name, cn_name, hint, museum, journal, icon }
//
//   SusatoModel.content.registerFoodstuff(key, config)
//     config: { name, singular, plural, icon, tending, shop, recipe, food }
//
//   SusatoModel.content.listAntiques() / listFoodstuffs()
//
// 依赖: susato-core.js (SM.events)
// 消费方: 隐都潜流 (黑市古董商/庄园厨房)
// ==================================================================

(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM || SM.content) return;

  var _antiques = {};
  var _foodstuffs = {};
  var _bodywritings = {};

  SM.content = {
    // ---- 古董 ----
    registerAntique: function (key, config) {
      if (!key || !config) return false;
      if (_antiques[key]) return false; // 去重
      config.key = key;
      _antiques[key] = config;

      // 自动注入到本体古董系统
      SM.onInit(function () {
        try {
          if (typeof V !== 'undefined' && V.museumAntiques && V.museumAntiques.antiques) {
            if (V.museumAntiques.antiques[key] === undefined) {
              V.museumAntiques.antiques[key] = 'notFound';
            }
          }
          // 注册到 _museumAntiqueText widget 所需的全局数据
          if (!window._susatoAntiques) window._susatoAntiques = {};
          window._susatoAntiques[key] = config;
        } catch (e) {}
      });

      return true;
    },

    listAntiques: function () {
      return Object.keys(_antiques).map(function (k) { return _antiques[k]; });
    },

    getAntique: function (key) { return _antiques[key] || null; },

    // ---- 食材 ----
    registerFoodstuff: function (key, config) {
      if (!key || !config) return false;
      if (_foodstuffs[key]) return false;
      config.key = key;
      _foodstuffs[key] = config;

      // 注入到本体食材系统
      SM.onInit(function () {
        try {
          if (!setup || !setup.foodstuffs) return;
          if (!setup.foodstuffs.find(function (f) { return f.key === key || f.name === config.name; })) {
            setup.foodstuffs.push(config);
          }
        } catch (e) {}
      });

      return true;
    },

    listFoodstuffs: function () {
      return Object.keys(_foodstuffs).map(function (k) { return _foodstuffs[k]; });
    },

    // ---- 身体涂写 ----
    registerBodywriting: function (key, config) {
      if (!key || !config) return false;
      if (_bodywritings[key]) return false;
      config.key = key;
      _bodywritings[key] = config;

      SM.onInit(function () {
        try {
          if (!setup || !setup.bodywritings) return;
          if (!setup.bodywritings.find(function (b) { return b.key === key || b.writing === config.writing; })) {
            setup.bodywritings.push(config);
          }
        } catch (e) {}
      });

      return true;
    },

    listBodywritings: function () {
      return Object.keys(_bodywritings).map(function (k) { return _bodywritings[k]; });
    }
  };
})();
