// ==================================================================
//  action-parser v1.0 -- 动作文本解析引擎
//  吸收 Multi_UI Alpha ActionParser 的 regex 分类逻辑。
//  将 combat/sex 动作的 value+label 文本解析为结构化分类：
//  动词类别、身体部位、衣物槽位，供动作图标渲染使用。
//
//  API:
//    SM.ui.actionParser.parse(actionValue, labelText) -> object
//      actionValue: string (一般来自 input.value 或 dataset)
//      labelText:   string (可选, 完整标签文本用于辅助匹配)
//      returns: { verb, category, bodyPart, clothingSlot, noFlip }
//        verb:        匹配的动词名 (string|null)
//        category:    动作大类 (string|null) -- 用于图标/样式选择
//        bodyPart:    匹配的身体部位 (string|null)
//        clothingSlot:检测到的衣物槽位 (string|null)
//        noFlip:      是否禁止翻转 (boolean)
//
//    SM.ui.actionParser.clearCache()
//      清除全部解析缓存 (passageend 时自动调用)
//
//  依赖: susato-core, jQuery (:passageend)
//  消费方: 战斗UI, 动作栏, 任何需要动作分类的模块
// ==================================================================
(function () {
  'use strict';

  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('action-parser')) return;

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.ui && SM.ui._actionParserV1) return;

  // ================================================================
  //  动词模式库
  //  每条记录: { regex, category, name }
  //    regex:    匹配动作文本的正则 (大小写不敏感)
  //    category: 动作大类, 用于图标和样式分组
  //    name:     动词名, 返回给调用方用于精确标识
  //
  //  分类体系:
  //    combat:   strike, slap, kick, headbutt, bite
  //    fending:  dodge, struggle, resist, escape
  //    intimate: touch, grab, pinch, penetrate, finger, masturbate, tease
  //    oral:     kiss, lick, suck, spit, swallow
  //    dress:    pull_up, pull_down, pull_away, displace, undress, cover
  //    social:   ask, demand, plead, apologize, mock
  //    vocal:    scream, moan
  //    state:    rest, submit, stop, wait
  //    swim:     swim
  // ================================================================
  var _verbPatterns = [
    // -- combat --
    { regex: /\bpunch\b|\bhitting?\b|\bstrike\b/i,   category: 'combat',   name: 'strike' },
    { regex: /\bslap(?:ping)?\b|\bsmack\b/i,          category: 'combat',   name: 'slap' },
    { regex: /\bkick(?:ing)?\b|\bstomp\b/i,           category: 'combat',   name: 'kick' },
    { regex: /\bheadbutt(?:ing)?\b|\bbutt\b/i,        category: 'combat',   name: 'headbutt' },
    { regex: /\bbite(?:ing)?\b|\bchomp\b/i,           category: 'combat',   name: 'bite' },
    { regex: /\bclaw\b|\bscratch(?:ing)?\b|\bscratch\b/i, category: 'combat', name: 'claw' },

    // -- fending --
    { regex: /\bdodge(?:ing)?\b|\bavoid\b/i,                    category: 'fending', name: 'dodge' },
    { regex: /\bstrug(?:gle|gling)\b|\bthrash\b/i,              category: 'fending', name: 'struggle' },
    { regex: /\bresist(?:ing)?\b|\bfight\s*back\b|\bdefy\b/i,  category: 'fending', name: 'resist' },
    { regex: /\bescape?(?:ing)?\b|\bflee\b|\brun\s+away\b/i,    category: 'fending', name: 'escape' },

    // -- intimate --
    { regex: /\bstrok(?:e|ing)\b|\bcaress\b|\brub(?:bing)?\b|\bmassage\b/i, category: 'intimate', name: 'touch' },
    { regex: /\bgrab(?:bing)?\b|\bgrasp\b|\bgrip(?:ping)?\b|\bsqueez(?:e|ing)\b/i, category: 'intimate', name: 'grab' },
    { regex: /\bpinch(?:ing)?\b|\btweak\b/i,              category: 'intimate', name: 'pinch' },
    { regex: /\bfinger(?:ing)?\b|\bdigit\b/i,              category: 'intimate', name: 'finger' },
    { regex: /\bpenetra(?:te|ting)\b|\bfuck(?:ing)?\b|\benter(?:ing)?\b/i, category: 'intimate', name: 'penetrate' },
    { regex: /\bmasturbat(?:e|ing)\b|\bjack(?:ing)?\b|\bjill(?:ing)?\b|\bfondl(?:e|ing)\b/i, category: 'intimate', name: 'masturbate' },
    { regex: /\bteas(?:e|ing)\b|\btantaliz(?:e|ing)\b/i,   category: 'intimate', name: 'tease' },

    // -- oral --
    { regex: /\bkiss(?:ing)?\b|\bpeck\b/i,                  category: 'oral', name: 'kiss' },
    { regex: /\blic(?:k|king)\b|\bsuck(?:ing)?\b/i,         category: 'oral', name: 'oral' },
    { regex: /\bspit(?:ting)?\b|\bdrool\b/i,                category: 'oral', name: 'spit' },
    { regex: /\bswallow(?:ing)?\b|\bgulp\b/i,               category: 'oral', name: 'swallow' },

    // -- dress --
    { regex: /\bpull\s*away\b|\bwithdraw\b|\brecede?\b/i,           category: 'dress', name: 'pull away' },
    { regex: /\bpull\s*up\b|\brais(?:e|ing)\b|\blift(?:ing)?\b/i,   category: 'dress', name: 'pull up' },
    { regex: /\bpull\s*down\b|\blower(?:ing)?\b|\bdescend\b/i,      category: 'dress', name: 'pull down' },
    { regex: /\bdisplace(?:ing)?\b|\bpush\s*aside\b|\bmove\s*away\b/i, category: 'dress', name: 'displace' },
    { regex: /\bcover(?:ing)?\b|\bshield\b|\bhide\b/i,              category: 'dress', name: 'cover' },
    { regex: /\bundress(?:ing)?\b|\bremove\b|\bstrip(?:ping)?\b|\btake\s*off\b/i, category: 'dress', name: 'undress' },

    // -- social --
    { regex: /\bask(?:ing)?\b|\brequest\b|\binquir(?:e|y)\b/i,      category: 'social', name: 'ask' },
    { regex: /\bdemand(?:ing)?\b|\border(?:ing)?\b|\binsist\b/i,     category: 'social', name: 'demand' },
    { regex: /\bplead(?:ing)?\b|\bbeg(?:ging)?\b|\bimplore\b/i,     category: 'social', name: 'plead' },
    { regex: /\bapologi(?:ze|sing)\b|\bsorry\b|\bregret\b/i,       category: 'social', name: 'apologize' },
    { regex: /\bmock(?:ing)?\b|\btaunt\b|\bsneer\b|\bderid(?:e|ing)\b/i, category: 'social', name: 'mock' },

    // -- vocal --
    { regex: /\bscream(?:ing)?\b|\bshout(?:ing)?\b|\byell(?:ing)?\b/i, category: 'vocal', name: 'scream' },
    { regex: /\bmoan(?:ing)?\b|\bgroan\b|\bwhimper\b/i,             category: 'vocal', name: 'moan' },

    // -- state --
    { regex: /\brest(?:ing)?\b|\brelax(?:ing)?\b/i,                 category: 'state', name: 'rest' },
    { regex: /\bsubmit(?:ting)?\b|\bgiv(?:e|ing)\s*in\b|\byield\b/i, category: 'state', name: 'submit' },
    { regex: /\bstop(?:ping)?\b|\bcease\b|\bhalt\b|\bdesist\b/i,    category: 'state', name: 'stop' },
    { regex: /\bwait(?:ing)?\b|\bpause\b|\bhold\b/i,                category: 'state', name: 'wait' },

    // -- swim --
    { regex: /\bswim(?:ming)?\b|\bfloat\b|\btread\s*water\b/i,     category: 'swim', name: 'swim' },

    // -- restrain (held behind/back) --
    { regex: /\bhold\s*(?:.*\s)?behind\b|\bbehind\s*(?:.*\s)?back\b|\bpin(?:ned)?\b/i, category: 'fending', name: 'restrain' }
  ];

  // ================================================================
  //  身体部位模式库
  //  每条记录: { regex, name }
  //  匹配后返回 bodyPart = name
  // ================================================================
  var _bodyPartPatterns = [
    { regex: /\b(?:face|cheek|forehead|chin)\b/i,       name: 'face' },
    { regex: /\b(?:breast|chest|nipple|tit|bust|boob)\b/i, name: 'chest' },
    { regex: /\b(?:vagina|pussy|clit|vulva|cunt)\b/i,   name: 'vagina' },
    { regex: /\b(?:ass|butt|buttock|rear|bottom)\b/i,   name: 'ass' },
    { regex: /\b(?:anus|anal|hole|rectum)\b/i,          name: 'anus' },
    { regex: /\b(?:penis|cock|dick|shaft|phallus)\b/i,  name: 'penis' },
    { regex: /\b(?:mouth|lips|tongue)\b/i,              name: 'mouth' },
    { regex: /\b(?:balls|testicles|nut|bollock)\b/i,    name: 'balls' },
    { regex: /\b(?:thigh|leg|crotch|lap)\b/i,           name: 'thigh' },
    { regex: /\b(?:hand|palm|wrist|fist)\b/i,           name: 'hand' },
    { regex: /\b(?:foot|feet|ankle|toe)\b/i,            name: 'foot' },
    { regex: /\b(?:arm|shoulder|elbow)\b/i,             name: 'arm' },
    { regex: /\b(?:stomach|belly|abdomen|waist)\b/i,    name: 'belly' },
    { regex: /\b(?:neck|throat|nape)\b/i,               name: 'neck' },
    { regex: /\b(?:hair|head|scalp)\b/i,                name: 'head' },
    { regex: /\b(?:hip|pelvis)\b/i,                     name: 'hip' }
  ];

  // ================================================================
  //  不翻转动作列表
  //  这些动作在 UI 中不应进行左右镜像翻转
  // ================================================================
  var _noFlipActions = [
    'rest', 'stop', 'displace', 'ask', 'cover', 'wait',
    'submit', 'struggle', 'resist', 'escape', 'moan', 'scream',
    'dodge', 'plead', 'apologize', 'mock', 'spit', 'swallow'
  ];

  // ================================================================
  //  解析缓存
  //  key: "actionValue|labelText"
  //  value: { verb, category, bodyPart, clothingSlot, noFlip }
  // ================================================================
  var _cache = new Map();

  // ================================================================
  //  衣物槽位检测
  //  根据 actionValue 或 labelText 推断涉及的衣物槽位
  // ================================================================
  function _getClothingSlot(actionValue, labelText) {
    // 已知动作值 -> 槽位映射 (DoL 原生命名)
    var actionMap = {
      'mupper': 'upper',
      'moverupper': 'over_upper',
      'munder_upper': 'under_upper',
      'mlower': 'lower',
      'moverlower': 'over_lower',
      'munder': 'under_lower',
      'mface': 'face',
      'mhands': 'hands',
      'mlegs': 'legs',
      'mfeet': 'feet',
      'mneck': 'neck',
      'mwaist': 'waist'
    };
    if (actionMap[actionValue]) return actionMap[actionValue];

    // 如果 setup.clothes 中直接存在此键名
    if (window.setup && window.setup.clothes && window.setup.clothes[actionValue]) return actionValue;

    // 基于文本推断
    var searchString = (actionValue + ' ' + labelText).toLowerCase();

    if (/(?:upper|shirt|top|blouse?|sundress|jacket|coat|hoodie)/i.test(searchString)) return 'upper';
    if (/(?:lower|bottoms?|skirt|pants?|trousers?|shorts)/i.test(searchString)) return 'lower';
    if (/(?:under.*lower|panties|underwear|knickers|briefs)/i.test(searchString)) return 'under_lower';
    if (/(?:under.*upper|bra|bralette|camisole)/i.test(searchString)) return 'under_upper';
    if (/(?:over.*upper|sweater|jumper|cardigan)/i.test(searchString)) return 'over_upper';
    if (/(?:over.*lower|overskirt|apron)/i.test(searchString)) return 'over_lower';
    if (/(?:face|mask|glasses|eyewear|veil)/i.test(searchString)) return 'face';
    if (/(?:hand|glove|mitten|ring|bracelet)/i.test(searchString)) return 'hands';
    if (/(?:leg|stocking|legging|sock|tights)/i.test(searchString)) return 'legs';
    if (/(?:foot|feet|shoe|boot|sandal|flip.?flop)/i.test(searchString)) return 'feet';
    if (/(?:neck|choker|collar|scarf|tie)/i.test(searchString)) return 'neck';
    if (/(?:waist|belt|sash|corset|girdle)/i.test(searchString)) return 'waist';
    if (/(?:head|hat|cap|crown|hairband|ribbon|hood)/i.test(searchString)) return 'head';

    return null;
  }

  // ================================================================
  //  核心解析
  // ================================================================
  function _parse(actionValue, labelText) {
    var cacheKey = actionValue + '|' + labelText;
    if (_cache.has(cacheKey)) return _cache.get(cacheKey);

    var searchString = (actionValue + ' ' + labelText).toLowerCase();
    var matchedVerb = null;
    var matchedCategory = null;

    // 1. 匹配动词
    for (var vi = 0; vi < _verbPatterns.length; vi++) {
      var vp = _verbPatterns[vi];
      if (vp.regex.test(searchString)) {
        matchedVerb = vp.name;
        matchedCategory = vp.category;
        break;
      }
    }

    // 2. 检测衣物槽位
    var clothingSlot = _getClothingSlot(actionValue, labelText);

    // 3. 匹配身体部位 (仅在未匹配到衣物槽位时)
    var bodyPart = null;
    if (!clothingSlot) {
      for (var bi = 0; bi < _bodyPartPatterns.length; bi++) {
        var bp = _bodyPartPatterns[bi];
        if (bp.regex.test(searchString)) {
          bodyPart = bp.name;
          break;
        }
      }
    }

    // 4. 检查是否禁止翻转
    var noFlip = false;
    for (var ni = 0; ni < _noFlipActions.length; ni++) {
      if (searchString.indexOf(_noFlipActions[ni]) !== -1) {
        noFlip = true;
        break;
      }
    }

    var result = {
      verb: matchedVerb,
      category: matchedCategory,
      bodyPart: bodyPart,
      clothingSlot: clothingSlot,
      noFlip: noFlip
    };

    _cache.set(cacheKey, result);
    return result;
  }

  // ================================================================
  //  注册 API
  // ================================================================
  SM.ui = SM.ui || {};
  SM.ui._actionParserV1 = true;

  SM.ui.actionParser = {
    parse: _parse,

    clearCache: function () {
      _cache.clear();
    }
  };

  // 模块化注册
  if (typeof SM.modules !== 'undefined' && SM.modules.register) {
    SM.modules.register('action-parser', function () {
      return SM.ui.actionParser;
    }, { deps: ['susato-core'] });
  }

  // ================================================================
  //  passage 切换时清空缓存
  // ================================================================
  if (typeof $ !== 'undefined' && $.fn && $.fn.on) {
    $(document).on(':passageend', function () {
      _cache.clear();
    });
  }
})();
