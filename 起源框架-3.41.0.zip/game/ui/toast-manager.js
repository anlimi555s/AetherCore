// ==================================================================
//  toast-manager v1.0 -- 浮动通知系统
//  吸收 Dynamicest (CSS变量驱动+pointer-events层级) +
//  Dol-Optimization (toast弹性动画+颜色编码) +
//  neoui-patch (cubic-bezier弹性缓动)。
//
//  API:
//    SM.toast.show(text, opts)   -- 弹出通知
//      opts: { color, duration, mode }
//      color: 'gold'|'red'|'green'|'blue'|'info' (默认 'info')
//      duration: 显示毫秒 (默认 3000)
//      mode: 'fixed' (固定在顶部右侧) | 'inline' (跟随passage流)
//    SM.toast.success(text)       -- 绿色成功
//    SM.toast.warn(text)          -- 金色警告
//    SM.toast.error(text)         -- 红色错误
//    SM.toast.info(text)          -- 蓝色信息
//
//  依赖: 纯 CSS + DOM，无框架依赖
//  消费方: CombatManager / 经济系统 / 任何需要通知的模块
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.toast) return;

  var _container = null;
  var _timer = null;

  var COLORS = {
    gold:   { bg: 'rgba(50,42,10,0.95)', border: '#ed3', text: '#ed3', icon: '⚡' },
    red:    { bg: 'rgba(50,10,10,0.95)', border: '#e44', text: '#e44', icon: '✖' },
    green:  { bg: 'rgba(10,40,15,0.95)', border: '#7d8', text: '#7d8', icon: '✔' },
    blue:   { bg: 'rgba(10,20,50,0.95)', border: '#8cf', text: '#8cf', icon: 'ℹ' },
    info:   { bg: 'rgba(20,20,30,0.95)', border: '#888', text: '#ccc', icon: '' }
  };

  function _ensureContainer() {
    if (_container) return _container;
    _container = document.createElement('div');
    _container.id = 'susato-toast-container';
    _container.innerHTML = '<style>' +
      // 容器: 固定在右上角，点击穿透
      '#susato-toast-container {' +
        'position:fixed; top:var(--susato-toast-top,60px); right:10px;' +
        'width:90vw; max-width:380px; z-index:10000;' +
        'pointer-events:none; display:flex; flex-direction:column; gap:8px;' +
      '}' +
      // 单个 toast: pointer-events: auto 让它可交互(悬停暂停倒计时)
      '.susato-toast {' +
        'pointer-events:auto; padding:10px 14px; border-radius:10px;' +
        'border:1px solid; font-size:0.85rem; line-height:1.4;' +
        'backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px);' +
        'cursor:default; position:relative; overflow:hidden;' +
        // 入场: 从右侧弹入，弹性过冲
        'animation:susato-toast-in 0.5s cubic-bezier(0.34,1.56,0.64,1);' +
        // 出场
        'transition: opacity 0.4s ease, transform 0.4s ease;' +
      '}' +
      '.susato-toast.removing {' +
        'opacity:0; transform:translateX(40px) scale(0.95);' +
        'pointer-events:none;' +
      '}' +
      // 悬停: 微放大 + 暂停进度条
      '.susato-toast:hover {' +
        'transform:scale(1.02);' +
      '}' +
      '.susato-toast:hover .susato-toast-bar {' +
        'animation-play-state:paused;' +
      '}' +
      // 进度条: 底部细线，从左到右收缩
      '.susato-toast-bar {' +
        'position:absolute; bottom:0; left:0; height:2px;' +
        'border-radius:0 0 0 10px;' +
        'animation:susato-toast-timer linear forwards;' +
      '}' +
      '.susato-toast-icon {' +
        'display:inline-block; width:1.2em; margin-right:6px; text-align:center;' +
      '}' +
      // 弹性入场关键帧
      '@keyframes susato-toast-in {' +
        'from { opacity:0; transform:translateX(60px) scale(0.9); }' +
        'to   { opacity:1; transform:translateX(0) scale(1); }' +
      '}' +
      '@keyframes susato-toast-timer {' +
        'from { width:100%; }' +
        'to   { width:0%; }' +
      '}' +
      // 响应式: 小屏幕占满宽
      '@media(max-width:420px){' +
        '#susato-toast-container { right:4px; max-width:calc(100vw - 8px); }' +
        '.susato-toast { font-size:0.78rem; padding:8px 10px; }' +
      '}' +
    '</style>';
    document.body.appendChild(_container);
    return _container;
  }

  SM.toast = {
    show: function (text, opts) {
      if (!text) return;
      opts = opts || {};
      var color = COLORS[opts.color] || COLORS.info;
      var duration = opts.duration || 3000;
      var container = _ensureContainer();

      // 创建 toast
      var el = document.createElement('div');
      el.className = 'susato-toast';
      el.style.background = color.bg;
      el.style.borderColor = color.border;
      el.style.color = color.text;

      // 内容: 图标 + 文字
      var iconHtml = color.icon ? '<span class="susato-toast-icon">' + color.icon + '</span>' : '';
      el.innerHTML = iconHtml + text;

      // 进度条
      var bar = document.createElement('div');
      bar.className = 'susato-toast-bar';
      bar.style.background = color.border;
      bar.style.animationDuration = duration + 'ms';
      el.appendChild(bar);

      // 点击关闭
      el.addEventListener('click', function () {
        _remove(el);
      });

      container.appendChild(el);

      // 自动移除
      var timer = setTimeout(function () {
        _remove(el);
      }, duration);
      el._timer = timer;

      // 限制同时显示数量(最多5个)
      var all = container.querySelectorAll('.susato-toast:not(.removing)');
      while (all.length > 5) {
        _remove(all[0]);
        all = container.querySelectorAll('.susato-toast:not(.removing)');
      }
    },

    success: function (text, duration) { SM.toast.show(text, { color: 'green', duration: duration }); },
    warn:    function (text, duration) { SM.toast.show(text, { color: 'gold', duration: duration }); },
    error:   function (text, duration) { SM.toast.show(text, { color: 'red', duration: duration }); },
    info:    function (text, duration) { SM.toast.show(text, { color: 'blue', duration: duration }); },

    // 配置 CSS 变量(允许用户/主题调整)
    configure: function (opts) {
      var container = _ensureContainer();
      if (opts.top !== undefined) {
        container.style.setProperty('--susato-toast-top', opts.top + 'px');
      }
    }
  };

  function _remove(el) {
    if (!el || el._removing) return;
    el._removing = true;
    if (el._timer) clearTimeout(el._timer);
    el.classList.add('removing');
    setTimeout(function () {
      if (el.parentNode) el.parentNode.removeChild(el);
    }, 400); // 等 transition 完成
  }
})();
