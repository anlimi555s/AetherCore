// ==================================================================
//  righthand v4.2.0 — 双手渲染高于衣物（独立 mod，自起源框架-寿里美化包 2.14.0 移出）
//  原 v4.1.0 只处理右手。v4.2.0 扩展为双手：左手层命名已对照本体 0.5.10.12
//  （leftarm / _leftarm_acc / _leftarm_fitted / _leftarm_fitted_acc /
//    hands_left* / writing_left_shoulder），与右手同基准抬升。
//
//  背景（照搬原 v4.1.0 注释）：右臂那组衣物的 z 散绑在 armsidle /
//  under_upper_arms / over_upper_arms / 共享 zarms / zupperright 五六个来源；
//  袖层多由工厂函数生成，源码正则枚举不到。「手高于衣服」逼出下面这套
//  运行时遍历+重映射。
//
//  目标：让垂在身侧的手（连同其上所有衣物：裸臂/内衣袖/上装袖/外套袖/
//  手套/纹身/cum）整组渲染在衣服之上，且彼此保持内部前后顺序。
//
//  把手臂组的 idle z 重映射到 [base, base+~0.1] 窄带（base 取 lower_top_high 之上），
//  除以 1000 是单调变换 → 保留内部顺序，又把整组压到全部衣服之上、手持物与头发之下。
//  cover/hold 姿态本体已在上方，原样不动（左右手各自独立判断）。
//
//  注意 时机：必须 :storyready（任何立绘渲染前、且工厂图层已全部进模板）才 patch。
//   susato-core 的 flush 也绑在 :storyready，且 core 排在本文件之前、
//   其 :storyready 处理器先绑定先触发 → flush 先跑完（把 SR.patchLayers 换成即时执行版），
//   本文件的 setup 随后在同一 :storyready 里调用，即时遍历模板覆盖全部手臂层。
//
//  API:
//    无。加载时自动 onCompile，运行时遍历 spec 覆盖全部手臂层。
//
//  依赖: susato-core.js (SusatoModel.renderer.onCompile)
//  去重守卫: SM._armLiftV1 —— 与旧版美化包(≤2.13.8)同装时防双注册。
//            注意: 旧包内的 v4.1.0 无此守卫，若旧包先加载仍会双变换
//            (z≈118.118 压缩)，用 2.14.0+ 美化包即无此问题。
//  模块开关 id 沿用 'righthand'（与旧版存档的开关设置兼容）。
// ==================================================================
(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('righthand')) return; // 模块开关(起源管理器), 刷新后生效

  var SM = window.SusatoModel;
  if (!SM) return;
  if (SM._armLiftV1) return;
  SM._armLiftV1 = true;

  var SR = SM.renderer;
  if (!SR) return; // susato-core 未加载

  var _ready = false;

  function setup() {
    if (_ready) return;
    if (typeof ZIndices === 'undefined' || typeof ZIndices.arms_cover !== 'number') return;
    _ready = true;

    // 基准要高于全部躯干/下装图层，手才能盖住所有衣服。
    // arms_cover(105) 只高过普通上下装(upper 95 / over_lower 103.3)，但盖不住
    // 高腰或紧身连体下装用的 lower_high(115) / lower_top_high(117)——这正是
    // 「只压得住袜子、压不住衣服」的原因。把基准抬到 lower_top_high 之上(118)，
    // 仍低于 handheld(131) 与头发/头部(hair_forward 132 起)，保证手在所有衣服之上、
    // 手持物与头发之下。
    var ceil = (typeof ZIndices.lower_top_high === 'number') ? ZIndices.lower_top_high : 117;
    var base = ceil + 1; // 118

    // 手臂层匹配（双手）：本体层名对照 0.5.10.12
    // 右: rightarm / _rightarm(_acc|_fitted|_fitted_acc) / hands_right* /
    //     _fitted_right(_acc) / writing_right_shoulder
    // 左: 同构镜像（leftarm / _leftarm* / hands_left* / writing_left_shoulder）
    function isArm(name) {
      if (name === 'rightarm' || name === 'leftarm') return true;
      return /^hands_(right|left)/.test(name)
        || /_(right|left)arm(_acc|_fitted|_fitted_acc)?$/.test(name)
        || /_fitted_(right|left)(_acc)?$/.test(name)
        || name === 'writing_right_shoulder' || name === 'writing_left_shoulder';
    }

    // 层属于哪只手
    function armSide(name) {
      if (name.indexOf('right') >= 0) return 'right';
      if (name.indexOf('left') >= 0) return 'left';
      return null;
    }

    // onCompile：prototype 级 compile 包装器，对所有实例生效；
    // compile 后 spec.z 已由原 zfn 求值，这里直接读数字改数字。
    SR.onCompile(function (specs, options, model) {
      // 只处理主立绘，跳过战斗/NPC/光照等模型
      if (model.name && model.name !== 'main') return;
      for (var i = 0; i < specs.length; i++) {
        var s = specs[i];
        if (!s || typeof s.name !== 'string' || typeof s.z !== 'number') continue;
        if (!isArm(s.name)) continue;
        // cover/hold：本体已把该组抬到衣物上，原样不动（左右手独立判断）
        var side = armSide(s.name);
        if (!side) continue;
        if (options && (options['arm_' + side] === 'cover' || options['arm_' + side] === 'hold')) continue;
        // idle：单调压到窄带内，保留内部顺序
        s.z = base + s.z / 1000;
      }
    });
  }

  // 模块加载时立即注册（ZIndices 由游戏脚本先行定义），首次立绘渲染即生效。
  // ZIndices 意外未就绪时 storyready 兜底重试。
  setup();
  if (!_ready && typeof $ !== 'undefined') {
    $(document).one(':storyready', setup);
  }
})();
