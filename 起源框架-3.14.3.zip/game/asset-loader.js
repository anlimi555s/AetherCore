// asset-loader.js -- 自定义 mod 图片加载器 v1.0
// 问题: <<icon>> 宏只解析本体路径, 自定义 mod 图片 (img/misc/icon/xxx/) 不生效。
// 猫咖方案: JS 侧用 modSC2DataManager.getHtmlTagSrcHook().requestImageBySrc() 取 base64。
// 本模块把此能力封装为框架 API, 供所有子 mod 在 twee 中可靠显示自定义图片。
//
// API:
//   SusatoModel.assets.add(path1, path2, ...)    注册图片路径 (对应 imgFileList 条目)
//   SusatoModel.assets.get(path) -> base64 data URI 或空串
//   SusatoModel.assets.render(path, width, height) -> <img> HTML 字符串
//   SusatoModel.assets.loaded() -> bool           是否全部就绪
//
// 用法 (子 mod boot.json):
//   scriptFileList 加 asset-loader.js, dependenceInfo 确保 moduleOff 守卫可用。
//   在 clothing-data 或 katherineHouse 等 init 中调用 SM.assets.add("img/.../xxx.png")。
//   twee 中用: <<print SusatoModel.assets.render("img/.../xxx.png", 30, 30)>>

(function () {
  'use strict';

  var SM = window.SusatoModel = window.SusatoModel || {};
  if (SM.assets) return;

  var _store = {};    // path -> dataUri (filled as loaded)
  var _pending = [];  // paths registered but not yet loaded
  var _resolving = false;

  function _resolveOne(path) {
    try {
      var hook = window.modSC2DataManager &&
                 window.modSC2DataManager.getHtmlTagSrcHook &&
                 window.modSC2DataManager.getHtmlTagSrcHook();
      if (!hook || typeof hook.requestImageBySrc !== 'function') return Promise.resolve('');
      return hook.requestImageBySrc(path).then(function (b64) {
        return b64 ? ('data:image/png;base64,' + b64) : '';
      }, function () { return ''; });
    } catch (e) { return Promise.resolve(''); }
  }

  function _resolveAll() {
    if (_resolving || !_pending.length) return;
    _resolving = true;
    var batch = _pending.slice();
    _pending = [];
    Promise.all(batch.map(function (path) {
      return _resolveOne(path).then(function (uri) {
        _store[path] = uri || '';
      });
    })).then(function () {
      _resolving = false;
      // 如果有晚注册的, 继续处理
      if (_pending.length) _resolveAll();
    });
  }

  SM.assets = {
    add: function () {
      for (var i = 0; i < arguments.length; i++) {
        var p = arguments[i];
        if (typeof p !== 'string' || !p || p in _store) continue;
        _store[p] = '';  // placeholder, to be filled
        _pending.push(p);
      }
      _resolveAll();
    },

    get: function (path) {
      return _store[path] || '';
    },

    render: function (path, width, height) {
      var src = _store[path] || '';
      if (!src) return '<!-- asset not ready: ' + (path || '') + ' -->';
      var w = width ? ' width="' + width + '"' : '';
      var h = height ? ' height="' + height + '"' : '';
      return '<img src="' + src + '"' + w + h + '>';
    },

    loaded: function () {
      if (_pending.length) return false;
      for (var k in _store) {
        if (Object.prototype.hasOwnProperty.call(_store, k) && !_store[k]) return false;
      }
      return true;
    },

    _store: _store,
    _forceRefresh: _resolveAll,
  };
})();
