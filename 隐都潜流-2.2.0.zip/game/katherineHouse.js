// Katherine House Mod — 剧情载体
// 接入 起源框架(原 susato-model ZH) 框架（共享 init 管道 / 技能注册 / 名望框架）
// 警局世俗路线 v1.0

(function () {
  'use strict';

  // ==================== 变量初始化 ====================
  // 全部默认值集中声明: state-addon 在场时走 SusatoModel.vars 托管(新档初始化+旧档自动补缺),
  // 缺席时回退本地幂等补齐。新增变量只需在此加一行。
  var KH_DEFAULTS = {

    // KatherineHouse
    boughtHouse: 0,
    metKatherine: 0,
    khMsg: '',
    khSleepDressed: false,
    hasGardenKey: false,
    baileyExtortMissed: 0,
    khRestore: 0,
    khSoftRestore: 0,
    khMystery: 0,
    khTech: 0,
    khLastVisitDay: 0,
    khDirt: { kitchen: 0, living: 0, bedroom: 0, bathroom: 0, study: 0, balcony: 0 },
    khDirtMax: 8,

    // 银行
    bankAccount: 0,
    bankSavings: 0,
    bankLoanPrincipal: 0,
    bankLoanAmount: 0,
    bankLoanNextPayment: 0,
    bankLoanMissed: 0,
    bankLoanDueDay: 0,
    bankCreditBlacklist: 0,

    // 警局框架
    policeReputation: 0,

    // 迪冷保护卡
    dilenProtection: 0,
    dilenProtectionPaid: 0,
    dilenProtectionDay: -1,
    dilenProtectionAutoRenew: 1,

    // 武器柜
    weaponCabinetDiscovered: 0,
    weaponCarried: "",
    weaponInventory: [],
    weaponSlots: 5,

    // 自定义技能（旧档补缺，skill-addon 注册前兜底）
    weaponCombat: 0,
    weaponCombatday: 0,
    hacking: 0,
    hackingday: 0,

    // 拳击馆
    boxingGym: { intro: 0, stage: 0, lesson: '', anger: 0, assistIntro: 0 },

    // 黑市
    blackMarketDiscovered: 0,
  };

  function initVariables() {
    var SMv = window.SusatoModel;
    if (SMv && SMv.vars) { SMv.vars.defineAll(KH_DEFAULTS); }
    // 兜底：直接补 khDirt，防 state-addon 时序问题
    if (typeof State !== 'undefined' && State.variables) {
      var V = State.variables;
      for (var k in KH_DEFAULTS) {
        if (Object.prototype.hasOwnProperty.call(KH_DEFAULTS, k) && V[k] === undefined) {
          try { V[k] = JSON.parse(JSON.stringify(KH_DEFAULTS[k])); } catch (e) { V[k] = KH_DEFAULTS[k]; }
        }
      }
    }
  }

  // ==================== 拳击馆教练 NPC ====================
  var _vitoTemplate = {
    nam: '维托', title: '拳击教练', type: 'human',
    pronoun: 'm', teen: 0, adult: 1, init: 1, intro: 1,
    love: 0, dom: 0, lust: 0, rage: 0, trust: 0, trauma: 0, state: '',
    eyeColour: 0, hairColour: 0, skincolour: 0, desc: 0, breastsdesc: 0,
    breastsize: 0, breastfeed: 0,
    penis: 'none', vagina: 'none',
    chastity: { penis: '', vagina: '', anus: '' },
    virginity: { oral: true, vaginal: true, penile: true, anal: true, kiss: true, handholding: true },
    pregnancy: {}, pregnancyAvoidance: 0,
    location: {}, skills: {}, pronouns: {}, traits: []
  };

  function registerVito() {
    try {
      if (typeof V === 'undefined') return;
      var list = V.NPCNameList;
      if (!Array.isArray(list)) return;
      // 清理旧英文名残留（nam 已改为中文"维托"）
      var oldIdx = list.indexOf('Vito');
      if (oldIdx !== -1) {
        list.splice(oldIdx, 1);
        if (Array.isArray(V.NPCName) && V.NPCName[oldIdx] && V.NPCName[oldIdx].nam === 'Vito') {
          V.NPCName.splice(oldIdx, 1);
        }
      }
      var idx = list.indexOf('维托');
      if (idx === -1) {
        list.push('维托');
        if (Array.isArray(V.NPCName)) V.NPCName.push(Object.assign({}, _vitoTemplate));
      } else if (Array.isArray(V.NPCName) && (!V.NPCName[idx] || !V.NPCName[idx].nam)) {
        V.NPCName[idx] = Object.assign({}, _vitoTemplate);
      }
      if (typeof setup !== 'undefined' && setup.loveAlias) {
        if (setup.loveAlias['Vito']) delete setup.loveAlias['Vito'];
        if (!setup.loveAlias['维托']) setup.loveAlias['维托'] = function () { return '尊敬'; };
      }
      // 补 C.npc 条目: npcPregnancyUpdater 等系统宏遍历 NPCNameList 时访问 C.npc[name]
      if (typeof C !== 'undefined' && C.npc && !C.npc['维托']) {
        C.npc['维托'] = { type: 'human', pregnancy: {} };
      }
    } catch (e) {}
  }

  // ==================== 拳击馆图片 ====================
  function registerBoxingAssets() {
    try {
      var SA = window.SusatoModel && window.SusatoModel.assets;
      if (SA) { SA.add('img/boxing/icon.png'); SA.add('img/blackmarket/icon.png'); }
    } catch (e) {}
  }

  // ==================== 古董商数据 ====================
  // 博物馆估值 x2 = 卖给古董商的价钱
  window.BM_ANTIQUES = {
    unique: [
      { id: "antiqueivorynecklace",   name: "无瑕象牙项链", worth: 200000,  carry: 2000,  icon: "clothes/ivory-necklace.png" },
      { id: "antiqueivorystatuette",  name: "象牙小雕像",   worth: 50000,   carry: 500,   icon: "antiques/antique-ivory-statuette.png" },
      { id: "antiquesilvercrown",     name: "银冠",         worth: 120000,  carry: 1200,  icon: "antiques/antique-silver-crown.png" },
      { id: "antiquewhitecrystal",    name: "白水晶",       worth: 200000,  carry: 2000,  icon: "antiques/antique-crystal.png" },
      { id: "antiquediamond",         name: "钻石",         worth: 200000,  carry: 2000,  icon: "antiques/antique-diamond.png" },
      { id: "antiquecoralring",       name: "珊瑚戒指",     worth: 80000,   carry: 800,   icon: "antiques/antique-coral-ring.png" },
      { id: "antiquegoldcompass",     name: "金指南针",     worth: 500000,  carry: 5000,  icon: "antiques/antique-gold-compass.png" },
      { id: "antiquestonetalisman",   name: "石质护符",     worth: 120000,  carry: 1200,  icon: "clothes/holy-pendant.png" },
      { id: "antiquehourglass",       name: "铭文沙漏",     worth: 140000,  carry: 1400,  icon: "antiques/antique-hourglass.png" },
      { id: "antiqueleathermap",      name: "皮革地图",     worth: 400000,  carry: 4000,  icon: "antiques/antique-map.png" },
      { id: "antiquegolddagger",      name: "金匕首",       worth: 400000,  carry: 4000,  icon: "antiques/antique-gold-dagger.png" },
      { id: "antiquegoldamulet",      name: "金护符",       worth: 400000,  carry: 4000,  icon: "antiques/antique-gold-amulet.png" },
      { id: "antiquegoldmask",        name: "金面具",       worth: 1200000, carry: 12000, icon: "antiques/antique-gold-mask.png" },
      { id: "antiquebell",            name: "洪钟",         worth: 1000000, carry: 10000, icon: "antiques/antique-bell.png" },
      { id: "antiquesilvermask",      name: "银面具",       worth: 300000,  carry: 3000,  icon: "antiques/antique-silver-mask.png" },
      { id: "antiqueobsidiandisc",    name: "黑曜石圆盘",   worth: 50000,   carry: 500,   icon: "antiques/antique-disc.png" }
    ],
    repeatable: [
      { id: "antiquebox",               name: "浸水象牙盒",     worth: 2000,   carry: 20,    icon: "antiques/antique-ivory-box.png" },
      { id: "antiquesilverring",        name: "磨损银戒指",     worth: 3000,   carry: 30,    icon: "antiques/antique-silver-ring.png" },
      { id: "antiquegoldnecklace",      name: "华丽金项链",     worth: 50000,  carry: 500,   icon: "antiques/antique-gold-necklace.png" },
      { id: "antiquegoldchastitybelt",  name: "黄金贞操带",     worth: 200000, carry: 2000,  icon: "antiques/antique-chastity.png" },
      { id: "antiqueforestarrow",       name: "生苔森林箭",     worth: 2000,   carry: 20,    icon: "antiques/antique-arrow.png" },
      { id: "antiqueforestdagger",      name: "锈蚀森林匕首",   worth: 4000,   carry: 40,    icon: "antiques/antique-dagger.png" },
      { id: "antiqueforestgem",         name: "脉动森林宝石",   worth: 10000,  carry: 100,   icon: "antiques/antique-forest-gem.png" },
      { id: "antiquetrashcup",          name: "废弃杯子",       worth: 5000,   carry: 50,    icon: "antiques/antique-cup.png" },
      { id: "antiquetrashburner",       name: "香炉",           worth: 10000,  carry: 100,   icon: "antiques/antique-incense.png" },
      { id: "antiqueminesign",          name: "贝利标牌",       worth: 14000,  carry: 140,   icon: "antiques/antique-bailey.png" },
      { id: "antiquegoldbrooch",        name: "金胸针",         worth: 50000,  carry: 500,   icon: "antiques/antique-gold-brooch.png" },
      { id: "antiquegrenade",           name: "旧手榴弹",       worth: 8000,   carry: 80,    icon: "antiques/antique-grenade.png" },
      { id: "antiquebullet",            name: "子弹",           worth: 5000,   carry: 50,    icon: "antiques/antique-bullet.png" },
      { id: "antiqueshell",             name: "炮弹壳",         worth: 10000,  carry: 100,   icon: "antiques/antique-artillery.png" },
      { id: "antiquegoldring",          name: "金戒指",         worth: 300000, carry: 3000,  icon: "antiques/antique-gold-ring.png" },
      { id: "antiquecoppercoin",        name: "铜币",           worth: 1000,   carry: 10,    icon: "antiques/antique-copper-coin.png" },
      { id: "antiquesilvercoin",        name: "银币",           worth: 2000,   carry: 20,    icon: "antiques/antique-silver-coin.png" },
      { id: "antiquegoldcoin",          name: "金币",           worth: 10000,  carry: 100,   icon: "antiques/antique-gold-coin.png" },
      { id: "antiquesilverblade",       name: "银刃",           worth: 5000,   carry: 60,    icon: "antiques/antique-silver-blade.png" },
      { id: "antiquestrangefetish",     name: "诡异人偶",       worth: 1500,   carry: 15,    icon: "antiques/antique-fetish.png" },
      { id: "antiquesilvergoblet",      name: "银高脚杯",       worth: 5000,   carry: 60,    icon: "antiques/antique-silver-goblet.png" },
      { id: "antiqueswordcane",         name: "剑杖",           worth: 5000,   carry: 50,    icon: "antiques/antique-cane.png" },
      { id: "antiquechocolate",         name: "巧克力",         worth: 2500,   carry: 25,    icon: "antiques/antique-chocolate.png" },
      { id: "antiqueteacaddy",          name: "茶叶罐",         worth: 2000,   carry: 20,    icon: "antiques/antique-tea.png" },
      { id: "antiquewoodenfigurine",    name: "木雕像",         worth: 1500,   carry: 15,    icon: "antiques/antique-figurine.png" },
      { id: "antiquecopperring",        name: "铜戒指",         worth: 500,    carry: 5,     icon: "antiques/antique-copper-ring.png" },
      { id: "antiquesilveramulet",      name: "银护符",         worth: 30000,  carry: 200,   icon: "antiques/antique-silver-amulet.png" },
      { id: "antiquebucket",            name: "桶",             worth: 20000,  carry: 200,   icon: "antiques/antique-bucket.png" },
      { id: "antiquesilvermanacle",     name: "银镣铐",         worth: 40000,  carry: 400,   icon: "antiques/antique-silver-manacle.gif" },
      { id: "antiquesnuffer",           name: "灭烛器",         worth: 20000,  carry: 200,   icon: "antiques/antique-snuffer.png" },
      { id: "antiquewhip",              name: "鞭子",           worth: 20000,  carry: 200,   icon: "antiques/antique-whip.png" },
      { id: "antiquehorn2",             name: "精雕号角",       worth: 40000,  carry: 400,   icon: "antiques/antique-horn-2.png" },
      { id: "antiquecrystal",           name: "撩人水晶",       worth: 20000,  carry: 200,   icon: "antiques/antique-crystal-pink.png" },
      { id: "antiquecandlestick",       name: "贵族烛台",       worth: 5000,   carry: 50,    icon: "antiques/antique-candlestick.png" },
      { id: "antiquedildo",             name: "诡异医疗器具",   worth: 5000,   carry: 50,    icon: "antiques/antique-dildo.png" },
      { id: "antiquehorn",              name: "狩猎号角",       worth: 10000,  carry: 100,   icon: "antiques/antique-horn.png" },
      { id: "antiquewatch",             name: "旧怀表",         worth: 20000,  carry: 200,   icon: "antiques/antique-watch.gif" },
      { id: "antiquesilvercompass",     name: "银指南针",       worth: 220000, carry: 2200,  icon: "antiques/antique-silver-compass.png" },
      { id: "antiquesilverbrooch",      name: "银胸针",         worth: 5000,   carry: 50,    icon: "antiques/antique-silver-brooch.png" },
      { id: "antiquecoppercompass",     name: "铜指南针",       worth: 5000,   carry: 50,    icon: "antiques/antique-copper-compass.png" },
      { id: "antiquebrassstatuette",    name: "黄铜小雕像",     worth: 12000,  carry: 120,   icon: "antiques/antique-brass-statuette.png" },
      { id: "antiquecutlass",           name: "弯刀",           worth: 12000,  carry: 120,   icon: "antiques/antique-cutlass.png" },
      { id: "antiquesilverdagger",      name: "银匕首",         worth: 24000,  carry: 240,   icon: "antiques/antique-silver-dagger.png" },
      { id: "antiquerustedcutlass",     name: "生锈弯刀",       worth: 1000,   carry: 10,    icon: "antiques/antique-rusted-cutlass.png" },
      { id: "antiqueislandarrow",       name: "岛民之箭",       worth: 2000,   carry: 20,    icon: "antiques/antique-islander-arrow.png" },
      { id: "antiquewoodenmask",        name: "木面具",         worth: 4000,   carry: 40,    icon: "clothes/islander-mask.png" },
      { id: "antiquetrilobitefossil",   name: "三叶虫化石",     worth: 5000,   carry: 50,    icon: "antiques/antique-trilobite.png" }
    ]
  };

  // 古董商: 执行卖出, 从 JS 调用
  window.BM_sellAntique = function(id, price, carry) {
    try {
      var Sv = State.variables;
      if (Sv.museumAntiques && Sv.museumAntiques.antiques && Sv.museumAntiques.antiques[id] === 'found') {
        Sv.museumAntiques.antiques[id] = 'talk';
        Sv.money += price;
        if (typeof carry === 'number' && carry > 0) Sv.antiquemoney = Math.max(0, (Sv.antiquemoney || 0) - carry);
        SugarCube.Engine.play(SugarCube.State.passage);
        return true;
      }
    } catch(e) {}
    return false;
  };

  window.BM_getSellableAntiques = function(type) {
    var result = [];
    var list = window.BM_ANTIQUES[type] || [];
    try {
      var Sv = State.variables;
      for (var i = 0; i < list.length; i++) {
        var a = list[i];
        if (Sv.museumAntiques && Sv.museumAntiques.antiques && Sv.museumAntiques.antiques[a.id] === 'found') {
          var mult = type === 'unique' ? 5 : 2;
          result.push({ id: a.id, name: a.name, price: a.worth * mult, carry: a.carry, icon: a.icon });
        }
      }
    } catch(e) {}
    return result;
  };

  // ==================== 自定义技能 ====================
  function registerSkills() {
    var SS = window.SusatoModel && window.SusatoModel.skill;
    if (!SS) return;

    SS.add({
      id: 'hacking',
      name: '黑客技术',
      max: 1000,
      detailed: true,
      daily: true,
      hidden: true,
      description: '渗透与数据抽取的辅助系统知识。',
    });

    // 拳击 —— 对标防狼喷雾等级表(F/D/C/B/A/S), 顶级对标施虐狂 S 级量级
    SS.add({
      id: 'weaponCombat',
      name: '拳击',
      max: 1000,
      detailed: false,
      daily: true,
      description: '运用拳脚与随身武器进行攻防的能力。等级越高, 造成的伤害与控制效果越强。',
    });
  }

  // ==================== 武器数据与战斗辅助 ====================
  // 武器定义: 每件武器的检定属性、技能系数
  // price 为便士（£1 = 100）。price=0 表示不可购买（剧情获取）。
  var WEAPON_DATA = {
    crimson_gloves:   { name: '深红拳套', stat: 'physique', desc: '用拳套发起近身攻击, 检定体能。', price: 0 },
    brass_knuckles:   { name: '纯金指虎', stat: 'physique', desc: '黄金永不生锈。近身打击, 检定体能。', price: 50000 },
    whip:             { name: '皮鞭',     stat: 'physique', desc: '抽打敌人造成疼痛与晕厥, 非致命。', price: 150000 },
    baton:            { name: '短棍',     stat: 'physique', desc: '近战短棍, 有一定概率击晕敌人。', price: 100000 },
    stun_gun:         { name: '电击器',   stat: 'physique', desc: '释放高压电流, 可瞬间麻痹对手。', price: 300000 },
    throwing_blades:  { name: '飞刀',     stat: 'physique', desc: '远程投掷, 命中率随技能提升。', price: 80000 },
  };

  // 黑市武器贩子可售卖清单（从 WEAPON_DATA 中筛出 price > 0 的）
  window.BM_WEAPONS_FOR_SALE = Object.keys(WEAPON_DATA)
    .filter(function(id) { return WEAPON_DATA[id].price > 0; })
    .map(function(id) { var w = WEAPON_DATA[id]; return { id: id, name: w.name, price: w.price, desc: w.desc }; });

  // 获取武器技能有效等级: 走 currentSkillValue 管道以享受技能框架的 modifier 修正
  function weaponSkillLevel() {
    try {
      if (typeof window.currentSkillValue === 'function') return window.currentSkillValue('weaponCombat');
      return (typeof V !== 'undefined' && typeof V.weaponCombat === 'number') ? V.weaponCombat : 0;
    } catch (e) { return 0; }
  }

  // 武器战斗检定: 返回 (难度值, 最大失败值) 供 <<physiquedifficulty>> 等宏使用。
  // difficulty 为基础难度, 技能等级可降低难度。
  window.KHWeapon = {
    // 当前携带的武器数据, 无携带时返回 null
    carried: function () {
      try {
        var id = (typeof V !== 'undefined') ? V.weaponCarried : '';
        return (id && WEAPON_DATA[id]) ? { id: id, data: WEAPON_DATA[id] } : null;
      } catch (e) { return null; }
    },

    // 检定难度: 基础值 - 技能减免。返回实际 difficulty 值供检宏使用。
    difficulty: function (base) {
      var lv = weaponSkillLevel();
      // 每 100 技能等级减 1 档难度, 最低到硬底
      var reduction = Math.floor(lv / 100);
      return Math.max(1, Math.round((base || 10) - reduction));
    },

    // 当前武器是否可用 (有携带 + 有数据)
    available: function () {
      return !!window.KHWeapon.carried();
    },
  };


  // ==================== NPC 关系注册（走主 mod npc-addon 框架） ====================
  // Social 页的关系条渲染由框架统一注入, 本 mod 只声明数据。
  function registerNpc() {
    var SN = window.SusatoModel && window.SusatoModel.npc;
    if (!SN) return;
    SN.register({
      id: 'policeTrust',
      name: '警局信任',
      variable: 'policeReputation',
      icon: 'img/misc/icon/police.png',
      states: [
        { requiredValue: 0,   color: 'red',    description: '警局前台对你视而不见。' },
        { requiredValue: 10,  color: 'pink',   description: '前台开始礼貌地回应你。' },
        { requiredValue: 30,  color: 'purple', description: '前台偶尔向你透露小道消息。' },
        { requiredValue: 50,  color: 'blue',   description: '你获准上楼见局长。' },
        { requiredValue: 75,  color: 'teal',   description: '局长愿意与你分享机密。' },
        { requiredValue: 100, color: 'green',  description: '警局把你当作自己人。' },
      ],
    });
  }

  // ==================== 名望注册（走主 mod 框架） ====================
  function registerFame() {
    var SF = window.SusatoModel && window.SusatoModel.fame;
    if (!SF) return;

    // 注册「秩序」名望类型: 框架自动处理
    //   $fame.order 变量初始化
    //   allure 阶梯折扣
    //   Social 页面渲染(<<customFame>> 宏, 框架 boot.json 注入)
    // 场景中使用 <<fameorder amount>> 增减声望值
    SF.register({
      type: 'order',
      name: '秩序',
      discount: [
        { threshold: 200,  pct: 5 },
        { threshold: 400,  pct: 10 },
        { threshold: 600,  pct: 15 },
        { threshold: 800,  pct: 20 },
        { threshold: 1000, pct: 25 },
      ],
    });
  }

  // ==================== 经济条目（走主 mod economy-addon 框架） ====================
  function registerEconomy() {
    var SE = window.SusatoModel && window.SusatoModel.economy;
    if (!SE) return;

    // #29 贝利盘剥：暂缓（2026-07-15：不从银行/账本走，以后做）
    // 设计存档见 date/.date/DoL economy-addon 经济框架.md，恢复时重新注册 expense 条目即可

    // 银行储蓄利息（income kind，每周 0.1%）
    // selfPay：利息直接滚进储蓄余额（onSettle），框架只记统计不发口袋
    SE.add({
      id: 'bankSavingsInterest',
      name: '储蓄利息',
      kind: 'income',
      period: 7,
      silent: true,
      selfPay: true,
      amount: function () {
        var V = State.variables;
        return Math.floor((V.bankSavings || 0) * 0.001);
      },
      active: function () {
        var V = State.variables;
        // 账户冻结期（劫案被抓）不结息
        if (Time.days < (V.bankFrozenUntil || 0)) return false;
        return V.bankAccount === 1 && (V.bankSavings || 0) >= 10000;
      },
      onSettle: function (amt) {
        var V = State.variables;
        V.bankSavings = (V.bankSavings || 0) + amt;
      },
    });

    // 银行贷款（debt kind，本金由 twee 段落设好后激活，28 天到期整笔还 1.9 倍）
    // 规则：账户的钱是账户的，身上的是身上的——
    //   到期只从储蓄账户划扣；不够就把储蓄全部抵债，进入违约冻结（不复利不再结算），
    //   等玩家回银行由职员当面讨债（bank.twee 的 Bank 段落拦截）：
    //   愿意还且钱够=结清；愿意还但不够=身上账户全部清零然后卖掉；拒绝=直接卖掉。
    // 注意：twee 侧借款/还清时必须调用 SusatoModel.economy.reset('bankLoan')，
    // 否则条目沿用陈旧 lastDay/principal（第二笔贷款要么白拿要么补结复利）
    SE.add({
      id: 'bankLoan',
      name: '银行贷款',
      kind: 'debt',
      period: 28,
      principal: function () {
        var V = State.variables;
        return V.bankLoanAmount || 0;
      },
      amount: function () {
        var V = State.variables;
        return V.bankLoanNextPayment || 0;
      },
      interest: 90,
      silent: true,
      active: function () {
        var V = State.variables;
        // 账户冻结期（劫案被抓）贷款结算暂停，出冻结后周期重新起算
        if (Time.days < (V.bankFrozenUntil || 0)) return false;
        // 违约后冻结：不再结算、不再复利，等银行当面讨债
        return V.bankAccount === 1 && (V.bankLoanPrincipal || 0) >= 100 && !(V.bankLoanMissed >= 1);
      },
      // 扣款只走储蓄账户；不足则储蓄全额抵债（减本金）后返回违约
      payWith: function (payment) {
        var V = State.variables;
        var savings = V.bankSavings || 0;
        if (savings >= payment) {
          V.bankSavings = savings - payment;
          // 储蓄划扣不动口袋余额，只记统计
          try { if (typeof window.money === 'function') window.money(-payment, 'bankLoan', { recordOnly: true }); } catch (e) {}
          return true;
        }
        // 不够：储蓄全部抵债，剩余欠款等讨债
        if (savings > 0) {
          V.bankSavings = 0;
          try { if (typeof window.money === 'function') window.money(-savings, 'bankLoan', { recordOnly: true }); } catch (e) {}
          var SE2 = window.SusatoModel && window.SusatoModel.economy;
          var st = SE2 && SE2.state('bankLoan');
          if (st) st.principal = Math.max(0, st.principal - savings);
        }
        return false;
      },
      onSettle: function (amt) {
        var SE2 = window.SusatoModel && window.SusatoModel.economy;
        if (!SE2) return;
        var st = SE2.state('bankLoan');
        var V = State.variables;
        if (st) {
          V.bankLoanPrincipal = st.principal;
          if (st.principal > 0) V.bankLoanDueDay = st.lastDay + 28;
        }
        V.khMsg = '银行从你的储蓄账户扣除了贷款还款 ' + SE2.fmt(amt) + '。';
      },
      onDefault: function () {
        var SE2 = window.SusatoModel && window.SusatoModel.economy;
        var V = State.variables;
        // 同步抵债后的剩余欠款到 UI 变量
        var st = SE2 && SE2.state('bankLoan');
        if (st) V.bankLoanPrincipal = st.principal;
        V.bankLoanMissed = (V.bankLoanMissed || 0) + 1;
        V.khMsg = '贷款到期。银行清空了你的储蓄账户，但仍欠 '
          + (SE2 ? SE2.fmt(V.bankLoanPrincipal || 0) : '') + '。他们在等你去银行说清楚。';
      },
      onPaidOff: function () {
        var SE2 = window.SusatoModel && window.SusatoModel.economy;
        var V = State.variables;
        V.bankLoanPrincipal = 0;
        V.bankLoanAmount = 0;
        V.bankLoanNextPayment = 0;
        V.bankLoanDueDay = 0;
        V.bankLoanMissed = 0;
        // 清框架状态，下次借款重新建档
        if (SE2) SE2.reset('bankLoan');
        V.khMsg = '你的贷款已全部还清。';
      },
    });
  }

  // ---- 迪冷保护卡：28 天自动续费 + 每日消减轻罪 ----
  function initProtectionCard() {
    if (typeof $ === 'undefined') return;

    $(document).on(':passageend', function () {
      try {
        var V = State.variables;
        if (!V || !V.dilenProtection) return;

        // 每日一次：自动抹掉少量妨害类犯罪（用 dilenProtectionDay 做日期门控）
        if (V.dilenProtectionDay !== Time.days) {
          V.dilenProtectionDay = Time.days;
          var pettyCrimes = ['obstruction', 'exposure', 'petty', 'trespassing'];
          for (var i = 0; i < pettyCrimes.length; i++) {
            var key = pettyCrimes[i];
            if (V.crime && V.crime[key] && V.crime[key].current > 0) {
              V.crime[key].current = Math.max(0, V.crime[key].current - 5);
            }
          }
        }

        // 续费检查
        var daysSince = Time.days - (V.dilenProtectionPaid || 0);
        if (daysSince >= 28) {
          V.dilenProtectionPaid = Time.days;
          if (!V.dilenProtectionAutoRenew) {
            V.dilenProtection = 0;
            V.khMsg = '你的表彰卡已到期。你关闭了自动续费，它安静地失效了。';
          } else if (V.money >= 300000) {
            V.money -= 300000;
            V.khMsg = '表彰卡自动续费 £3,000。';
          } else {
            V.dilenProtection = 0;
            V.khMsg = '你的资金不足。表彰卡已失效。';
          }
        }
      } catch (e) {}
    });
  }

  // ==================== 启动 ====================
  var SM = window.SusatoModel || {};

  if (SM.onInit) {
    SM.onInit(function () {
      initVariables();
      registerVito();
      registerBoxingAssets();
      registerSkills();
      registerFame();
      registerNpc();
      registerEconomy();
      initProtectionCard();
    });
  } else {
    if (typeof $ !== 'undefined') {
      $(document).one(':storyready', function () {
        initVariables();
        registerVito();
        registerBoxingAssets();
        registerSkills();
        registerFame();
        registerEconomy();
        initProtectionCard();
      });
    }
  }

  // 旧存档兜底：storyready 只跑一次，载入 mod 更新前的存档时新变量不会被补齐
  // （undefined 冷却锚会让 Time.days - undefined = NaN，所有冷却判定失真）。
  // initVariables 全部是 undefined 检查，幂等且廉价，挂 :passageend 每回合兜底。
  if (typeof $ !== 'undefined') {
    $(document).on(':passageend', function () {
      try { initVariables(); } catch (e) {}
      try { registerVito(); } catch (e) {}
      // khMsg 桥接: twee 里的 <<set $khMsg ...>> 保持原 API 不动;
      // 渲染后仍未被段落顶部消息块消费的 khMsg, 转入统一消息系统当页显示(此前会滞留到下一个有消息块的段落)。
      try {
        var SMb = window.SusatoModel, Vb = State.variables;
        if (SMb && SMb.notify && Vb && Vb.khMsg) {
          SMb.notify(Vb.khMsg, 'gold');
          Vb.khMsg = '';
          if (SMb.notifyFlush) SMb.notifyFlush();
        }
      } catch (e) {}
    });
  }
})();
