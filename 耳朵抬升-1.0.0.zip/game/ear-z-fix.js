// ==================================================================
//  ear-z-fix v2.14 — 耳朵 Z 层级修正（独立 mod，自起源框架-寿里美化包 2.14.0 移出）
//  将耳朵图层从 basehead (z=5) 提升到 ears (z=132.5)，让狼耳/猫耳/狐耳/牛耳穿过头发显示。
//  运行时 patchLayers 实现（不依赖游戏源码文本替换）。
//
//  API:
//    无。storyready 时自动 patch。
//
//  依赖: susato-core.js (SusatoModel.renderer.patchLayers)
//  去重守卫: SM._earZFixV1 —— 与旧版美化包(≤2.13.8)同装时防双注册（本钩子幂等，
//            双注册也无害，守卫只是省一次包装）。
// ==================================================================
(function () {
  'use strict';
  if (window.SusatoModel && window.SusatoModel.moduleOff && window.SusatoModel.moduleOff('ear-z-fix')) return;

  var SM = window.SusatoModel;
  if (!SM) return;
  if (SM._earZFixV1) return;
  SM._earZFixV1 = true;

  var SR = SM.renderer;
  if (!SR || !SR.patchLayers) return;

  SR.patchLayers(function (name) {
    return name === 'wolf_ears' || name === 'cat_ears' || name === 'fox_ears' ||
           name === 'cow_ear_left' || name === 'cow_ear_right' || name === 'cow_tag';
  }, function (layer) {
    var origZfn = layer.zfn;
    layer.zfn = function (o) {
      // 0.5.11+ 新增 tf_ears_layer 选项(前/后): front 时尊重玩家选择, 交给
      // origZfn(可能已被 ReplacePatcher 改成 front_hair+1)处理, 不强行覆盖。
      if (!o.hideHeadAcc && o.tf_ears_layer !== 'front' &&
          typeof ZIndices !== 'undefined' && typeof ZIndices.ears === 'number') {
        return ZIndices.ears;
      }
      return origZfn ? origZfn.call(this, o) : layer.z;
    };
  });
})();
