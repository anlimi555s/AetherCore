// ==================================================================
//  起源拓展-云存档 v1.1.0 — 玩家自有 GitHub 仓库
//
//  独立 mod，依赖起源框架。首次使用引导玩家创建私有仓库 + token，
//  之后存档存取到玩家自己的 GitHub。token 只存 localStorage，不经第三方。
//
//  入口: 存档 overlay 第三个标签页 (boot.json 往 titleSaves 标签栏注入,
//  与本体 Saves / Export/Import 并列, 渲染 susatoCloudPanel widget)。
//
//  存档格式：Save.serialize() 的输出（与本体"复制到剪贴板"同一编码），
//  恢复用 Save.deserialize()（与本体"从剪贴板读取"同路径）。
//  注意：Save.get()/Save.set() 不能用——get 拿到的是槽位存储对象
//  （新版本体存档在 IndexedDB，localStorage 槽位可能是空的），
//  set 在 SugarCube 里根本不存在。
//  每次上传都是独立文件, 永不覆盖已有云端存档。
//
//  国内直连 api.github.com 不通时，设置页"高级"可填反代地址。
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM) return;
  if (SM._cloudSaveLoaded) return;
  SM._cloudSaveLoaded = true;

  var DEFAULT_API = 'https://api.github.com';

  // ========== 配置读写 ==========
  var STORE_KEY = 'susato_cloud_cfg';
  function getCfg() {
    try { return JSON.parse(localStorage.getItem(STORE_KEY)) || {}; } catch (e) { return {}; }
  }
  function setCfg(v) {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(v)); } catch (e) {}
  }
  function apiBase(cfg) {
    return (cfg.apiBase || DEFAULT_API).replace(/\/+$/, '');
  }

  // ========== GitHub API ==========
  // 失败时抛出的 Error 带 status 字段，调用方按状态码区分场景
  // （比如 listSaves 的 404 = 还没上传过，不是错误）。
  function api(cfg, method, path, body) {
    var url = apiBase(cfg) + '/repos/' + cfg.owner + '/' + cfg.repo + '/contents/' + path;
    var opts = {
      method: method,
      headers: {
        'Authorization': 'Bearer ' + cfg.token,
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
      },
    };
    if (body) opts.body = JSON.stringify(body);
    return fetch(url, opts).then(function (r) {
      if (!r.ok) {
        var msg;
        if (r.status === 401 || r.status === 403) msg = 'Token 无效或无权限';
        else if (r.status === 404) msg = '仓库或文件不存在';
        else msg = 'GitHub ' + r.status;
        var err = new Error(msg);
        err.status = r.status;
        throw err;
      }
      // DELETE 等场景响应体可能为空
      return r.text().then(function (t) { return t ? JSON.parse(t) : {}; });
    });
  }

  // ========== 存档操作 ==========
  function upload(cfg) {
    // 本体部分场景禁止存档（savesAllowed = false），与本体行为保持一致
    if (window.savesAllowed === false) {
      return Promise.reject(new Error('当前场景禁止存档'));
    }
    var saveData;
    try {
      saveData = Save.serialize();
    } catch (e) { saveData = null; }
    if (!saveData) return Promise.reject(new Error('读取当前进度失败, 请先进入游戏'));

    var days = '?';
    try { if (window.Time && typeof Time.days === 'number') days = Time.days; } catch (e) {}
    var d = new Date();
    var pad = function (n) { return ('0' + n).slice(-2); };
    var ds = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
      + '-' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
    var name = 'DoL-第' + days + '天-' + ds + '.save';
    var path = 'saves/' + name;

    // 每次上传都是独立文件, 永不覆盖已有存档。
    // 文件名精确到秒基本不会撞; 万一同名已存在, 追加随机后缀另存。
    return api(cfg, 'GET', path).then(
      function () {
        var alt = 'DoL-第' + days + '天-' + ds + '-' + Math.random().toString(36).slice(2, 6) + '.save';
        return 'saves/' + alt;
      },
      function (e) { if (e.status === 404) return path; throw e; }
    ).then(function (finalPath) {
      return api(cfg, 'PUT', finalPath, {
        message: 'Upload save: ' + finalPath.slice(6),
        content: btoa(saveData), // serialize 输出是纯 ASCII，btoa 直接可用
        branch: cfg.branch || 'main',
      }).then(function () { return { name: finalPath.slice(6) }; });
    });
  }

  function listSaves(cfg) {
    return api(cfg, 'GET', 'saves/').then(function (entries) {
      if (!Array.isArray(entries)) return [];
      return entries.filter(function (e) { return e.type === 'file' && /\.(save|json)$/.test(e.name); })
        .map(function (e) { return { name: e.name, sha: e.sha, size: e.size }; })
        .sort(function (a, b) { return b.name.localeCompare(a.name); });
    }).catch(function (e) {
      // 404 = saves 目录还不存在（一次都没传过），按空列表处理
      if (e.status === 404) return [];
      throw e;
    });
  }

  function restoreSave(cfg, saveName) {
    return api(cfg, 'GET', 'saves/' + saveName).then(function (r) {
      var saveStr = atob((r.content || '').replace(/\n/g, ''));
      var ok = false;
      try {
        ok = Save.deserialize(saveStr) != null;
      } catch (e) { ok = false; }
      if (!ok) throw new Error('存档解析失败, 文件可能已损坏');
      return true;
    });
  }

  function deleteSave(cfg, saveName) {
    return api(cfg, 'GET', 'saves/' + saveName).then(function (r) {
      return api(cfg, 'DELETE', 'saves/' + saveName, {
        message: 'Delete save: ' + saveName,
        sha: r.sha,
        branch: cfg.branch || 'main',
      });
    });
  }

  // ========== UI 辅助 ==========
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  // 颜色一律走本体主题变量（--000 最亮 .. --900 最暗），跟随玩家主题
  var PANEL_STYLE = ''
    + '#susato-cloud-save { padding: 4px 2px; }'
    + '#susato-cloud-save h3 { margin: 0 0 10px; font-size: 15px; }'
    + '#susato-cloud-save .cs-step { margin: 8px 0; font-size: 13px; }'
    + '#susato-cloud-save .cs-input { width: 100%; max-width: 400px; padding: 6px 8px; background: var(--850); border: 1px solid var(--700); color: var(--000); border-radius: 4px; font-size: 13px; font-family: monospace; }'
    + '#susato-cloud-save .cs-btn { display: inline-block; padding: 5px 14px; margin: 4px 6px 4px 0; border-radius: 4px; cursor: pointer; font-size: 13px; border: 1px solid var(--700); background: var(--850); color: var(--000); }'
    + '#susato-cloud-save .cs-btn:hover { background: var(--800); }'
    + '#susato-cloud-save .cs-btn.danger { color: var(--red); border-color: var(--red); }'
    + '#susato-cloud-save .cs-status { font-size: 12px; color: var(--500); margin: 6px 0; min-height: 18px; }'
    + '#susato-cloud-save .cs-item { display: flex; align-items: center; gap: 8px; padding: 4px 0; border-bottom: 1px solid var(--700); font-size: 12px; }'
    + '#susato-cloud-save .cs-item span { flex: 1; }'
    + '#susato-cloud-save .cs-adv { margin-top: 10px; padding-top: 8px; border-top: 1px dashed var(--700); }';

  function makeRoot() {
    var box = el('div', '', '');
    box.id = 'susato-cloud-save';
    var style = document.createElement('style');
    style.textContent = PANEL_STYLE;
    box.appendChild(style);
    return box;
  }

  // ========== 首次设置 UI ==========
  function renderSetup(host) {
    host.innerHTML = '';
    var root = makeRoot();
    host.appendChild(root);

    root.appendChild(el('h3', 'gold', '云存档设置'));

    var cfg = getCfg();

    var step1 = el('div', 'cs-step', '');
    step1.innerHTML = '<b>1.</b> 创建私有仓库: <a class="gold" href="https://github.com/new?name=susato-saves&visibility=private&description=DoL+Cloud+Saves" target="_blank" rel="noopener">一键创建 susato-saves</a>';
    root.appendChild(step1);

    var step2 = el('div', 'cs-step', '');
    step2.innerHTML = '<b>2.</b> 生成 token: <a class="gold" href="https://github.com/settings/tokens/new?description=susato-cloud-save&scopes=repo" target="_blank" rel="noopener">点此生成</a>, Expiration 选 No expiration, 点 Generate 后复制';
    root.appendChild(step2);

    var step3 = el('div', 'cs-step', '');
    step3.innerHTML = '<b>3.</b> 粘贴 token:';
    root.appendChild(step3);

    var tokenInput = el('input', 'cs-input', '');
    tokenInput.type = 'password';
    tokenInput.placeholder = 'ghp_xxxx 或 github_pat_xxxx';
    tokenInput.value = cfg.token || '';
    root.appendChild(tokenInput);

    var repoLabel = el('div', 'cs-step', '');
    repoLabel.innerHTML = '<b>仓库名</b>（默认 susato-saves, 如果改了第1步的名字这里也要改）:';
    root.appendChild(repoLabel);
    var repoInput = el('input', 'cs-input', '');
    repoInput.placeholder = 'susato-saves';
    repoInput.value = cfg.repo || 'susato-saves';
    root.appendChild(repoInput);

    // 高级: API 地址（国内直连 api.github.com 不通时填反代）
    var adv = el('div', 'cs-adv', '');
    var advLabel = el('div', 'cs-step', '');
    advLabel.innerHTML = '<b>高级</b> API 地址（留空用官方 api.github.com; 国内直连不通时填反代地址）:';
    adv.appendChild(advLabel);
    var apiInput = el('input', 'cs-input', '');
    apiInput.placeholder = DEFAULT_API;
    apiInput.value = cfg.apiBase || '';
    adv.appendChild(apiInput);
    root.appendChild(adv);

    var status = el('div', 'cs-status', '');
    root.appendChild(status);

    var saveBtn = el('button', 'cs-btn gold', '保存并连接');
    saveBtn.onclick = function () {
      var token = tokenInput.value.trim();
      var repo = repoInput.value.trim() || 'susato-saves';
      var base = apiInput.value.trim().replace(/\/+$/, '');
      // classic token 前缀 ghp_, fine-grained 前缀 github_pat_, 都合法
      if (!token || !/^(ghp_|github_pat_)/.test(token)) {
        status.textContent = 'Token 格式不对, 应以 ghp_ 或 github_pat_ 开头';
        return;
      }
      if (base && !/^https?:\/\//.test(base)) {
        status.textContent = 'API 地址要以 http(s):// 开头';
        return;
      }
      status.textContent = '验证中……';
      var verifyBase = base || DEFAULT_API;
      fetch(verifyBase + '/user', { headers: { 'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github.v3+json' } })
        .then(function (r) {
          if (!r.ok) throw new Error('Token 无效 (HTTP ' + r.status + ')');
          return r.json();
        })
        .then(function (user) {
          if (!user || !user.login) throw new Error('接口响应异常, 检查 API 地址');
          var newCfg = { token: token, owner: user.login, repo: repo, branch: 'main' };
          if (base) newCfg.apiBase = base;
          setCfg(newCfg);
          status.textContent = '已连接 ' + user.login + '/' + repo;
          saveBtn.textContent = '已保存';
          saveBtn.disabled = true;
          setTimeout(function () { renderMain(host, newCfg); }, 800);
        })
        .catch(function (e) {
          status.textContent = 'Token 验证失败: ' + (e.message || e);
        });
    };
    root.appendChild(saveBtn);

    if (cfg.token && cfg.owner && cfg.repo) {
      var backBtn = el('button', 'cs-btn', '返回, 用已保存配置');
      backBtn.onclick = function () { renderMain(host, cfg); };
      root.appendChild(backBtn);
    }
  }

  // ========== 主界面 ==========
  function renderMain(host, cfg) {
    host.innerHTML = '';
    var root = makeRoot();
    host.appendChild(root);

    var headerRow = el('div', '');
    headerRow.style.cssText = 'display:flex;justify-content:space-between;align-items:center;gap:8px;';
    headerRow.appendChild(el('h3', 'gold', cfg.owner + '/' + cfg.repo));

    var settingsBtn = el('button', 'cs-btn', '设置');
    settingsBtn.onclick = function () { renderSetup(host); };
    headerRow.appendChild(settingsBtn);
    root.appendChild(headerRow);

    var status = el('div', 'cs-status', '');
    root.appendChild(status);

    var btnRow = el('div', '');
    btnRow.style.cssText = 'margin: 6px 0;';

    var uploadBtn = el('button', 'cs-btn gold', '上传当前进度');
    uploadBtn.onclick = function () {
      uploadBtn.disabled = true;
      status.textContent = '上传中……';
      upload(cfg).then(function (r) {
        status.textContent = '已上传: ' + r.name;
        uploadBtn.disabled = false;
        refreshList();
      }, function (e) {
        status.textContent = '上传失败: ' + (e.message || e);
        uploadBtn.disabled = false;
      });
    };
    btnRow.appendChild(uploadBtn);

    var refreshBtn = el('button', 'cs-btn', '刷新');
    refreshBtn.onclick = refreshList;
    btnRow.appendChild(refreshBtn);
    root.appendChild(btnRow);

    var listBox = el('div', '');
    listBox.style.cssText = 'max-height:240px;overflow-y:auto;';
    root.appendChild(listBox);

    function refreshList() {
      listBox.innerHTML = '';
      status.textContent = '加载中……';
      listSaves(cfg).then(function (saves) {
        status.textContent = saves.length ? '共 ' + saves.length + ' 个存档' : '暂无云端存档';
        if (!saves.length) { listBox.appendChild(el('div', 'cs-status', '还没有上传过存档')); return; }
        saves.forEach(function (s) {
          var row = el('div', 'cs-item', '');
          row.appendChild(el('span', '', s.name.replace(/\.(save|json)$/, '')));
          var rst = el('button', 'cs-btn', '恢复');
          rst.onclick = function () {
            if (!confirm('确定读取 [' + s.name + '] 覆盖当前进度？')) return;
            status.textContent = '恢复中……';
            restoreSave(cfg, s.name).then(function () {
              // deserialize 成功后引擎自动加载该进度并重渲染。
              // 内嵌在存档 overlay 里时跟随本体 loadSaveData 的行为关掉 overlay。
              try { if (window.closeOverlay) window.closeOverlay(); } catch (e2) {}
              closePanel();
            }, function (e) { status.textContent = '恢复失败: ' + (e.message || e); });
          };
          row.appendChild(rst);
          var delBtn = el('button', 'cs-btn danger', '删');
          delBtn.onclick = function () {
            if (!confirm('删除 [' + s.name + ']？')) return;
            deleteSave(cfg, s.name).then(function () { refreshList(); }, function (e) { status.textContent = '删除失败: ' + (e.message || e); });
          };
          row.appendChild(delBtn);
          listBox.appendChild(row);
        });
      }, function (e) { status.textContent = '加载失败: ' + (e.message || e); });
    }

    refreshList();
  }

  // ========== 面板 ==========
  // 面板是纯 DOM（没有对应 widget），不走框架 openPanel(widgetName)，
  // 直接用本体 Dialog + append。带上 susato-panel 标记类，
  // 框架的 closePanel 能识别并只关自己的面板。
  function dialogUsable() {
    return typeof Dialog !== 'undefined' && Dialog.setup && Dialog.open &&
      (Dialog.append || Dialog.body);
  }

  function closePanel() {
    if (SM.ui && SM.ui.closePanel) { SM.ui.closePanel(); return; }
    try { if (typeof Dialog !== 'undefined' && Dialog.close) Dialog.close(); } catch (e) {}
    var fb = document.getElementById('susato-cloud-fallback');
    if (fb && fb.parentNode) fb.parentNode.removeChild(fb);
  }

  function openPanel() {
    var cfg = getCfg();
    var host = document.createElement('div');
    host.style.cssText = 'min-width:300px;max-width:480px;';

    if (!cfg.token || !cfg.owner) {
      renderSetup(host);
    } else {
      renderMain(host, cfg);
    }

    if (dialogUsable()) {
      try {
        Dialog.setup('云存档', 'susato-panel susato-cloud');
        if (Dialog.append) Dialog.append(host);
        else Dialog.body().appendChild(host);
        Dialog.open();
        return;
      } catch (e) {}
    }

    // 兜底: 原生 Dialog 不可用时的固定面板
    var dlg = document.createElement('div');
    dlg.id = 'susato-cloud-fallback';
    dlg.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:9999;background:var(--900);border:2px solid var(--700);border-radius:8px;padding:16px;max-height:80vh;overflow-y:auto;color:var(--000);';
    var closeBtn = el('button', 'cs-btn', '关闭');
    closeBtn.style.cssText = 'float:right;';
    closeBtn.onclick = function () { dlg.remove(); };
    dlg.appendChild(closeBtn);
    dlg.appendChild(host);
    document.body.appendChild(dlg);
  }

  SM._cloudOpenPanel = openPanel; // Dialog 入口保留, 供管理器/控制台调用

  // 页内渲染入口: susatoCloudPanel widget (存档 overlay 第三标签页) 内含
  // <div id="susato-cloud-inline"> + <<run 本函数>>。
  // <<run>> 执行时 div 可能还在渲染 fragment 里没进 document, setTimeout 0 等插入后再渲染。
  SM._cloudRenderInline = function () {
    setTimeout(function () {
      var host = document.getElementById('susato-cloud-inline');
      if (!host || host.getAttribute('data-cs-rendered')) return;
      host.setAttribute('data-cs-rendered', '1');
      var cfg = getCfg();
      if (!cfg.token || !cfg.owner) renderSetup(host);
      else renderMain(host, cfg);
    }, 0);
  };

  console.log('[cloud-save] 已加载, 存档页云存档标签已注册');
})();
