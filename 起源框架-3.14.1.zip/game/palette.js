// ==================================================================
//  起源框架 — 主题工坊 (Theme Workshop)
//
//  整合入起源框架 v3.14。Options 第 6 个标签。功能:
//  - 配色: 46 个 CSS 变量(灰阶/强调色/状态色/工具色 4 组)
//  - 效果: 透明度滑块 + 背景图片(上传/URL/清除)
//  - 画廊: 预设 + 自定义主题色条卡片, 点选即编
//  - 命名保存/加载/删除, 导入/导出 JSON, 预置 4 套社区主题(不可删)
//  走 DoL 原生 [data-theme="custom"] CSS 块应用, 与 ThemeManager 零冲突。
// ==================================================================
(function () {
  'use strict';

  var SM = window.SusatoModel;
  if (!SM) return;
  if (SM.palette) return;
  var SP = SM.palette = {};

  // ========== 常量 ==========
  var GROUPS = [
    { id:'greyscale', label:'灰阶 Greyscale', vars:['--000','--100','--150','--200','--300','--400','--500','--600','--700','--750','--800','--850','--900'] },
    { id:'accents', label:'强调色 Accents', vars:['--red','--pink','--pink-secondary','--gold','--blue','--blue-secondary','--green','--green-secondary','--purple','--purple-secondary','--teal','--lime','--orange','--brown','--silver','--yellow','--black'] },
    { id:'status', label:'状态色 Status', vars:['--lewd','--defiant','--meek','--brat','--relaxed','--anxious','--veteran','--methodical','--scarred','--tattooed','--manager'] },
    { id:'utility', label:'工具色 Utility', vars:['--link','--link-hover','--danger','--tooltip-background','--tooltip-border'] }
  ];
  var DEFAULTS = { '--000':'#eeeeee','--100':'#dddddd','--150':'#cccccc','--200':'#bbbbbb','--300':'#aaaaaa','--400':'#999999','--500':'#888888','--600':'#777777','--700':'#666666','--750':'#444444','--800':'#333333','--850':'#222222','--900':'#111111','--red':'#ec3535','--pink':'#e40081','--pink-secondary':'#d67caf','--gold':'#ffd700','--blue':'#4372ff','--blue-secondary':'#559bc0','--green':'#38b20a','--green-secondary':'#7caf7c','--purple':'#8800ff','--purple-secondary':'#aa4bc8','--teal':'#08c1c1','--lime':'#44e342','--orange':'#f28500','--brown':'#4c2217','--silver':'#c0c0c0','--yellow':'#ffff00','--black':'#929292','--lewd':'#ff80c5','--defiant':'#ec3535','--meek':'#e40081','--brat':'#f28500','--relaxed':'#38b20a','--anxious':'#aa4bc8','--veteran':'#4372ff','--methodical':'#559bc0','--scarred':'#888888','--tattooed':'#d67caf','--manager':'#8800ff','--link':'#5888dd','--link-hover':'#88aaff','--danger':'#c62b2b','--tooltip-background':'#1a1919','--tooltip-border':'#b0b0b4' };
  var COMMUNITY = { '温暖暮光':{'--000':'#f5e6d3','--100':'#e8d5bc','--150':'#d4bfa0','--200':'#c0a885','--300':'#aa9270','--400':'#947c5c','--500':'#7e6848','--600':'#685438','--700':'#52422c','--750':'#3d3020','--800':'#2d2216','--850':'#1e1610','--900':'#120d0a','--red':'#d4442a','--gold':'#f0a030','--blue':'#5b8abf','--green':'#6b9e3a','--pink':'#c76b8a','--purple':'#7e5da0','--teal':'#4a9088','--orange':'#e08040','--lime':'#8aac40','--pink-secondary':'#b88a9a','--purple-secondary':'#8a70a8','--blue-secondary':'#6b8aaa','--green-secondary':'#7a9a5a','--brown':'#5c3820','--silver':'#c0b8a0','--yellow':'#e8c840','--black':'#8a7a60','--lewd':'#e080a0','--defiant':'#d4442a','--meek':'#c76b8a','--brat':'#e08040','--relaxed':'#6b9e3a','--anxious':'#7e5da0','--veteran':'#5b8abf','--methodical':'#6b8aaa','--scarred':'#7a6550','--tattooed':'#b88a9a','--manager':'#7e5da0','--link':'#6b9ec0','--link-hover':'#8ab8e0','--danger':'#c04030','--tooltip-background':'#1e1610','--tooltip-border':'#7a6550'},'深海幽蓝':{'--000':'#d6e6f0','--100':'#c0d8e8','--150':'#a8c8e0','--200':'#90b8d0','--300':'#78a8c0','--400':'#6098b0','--500':'#5088a0','--600':'#407890','--700':'#306880','--750':'#204c60','--800':'#183848','--850':'#102430','--900':'#081420','--red':'#e06070','--gold':'#d0c060','--blue':'#5098e0','--green':'#50a060','--pink':'#c070a0','--purple':'#7068c0','--teal':'#40a0a0','--orange':'#d09050','--lime':'#80b050','--pink-secondary':'#a070b0','--purple-secondary':'#8070c0','--blue-secondary':'#6090c0','--green-secondary':'#60a070','--brown':'#504030','--silver':'#a0b8c8','--yellow':'#d8d050','--black':'#688090','--lewd':'#c080b0','--defiant':'#e06070','--meek':'#c070a0','--brat':'#d09050','--relaxed':'#50a060','--anxious':'#7068c0','--veteran':'#5098e0','--methodical':'#6090c0','--scarred':'#507080','--tattooed':'#a070b0','--manager':'#7068c0','--link':'#60a0d0','--link-hover':'#80c0f0','--danger':'#d05060','--tooltip-background':'#0c1824','--tooltip-border':'#407090'},'樱花粉雾':{'--000':'#f0e0e8','--100':'#e8d0dc','--150':'#dcc0d0','--200':'#d0b0c4','--300':'#c0a0b4','--400':'#b090a4','--500':'#a08094','--600':'#907084','--700':'#806074','--750':'#604858','--800':'#483440','--850':'#30242c','--900':'#1c1418','--red':'#d45068','--gold':'#d0a060','--blue':'#8090c8','--green':'#70a068','--pink':'#d070a0','--purple':'#9070b8','--teal':'#609890','--orange':'#d08860','--lime':'#90a860','--pink-secondary':'#c080a8','--purple-secondary':'#9880c0','--blue-secondary':'#8898c0','--green-secondary':'#80a878','--brown':'#584038','--silver':'#c0acb8','--yellow':'#d8c060','--black':'#887880','--lewd':'#d080b0','--defiant':'#d45068','--meek':'#d070a0','--brat':'#d08860','--relaxed':'#70a068','--anxious':'#9070b8','--veteran':'#8090c8','--methodical':'#8898c0','--scarred':'#786870','--tattooed':'#c080a8','--manager':'#9070b8','--link':'#8898c8','--link-hover':'#a8b8e8','--danger':'#c04860','--tooltip-background':'#201820','--tooltip-border':'#786870'},'翡翠暗夜':{'--000':'#d8e8d0','--100':'#c8dcc0','--150':'#b4d0a8','--200':'#a0c490','--300':'#8cb478','--400':'#78a460','--500':'#649448','--600':'#508438','--700':'#3c7028','--750':'#28541c','--800':'#1c3c14','--850':'#14280e','--900':'#0c1808','--red':'#d05040','--gold':'#c0a040','--blue':'#6098c8','--green':'#50b040','--pink':'#b87090','--purple':'#7868b8','--teal':'#40a888','--orange':'#d08840','--lime':'#80c040','--pink-secondary':'#a870a0','--purple-secondary':'#8070b8','--blue-secondary':'#6888b8','--green-secondary':'#60a858','--brown':'#4c3c28','--silver':'#a8b898','--yellow':'#d0c040','--black':'#688060','--lewd':'#b880a0','--defiant':'#d05040','--meek':'#b87090','--brat':'#d08840','--relaxed':'#50b040','--anxious':'#7868b8','--veteran':'#6098c8','--methodical':'#6888b8','--scarred':'#4c7040','--tattooed':'#a870a0','--manager':'#7868b8','--link':'#68a0c0','--link-hover':'#88c0e0','--danger':'#c04838','--tooltip-background':'#0e1808','--tooltip-border':'#386028'} };
  var PROTECTED = ['温暖暮光', '深海幽蓝', '樱花粉雾', '翡翠暗夜'];

  // ========== 存储 ==========
  var ACTIVE_KEY = 'susato_palette_active', THEMES_KEY = 'susato_palette_themes', SEED_KEY = 'susato_palette_seeded', BG_KEY = 'susato_palette_bg', BG_OP_KEY = 'susato_palette_bg_opacity', OP_KEY = 'susato_palette_opacity';
  var _pendingFlash = '';
  var _bgDataUrl = '';  // 内存持有当前 data URL, 绕过 localStorage 配额限制

  // IndexedDB 存储大图 (localStorage 5-10MB, IDB 数百 MB)
  function _idbOpen(cb) { var r = indexedDB.open('susato_bg', 1); r.onupgradeneeded = function() { r.result.createObjectStore('bg'); }; r.onsuccess = function() { cb(r.result); }; r.onerror = function() { cb(null); }; }
  function _idbStore(dataUrl) { _idbOpen(function(db) { if (!db) return; try { var tx = db.transaction('bg', 'readwrite'); tx.objectStore('bg').put(dataUrl, 'current'); tx.oncomplete = function() { db.close(); }; } catch(e) { db.close(); } }); }
  function _idbLoad(cb) { _idbOpen(function(db) { if (!db) return cb(''); try { var tx = db.transaction('bg', 'readonly'); var r = tx.objectStore('bg').get('current'); r.onsuccess = function() { db.close(); cb(r.result || ''); }; r.onerror = function() { db.close(); cb(''); }; } catch(e) { db.close(); cb(''); } }); }
  function _idbDelete() { _idbOpen(function(db) { if (!db) return; try { var tx = db.transaction('bg', 'readwrite'); tx.objectStore('bg').delete('current'); tx.oncomplete = function() { db.close(); }; } catch(e) { db.close(); } }); }

  function loadJSON(k, fb) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : fb; } catch (e) { return fb; } }
  function saveJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function getBg() { try { if (_bgDataUrl) return _bgDataUrl; var v = localStorage.getItem(BG_KEY) || ''; return v === '__idb__' ? '' : v; } catch (e) { return ''; } }
  function setBg(url) { try { if (url) { var old = localStorage.getItem(BG_KEY); var stored = false; try { localStorage.setItem(BG_KEY, url); stored = true; } catch (e) { try { localStorage.setItem(BG_KEY, '__idb__'); } catch (e2) {} _idbStore(url); } if (stored && old === '__idb__') _idbDelete(); } else { _bgDataUrl = ''; localStorage.removeItem(BG_KEY); _idbDelete(); } } catch (e) {} }
  function getOpacity() { try { var v = localStorage.getItem(OP_KEY); return v ? parseFloat(v) : 0; } catch (e) { return 0; } }
  function setOpacity(v) { try { if (v > 0) localStorage.setItem(OP_KEY, String(v)); else localStorage.removeItem(OP_KEY); } catch (e) {} }
  function getBgOpacity() { try { var v = localStorage.getItem(BG_OP_KEY); return v ? parseFloat(v) : 0; } catch (e) { return 0; } }
  function setBgOpacity(v) { try { if (v > 0) localStorage.setItem(BG_OP_KEY, String(v)); else localStorage.removeItem(BG_OP_KEY); } catch (e) {} }
  function shallowClone(o) { var c = {}; for (var k in o) { if (Object.prototype.hasOwnProperty.call(o, k)) c[k] = o[k]; } return c; }

  // ========== CSS 应用 ==========
  function applyAll() {
    var colors = loadJSON(ACTIVE_KEY, shallowClone(DEFAULTS));
    var bgUrl = getBg();
    var opacity = getOpacity();
    var bgOpacity = getBgOpacity();
    var css = '[data-theme="custom"] {\n';
    for (var key in colors) { if (Object.prototype.hasOwnProperty.call(colors, key)) css += '\t' + key + ': ' + colors[key] + ';\n'; }
    css += '}\n';
    // 背景图通过 ::before 伪元素, 独立控透明度
    if (bgUrl) {
      css += '[data-theme="custom"] body::before {\n\tcontent: "";\n\tposition: fixed;\n\tinset: 0;\n\tbackground-image: url(' + bgUrl + ');\n\tbackground-size: cover;\n\tbackground-position: center;\n\tbackground-repeat: no-repeat;\n\tpointer-events: none;\n\tz-index: -1;\n';
      if (bgOpacity > 0) css += '\topacity: ' + bgOpacity.toFixed(2) + ';\n';
      css += '}\n';
    }
    // 界面整体透明度: 100=不透明, 30=最透
    if (opacity > 0) {
      css += '[data-theme="custom"] body {\n\topacity: ' + opacity.toFixed(2) + ';\n}\n';
    }
    var el = document.getElementById('susato-palette-style');
    if (!el) { el = document.createElement('style'); el.id = 'susato-palette-style'; (document.head || document.documentElement).appendChild(el); }
    el.textContent = css;
  }
  function saveColors(c) { saveJSON(ACTIVE_KEY, c); }

  // ========== UI 样式(一次性注入) ==========
  function injectUIStyle() {
    if (document.getElementById('susato-palette-ui-css')) return;
    var s = document.createElement('style');
    s.id = 'susato-palette-ui-css';
    s.textContent = '.susato-hidden{display:none!important}#susato-palette-editor{padding:4px 2px;max-height:62vh;overflow-y:auto}.sp-gallery{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}.sp-card{width:100px;border:1px solid var(--700);border-radius:5px;padding:4px;cursor:pointer;text-align:center;background:var(--850);transition:border-color .15s}.sp-card:hover{border-color:var(--gold)}.sp-card.active{border-color:var(--gold);box-shadow:0 0 4px var(--gold)}.sp-card-strip{height:18px;border-radius:3px;margin-bottom:3px;display:flex;overflow:hidden}.sp-card-strip span{flex:1}.sp-card-name{font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sp-card-tag{font-size:10px;color:var(--500)}.sp-card-del{position:absolute;top:1px;right:4px;font-size:10px;color:var(--600);cursor:pointer;display:none}.sp-card:hover .sp-card-del{display:block}.sp-card-del:hover{color:var(--red)}.sp-actions{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:6px 0;padding:6px 8px;background:var(--850);border-radius:4px;font-size:12px}.sp-actions input[type=text]{width:100px;font-size:12px;background:var(--850);border:1px solid var(--700);color:var(--000);padding:2px 6px;border-radius:3px}.sp-actions button,.sp-btn{font-size:11px;padding:3px 12px;background:var(--850);border:1px solid var(--700);color:var(--000);border-radius:3px;cursor:pointer}.sp-actions button:hover,.sp-btn:hover{background:var(--800)}.sp-actions button.primary,.sp-btn.primary{border-color:var(--gold);color:var(--gold)}.sp-section{margin:4px 0;border:1px solid var(--700);border-radius:4px}.sp-section summary{cursor:pointer;font-size:13px;padding:5px 8px;background:var(--850);border-radius:4px;color:var(--000);user-select:none}.sp-section summary:hover{background:var(--800)}.sp-section .sp-mod{font-size:11px;color:var(--gold);margin-left:4px}.sp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:2px 6px;padding:4px 6px}.sp-row{display:flex;align-items:center;gap:4px;font-size:12px}.sp-row .sp-vname{font-family:monospace;font-size:10px;min-width:56px;color:var(--400)}.sp-row .sp-swatch{width:18px;height:18px;border-radius:3px;flex-shrink:0;border:1px solid var(--600);cursor:pointer}.sp-row input[type=color]{width:24px;height:18px;padding:0;border:1px solid var(--700);background:var(--850);cursor:pointer;border-radius:3px}.sp-row input[type=text]{width:60px;font-size:10px;font-family:monospace;background:var(--850);border:1px solid var(--700);color:var(--000);padding:1px 4px;border-radius:3px}.sp-row .sp-rst{font-size:10px;cursor:pointer;color:var(--600);padding:0 2px;user-select:none}.sp-row .sp-rst:hover{color:var(--red)}.sp-fx{padding:6px 8px;display:flex;flex-wrap:wrap;align-items:center;gap:10px;font-size:12px}.sp-fx input[type=range]{width:120px}.sp-msg{font-size:11px;color:var(--gold);min-height:16px}';
    (document.head || document.documentElement).appendChild(s);
  }

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }

  // ========== 主题画廊卡片 ==========
  function _colorStrip(colors) {
    // 取灰阶中段 5 色 + 强调色 gold/red/blue/green 形成色条
    var picks = ['--200','--400','--600','--800','--900','--gold','--red','--blue','--green'];
    var strip = '';
    for (var i = 0; i < picks.length; i++) {
      strip += '<span style="background:' + (colors[picks[i]] || DEFAULTS[picks[i]] || '#888') + '"></span>';
    }
    return strip;
  }

  // ========== 编辑器主体 ==========
  SP.render = function (editingName) {
    var host = document.getElementById('susato-palette-editor');
    if (!host) return;
    host.innerHTML = '';

    var colors = loadJSON(ACTIVE_KEY, shallowClone(DEFAULTS));
    var saved = loadJSON(THEMES_KEY, {});
    var curBg = getBg();
    var curOpacity = getOpacity();
    var curBgOpacity = getBgOpacity();
    var _editing = editingName || null;
    var _editColors = shallowClone(colors);
    var _editBg = curBg;
    var _editOpacity = curOpacity;
    var _editBgOpacity = curBgOpacity;
    var msg = el('div', 'sp-msg');
    host.appendChild(msg);
    function flash(text) { msg.textContent = text; setTimeout(function(){ if(msg.textContent===text) msg.textContent=''; }, 2500); }

    function startEdit(name, srcColors, srcBg, srcOpacity, srcBgOpacity) {
      // 先写入 ACTIVE_KEY 再重绘, 否则 SP.render() 会从 ACTIVE_KEY 读回旧数据
      saveColors(shallowClone(srcColors));
      // 仅在新主题明确带有背景时覆盖, 否则保留当前背景
      if (srcBg) setBg(srcBg);
      setOpacity(srcOpacity > 0 ? srcOpacity : 0);
      setBgOpacity(srcBgOpacity > 0 ? srcBgOpacity : 0);
      applyAll();
      try { SP.applyAsTheme(); } catch (e) {}
      SP.render(name);
    }
    function applyEdits() {
      saveColors(shallowClone(_editColors));
      setBg(_editBg || '');
      setOpacity(_editOpacity > 0 ? _editOpacity : 0);
      setBgOpacity(_editBgOpacity > 0 ? _editBgOpacity : 0);
      applyAll();
    }
    function modCount() { var n=0; for(var k in _editColors){if(_editColors[k]!==DEFAULTS[k])n++;} return n; }

    // ---- 主题画廊 ----
    var gallery = el('div', 'sp-gallery');
    // 预设
    for (var tn in COMMUNITY) {
      if (!Object.prototype.hasOwnProperty.call(COMMUNITY, tn)) continue;
      (function(name, cols) {
        var card = el('div', 'sp-card' + (_editing === name ? ' active' : ''));
        var strip = el('div', 'sp-card-strip');
        strip.innerHTML = _colorStrip(cols);
        card.appendChild(strip);
        card.appendChild(el('div', 'sp-card-name', name));
        card.appendChild(el('div', 'sp-card-tag', '预设'));
        card.onclick = function () { startEdit(name, cols, '', 0, 0); };
        gallery.appendChild(card);
      })(tn, COMMUNITY[tn]);
    }
    // 分隔
    var sep = el('div', '');
    sep.style.cssText = 'width:1px;background:var(--700);align-self:stretch;margin:0 2px;';
    gallery.appendChild(sep);
    // 自定义主题
    var savedNames = Object.keys(saved).sort();
    for (var si = 0; si < savedNames.length; si++) {
      (function(name, t) {
        var card = el('div', 'sp-card' + (_editing === name ? ' active' : ''));
        card.style.position = 'relative';
        var strip = el('div', 'sp-card-strip');
        strip.innerHTML = _colorStrip(t.colors || {});
        card.appendChild(strip);
        card.appendChild(el('div', 'sp-card-name', name));
        if (t.bgImage) card.appendChild(el('div', 'sp-card-tag', '含背景'));
        if (PROTECTED.indexOf(name) < 0) {
          var del = el('span', 'sp-card-del', 'x');
          del.onclick = function (ev) { ev.stopPropagation(); if (!deleteTheme(name)) flash('删除失败'); };
          card.appendChild(del);
        }
        card.onclick = function () { startEdit(name, t.colors || {}, t.bgImage || '', t.opacity || 0, t.bgOpacity || 0); };
        gallery.appendChild(card);
      })(savedNames[si], saved[savedNames[si]]);
    }
    // + 新建按钮
    var newCard = el('div', 'sp-card');
    newCard.style.cssText += 'border-style:dashed;display:flex;align-items:center;justify-content:center;min-height:52px;';
    newCard.appendChild(el('div', 'sp-card-name', '+ 新建'));
    newCard.onclick = function () { startEdit(null, shallowClone(DEFAULTS), '', 0, 0); };
    gallery.appendChild(newCard);
    host.appendChild(gallery);

    // ---- 当前编辑信息 ----
    var editLabel = _editing ? '编辑: ' + _editing : '编辑: 未命名主题';
    var changed = modCount();
    if (changed > 0) editLabel += ' (已修改 ' + changed + ' 色)';

    // ---- 操作栏 ----
    var actions = el('div', 'sp-actions');
    actions.appendChild(el('span', '', editLabel));
    actions.appendChild(el('span', '', '')); // spacer
    var nameInput = el('input');
    nameInput.type = 'text'; nameInput.placeholder = '主题名'; nameInput.value = _editing || '';
    actions.appendChild(nameInput);
    var saveBtn = el('button', '', '保存');
    var applyBtn = el('button', 'primary', '应用主题');
    var exportBtn = el('button', '', '导出');
    var importBtn = el('button', '', '导入');
    actions.appendChild(saveBtn); actions.appendChild(applyBtn);
    actions.appendChild(exportBtn); actions.appendChild(importBtn);
    host.appendChild(actions);
    host.appendChild(msg);

    // 事件
    saveBtn.onclick = function () {
      var n = nameInput.value.trim();
      if (!n) { flash('请输入主题名'); return; }
      if (PROTECTED.indexOf(n) >= 0) { flash('预置主题不可覆盖'); return; }
      var s2 = loadJSON(THEMES_KEY, {});
      s2[n] = { name: n, colors: shallowClone(_editColors), bgImage: _editBg, opacity: _editOpacity, bgOpacity: _editBgOpacity };
      saveJSON(THEMES_KEY, s2);
      applyEdits();
      _pendingFlash = '已保存: ' + n;
      SP.render(n);
    };
    applyBtn.onclick = function () {
      applyEdits();
      try { SP.applyAsTheme(); } catch (e) {}
      flash('已应用');
    };
    exportBtn.onclick = function () {
      var data = { name: _editing || '自定义', colors: shallowClone(_editColors), bgImage: _editBg, opacity: _editOpacity, bgOpacity: _editBgOpacity, version: 1, exportedAt: new Date().toISOString() };
      var json = JSON.stringify(data, null, 2);
      if (navigator.clipboard) { navigator.clipboard.writeText(json).then(function(){flash('已复制到剪贴板');},function(){flash('复制失败');}); }
      var ta = el('textarea');
      ta.style.cssText = 'width:100%;height:100px;font-size:10px;font-family:monospace;background:var(--850);color:var(--000);border:1px solid var(--700);margin-top:4px;';
      ta.value = json; ta.readOnly = true; ta.onclick = function(){this.select();};
      host.insertBefore(ta, host.firstChild);
      setTimeout(function(){if(ta.parentNode)ta.parentNode.removeChild(ta);},25000);
    };
    importBtn.onclick = function () {
      var json = prompt('粘贴主题 JSON:');
      if (!json) return;
      var data;
      try { data = JSON.parse(json); } catch (e) { flash('JSON 格式无效'); return; }
      if (!data || !data.colors || Object.keys(data.colors).length < 10) { flash('缺少 colors 字段或条目太少'); return; }
      var name = data.name || '导入主题';
      var merged = shallowClone(DEFAULTS);
      for (var vk in data.colors) { if (Object.prototype.hasOwnProperty.call(DEFAULTS, vk)) merged[vk] = data.colors[vk]; }
      // 存入选单
      var s3 = loadJSON(THEMES_KEY, {});
      s3[name] = { name: name, colors: shallowClone(merged), bgImage: data.bgImage || '', opacity: data.opacity || 0, bgOpacity: data.bgOpacity || 0 };
      saveJSON(THEMES_KEY, s3);
      _pendingFlash = '已导入: ' + name;
      startEdit(name, merged, data.bgImage || '', data.opacity || 0, data.bgOpacity || 0);
    };

    // ---- 编辑器(折叠) ----
    // 颜色组
    var colorSec = el('details', 'sp-section');
    var colorSum = el('summary');
    colorSum.appendChild(el('span', '', '颜色'));
    if (changed > 0) colorSum.appendChild(el('span', 'sp-mod', '(' + changed + '/46)'));
    colorSec.appendChild(colorSum);
    GROUPS.forEach(function (g) {
      var det = el('details', 'sp-section');
      det.style.cssText = 'margin:2px 0;border:none;';
      var gSum = el('summary');
      var gm = 0;
      g.vars.forEach(function(v){ if(_editColors[v]!==DEFAULTS[v]) gm++; });
      gSum.textContent = g.label;
      if (gm > 0) { var cnt = el('span', 'sp-mod', '(' + gm + '/' + g.vars.length + ')'); gSum.appendChild(cnt); det.setAttribute('open', ''); }
      det.appendChild(gSum);
      var grid = el('div', 'sp-grid');
      g.vars.forEach(function (v) {
        var val = _editColors[v] || DEFAULTS[v] || '#888';
        var row = el('div', 'sp-row');
        row.appendChild(el('span', 'sp-vname', v));
        var sw = el('span', 'sp-swatch'); sw.style.backgroundColor = val; row.appendChild(sw);
        var ci = el('input'); ci.type = 'color'; ci.value = val; row.appendChild(ci);
        var ti = el('input'); ti.type = 'text'; ti.value = val; row.appendChild(ti);
        var rst = el('span', 'sp-rst', 'x'); row.appendChild(rst);
        function onChange(nv) { _editColors[v] = nv; sw.style.backgroundColor = nv; ci.value = nv; ti.value = nv; applyEdits(); }
        ci.addEventListener('input', function(){onChange(this.value);});
        ti.addEventListener('change', function(){if(/^#[0-9a-fA-F]{6}$/.test(this.value))onChange(this.value);else this.value=_editColors[v];});
        rst.onclick = function(){onChange(DEFAULTS[v]||'#888');};
        grid.appendChild(row);
      });
      det.appendChild(grid);
      colorSec.appendChild(det);
    });
    host.appendChild(colorSec);

    // 效果组(透明度 + 背景)
    var fxSec = el('details', 'sp-section');
    var fxSum = el('summary');
    fxSum.textContent = '效果';
    if (_editOpacity > 0 || _editBg || _editBgOpacity > 0) fxSum.appendChild(el('span', 'sp-mod', _editOpacity>0?'(透明:'+Math.round(_editOpacity*100)+'%)':''));
    fxSec.appendChild(fxSum);
    var fxBody = el('div', 'sp-fx');
    // 界面透明度: 100=不透明(默认), 30=最透。值存为 CSS opacity (1.0~0.3)
    fxBody.appendChild(el('span', '', '界面透明度'));
    var opSlider = el('input');
    opSlider.type = 'range'; opSlider.min = '30'; opSlider.max = '100'; opSlider.step = '1';
    opSlider.value = String(_editOpacity > 0 ? Math.round(_editOpacity * 100) : 100);
    var opLabel = el('span', '', (opSlider.value === '100' ? '不透明' : opSlider.value + '%'));
    opSlider.oninput = function () {
      var v = parseInt(this.value, 10);
      _editOpacity = v >= 100 ? 0 : v / 100;
      opLabel.textContent = v >= 100 ? '不透明' : v + '%';
      applyEdits();
    };
    fxBody.appendChild(opSlider);
    fxBody.appendChild(opLabel);
    // 背景图透明度: 仅在设置了背景时可用
    var bgOpSlider, bgOpLabel;
    if (_editBg) {
      fxBody.appendChild(el('span', '', '| 背景透明度'));
      bgOpSlider = el('input');
      bgOpSlider.type = 'range'; bgOpSlider.min = '10'; bgOpSlider.max = '100'; bgOpSlider.step = '1';
      bgOpSlider.value = String(_editBgOpacity > 0 ? Math.round(_editBgOpacity * 100) : 100);
      bgOpLabel = el('span', '', bgOpSlider.value === '100' ? '不透明' : bgOpSlider.value + '%');
      bgOpSlider.oninput = function () {
        var v = parseInt(this.value, 10);
        _editBgOpacity = v >= 100 ? 0 : v / 100;
        bgOpLabel.textContent = v >= 100 ? '不透明' : v + '%';
        applyEdits();
      };
      fxBody.appendChild(bgOpSlider);
      fxBody.appendChild(bgOpLabel);
    }
    // 背景图片
    var bgLabel = el('span', '', '背景:');
    fxBody.appendChild(bgLabel);
    var bgStatus = el('span', '', _editBg ? (_editBg.indexOf('data:') === 0 || _editBg.length > 200 ? '本地图片' : 'URL') : '无');
    bgStatus.style.cssText = 'font-size:11px;color:var(--500);';
    fxBody.appendChild(bgStatus);
    var fileLabel = document.createElement('label');
    fileLabel.textContent = '上传'; fileLabel.className = 'sp-btn'; fileLabel.style.cssText += 'cursor:pointer;';
    var fileInput = document.createElement('input');
    fileInput.type = 'file'; fileInput.accept = 'image/*'; fileInput.style.display = 'none';
    fileInput.onchange = function () {
      var f = fileInput.files && fileInput.files[0];
      if (!f) return;
      var reader = new FileReader();
      reader.onload = function () { _bgDataUrl = reader.result; _editBg = _bgDataUrl; bgStatus.textContent = '本地图片'; applyEdits(); try { SP.applyAsTheme(); } catch (e) {} SP.render(); };
      reader.readAsDataURL(f);
    };
    fileLabel.appendChild(fileInput);
    fxBody.appendChild(fileLabel);
    var urlInput = el('input');
    urlInput.type = 'text'; urlInput.placeholder = '图片URL';
    urlInput.style.cssText = 'width:140px;font-size:11px;background:var(--850);border:1px solid var(--700);color:var(--000);padding:2px 4px;border-radius:3px;';
    urlInput.value = (_editBg && _editBg.indexOf('data:') !== 0) ? _editBg : '';
    fxBody.appendChild(urlInput);
    var urlBtn = el('span', 'sp-btn', '设URL');
    urlBtn.onclick = function () { var v = urlInput.value.trim(); if (!v) return; _bgDataUrl = ''; _editBg = v; bgStatus.textContent = v; applyEdits(); try { SP.applyAsTheme(); } catch (e) {} SP.render(); };
    fxBody.appendChild(urlBtn);
    var clearBg = el('span', 'sp-btn', '清除');
    clearBg.style.cssText += 'color:var(--red);';
    clearBg.onclick = function () { _bgDataUrl = ''; _editBg = ''; bgStatus.textContent = '无'; urlInput.value = ''; applyEdits(); try { SP.applyAsTheme(); } catch (e) {} SP.render(); };
    fxBody.appendChild(clearBg);
    fxSec.appendChild(fxBody);
    host.appendChild(fxSec);

    // 消息条
    host.appendChild(el('div', 'sp-msg'));
    // 消费跨 render 的 flash 消息 (保存/导入后旧 msg 被销毁, 用新 render 的 msg 重新 flash)
    if (_pendingFlash) { flash(_pendingFlash); _pendingFlash = ''; }
  };

  function deleteTheme(name) {
    if (PROTECTED.indexOf(name) >= 0) return false;
    var saved = loadJSON(THEMES_KEY, {});
    if (!saved[name]) return false;
    delete saved[name];
    saveJSON(THEMES_KEY, saved);
    SP.render();
    return true;
  }

  // ========== 外部 API ==========
  SP.applyAsTheme = function () {
    try { if (typeof ThemeManager !== 'undefined' && ThemeManager.setPreference) { ThemeManager.setPreference('custom'); } else { localStorage.setItem('dolTheme', 'custom'); document.documentElement.setAttribute('data-theme', 'custom'); } try { $('input[name=theme][value=custom]').prop('checked', true); } catch (e) {} } catch (e) {}
  };

  SP.init = function () {
    injectUIStyle();
    if (!localStorage.getItem(SEED_KEY)) {
      saveJSON(ACTIVE_KEY, shallowClone(DEFAULTS));
      var seed = {};
      for (var tn in COMMUNITY) { if (Object.prototype.hasOwnProperty.call(COMMUNITY, tn)) seed[tn] = { name: tn, colors: shallowClone(COMMUNITY[tn]) }; }
      saveJSON(THEMES_KEY, seed);
      localStorage.setItem(SEED_KEY, '1');
    }
    applyAll();
    SP.render();
  };

  // 启动时自动注入 custom CSS 块, 无需等用户打开工坊面板
  if (!localStorage.getItem(SEED_KEY)) {
    saveJSON(ACTIVE_KEY, shallowClone(DEFAULTS));
    var _seed = {};
    for (var _tn in COMMUNITY) { if (Object.prototype.hasOwnProperty.call(COMMUNITY, _tn)) _seed[_tn] = { name: _tn, colors: shallowClone(COMMUNITY[_tn]) }; }
    saveJSON(THEMES_KEY, _seed);
    localStorage.setItem(SEED_KEY, '1');
  }
  applyAll();
  // 异步加载 IDB 大图 (localStorage 只存了 __idb__ 标记)
  if (localStorage.getItem(BG_KEY) === '__idb__') {
    _idbLoad(function(dataUrl) { if (dataUrl) { _bgDataUrl = dataUrl; applyAll(); } });
  }

  console.log('[palette] 已加载, Options 主题工坊标签就绪');
})();
