// rules.js — mod 生态校验规则数据（单一事实源）
// 消费方: 整合包构建器 builder.html(内联) + 起源管理器 game/rules.js(副本)
// 修改本文件后需同步两处。纯数据, 无逻辑。
(function () {
  'use strict';
  if (typeof window !== 'undefined' && window.SusatoRules) return;

  var RULES = {
    version: 1,

    // 互斥对: 两个 mod 不应同时安装。type: hard=阻止构建/红色告警, warn=黄色提示
    // versionA/versionB 为可选 semver 范围, 省略表示任意版本
    mutualExclusion: [
      {
        nameA: '起源框架',
        nameB: '寿里美化拓展-起源管理器',
        reason: '管理器已升格为起源框架基座, 旧管理器包退役, 同装会双份面板与钩子',
        type: 'hard'
      },
      {
        nameA: '起源框架',
        nameB: '起源框架-寿里美化包', versionB: '<=2.8',
        reason: '旧版大包(<=2.8)自带整套框架层, 与基座同装单例互抢/注入双份, 请换 v2.9+ 内容包',
        type: 'hard'
      },
      {
        nameA: '起源框架',
        nameB: '寿里美化拓展-人模切换',
        reason: '起源框架基座已内置人模切换, 同装会在镜子里出现两个入口',
        type: 'hard'
      },
      {
        nameA: '起源框架-寿里美化包', versionA: '>=2.7',
        nameB: '寿里美化拓展-人模切换',
        reason: '大包 v2.7 起生态内置人模切换(2.7-2.8 在大包, 2.9+ 在基座), 独立包仅供无框架环境',
        type: 'hard'
      },
      {
        nameA: '起源框架-寿里美化包',
        nameB: 'susato-model ZH',
        reason: '同一个 mod 的新旧两代包, 同装图片补丁全部双份冲突',
        type: 'hard'
      }
    ],

    // 旧包名: 检测到即提示换新
    oldNames: [
      { oldName: '寿里美化拓展-起源管理器', newName: '起源框架', reason: '2026-07-17 管理器升格为框架基座, 旧管理器不再维护' },
      { oldName: 'susato-model ZH', newName: '起源框架-寿里美化包', reason: '2026-07-16 改名, 旧包不再维护' },
      { oldName: 'susato-model EN (International)', newName: '(暂无, EN 区重做中)', reason: '英文区旧包已暂弃' },
      { oldName: 'KatherineHouse', newName: '隐都潜流', reason: '2026-07-16 改名, 旧包不再维护' }
    ],

    // 顺序契约: name 必须排在 afterNames 中每个已安装 mod 之后
    orderContracts: [
      { name: '起源框架-寿里美化包', afterNames: ['起源框架'], reason: '内容包的衣物/发型注册依赖基座框架先建立 API' },
      { name: '隐都潜流', afterNames: ['起源框架', '起源框架-寿里美化包'], reason: '内容 mod 依赖框架的 addon 与运行时' },
      { name: '寿里美化拓展-人模切换', afterNames: ['起源框架-寿里美化包'], reason: '人模改写钩子须后于框架叠穿钩子(无基座的旧生态)' }
    ],

    // 起源框架功能模块开关清单(管理器 C 页签)
    // lock=true 不可关; warn 为关闭时的额外提示文字
    modules: [
      { id: 'susato-core', name: '渲染器核心', lock: true, desc: '图层注入与编译钩子管道, 一切功能的地基' },
      { id: 'state-addon', name: '运行时地基', lock: true, desc: '变量托管/统一消息/日界调度, 其他模块依赖' },
      { id: 'text-addon', name: '文本注入引擎', lock: true, desc: 'SusatoTextAddon, 各 mod 的界面注入都靠它' },
      { id: 'clothing-addon', name: '衣服注册框架', lock: true, desc: '存档穿着注册衣物时关闭会导致崩溃' },
      { id: 'clothing-data', name: '衣服数据', lock: true, desc: '同上, 与衣服注册框架一体' },
      { id: 'hair-addon', name: '发型注册框架', lock: true, desc: '存档使用注册发型时关闭会异常' },
      { id: 'skill', name: '技能注册框架', lock: false, warn: '内容 mod 注册的技能将不生效(存档变量保留)', desc: '自定义技能注册与升级提示' },
      { id: 'economy-addon', name: '经济框架', lock: false, warn: '隐都潜流银行/贷款等结算将停摆', desc: '周期结算与账本' }
    ],

    // 联网更新配置: jsDelivr 为主通道 (CORS 全开, 国内可达, 单文件 20MB 硬上限——
    // 超限包由发布脚本切分卷, 管理器下载后拼接), raw GitHub 为降级通道(国内常不可达)。
    // 更新源文件必须提交进仓库分支(git 文件树), Release 附件 jsDelivr 不服务。
    update: {
      user: 'anlimi555s',
      repo: 'AetherCore',
      branch: 'main',
      manifestFile: 'versions.json',
      // jsDelivr 优先, raw 降级 (函数内按序尝试)
      urls: function (file) {
        var u = RULES.update;
        return [
          'https://cdn.jsdelivr.net/gh/' + u.user + '/' + u.repo + '@' + u.branch + '/' + file,
          'https://raw.githubusercontent.com/' + u.user + '/' + u.repo + '/' + u.branch + '/' + file
        ];
      }
    }
  };

  if (typeof window !== 'undefined') window.SusatoRules = RULES;
  if (typeof module !== 'undefined' && module.exports) module.exports = RULES;
})();
